from boolean2 import Model
import random

text = """
# initial values
A = B = C = True

# updating rules

A* = A and C
B* = A and C
C* = not A
"""

counter = 0
def set_value( state, name, value, p ):
    "Custom value setter"
    global counter

    # detect the node of interest
    if name == 'A':
        
        # odd/even 
        value = bool(counter % 2)
        print 'now setting node %s to %s' % (name, value)
        print state
        setattr( state, name, value )
        print state
        print '-' * 10
        
        counter += 1
    # this sets the attribute
    setattr( state, name, value )

    return value

model = Model( text=text, mode='sync')
model.parser.RULE_SETVALUE = set_value
model.initialize()
model.iterate( steps=10 )

for state in model.states:
    print state.A, state.B


