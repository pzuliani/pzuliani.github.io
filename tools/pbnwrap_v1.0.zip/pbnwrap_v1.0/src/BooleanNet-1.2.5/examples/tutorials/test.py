import boolean2
from boolean2 import util

text = """
1: A* = B or C or E
1: B* = A and B and C or E
1: C* = E or (not F)
"""

edges = []

flag = False

def my_SETVALUE( state, name, value, parser ):
    if flag:
        print '->' , name
        print '---'
    return  setattr( state, name, value )
  
def my_GETVALUE( state, name, parser ):
    edges.append( name )
    return name
    
def my_AND( node1, node2, parser ):
    global flag

    flag = True
    print node1, node2,
    return ''

def my_OR( node1, node2, parser ):
    global flag

    flag = True
    print node1, node2,
    return ''

def my_NOT( node, parser ):
    global flag

    flag = True
    print ' not ' + node,
    return ''

model = boolean2.Model( text=text, mode='sync')

model.RULE_GETVALUE = my_GETVALUE
model.RULE_SETVALUE = my_SETVALUE
model.RULE_AND = my_AND
model.RULE_OR = my_OR
model.RULE_NOT = my_NOT

model.initialize( missing=util.true )
model.iterate(steps=1)