# dynamically generated code
# abbreviations: c=concentration, d=decay, t=threshold, n=newvalue
# [(0, 'A', (1.0, 1.0, 0.5)), (1, 'B', (0.0, 1.0, 0.5)), (2, 'C', (0.0, 1.0, 0.5)), (3, 'D', (1.0, 1.0, 0.5))]
c0, d0, t0 = 1.000000, 1.000000, 0.500000 # A
c1, d1, t1 = 0.000000, 1.000000, 0.500000 # B
c2, d2, t2 = 0.000000, 1.000000, 0.500000 # C
c3, d3, t3 = 1.000000, 1.000000, 0.500000 # D
dt = 0.466666666667
x0 = c0, c1, c2, c3
def derivs( x, t):
    c0, c1, c2, c3 = x
    n0, n1, n2, n3 = 0.0, 0.0, 0.0, 0.0
    
    #1: B * = A or C
    n1  = float(  ( c0 > t0 )  or  ( c2 > t2 )  ) - d1 * c1
    
    #1: C * = A and not D
    n2  = float(  ( c0 > t0 )  and not  ( c3 > t3 )  ) - d2 * c2
    
    #1: D * = B and C
    n3  = float(  ( c1 > t1 )  and  ( c2 > t2 )  ) - d3 * c3

    return ( n0, n1, n2, n3 ) 
