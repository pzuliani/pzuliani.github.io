from boolean2 import Model, util

text = file('ABA.txt').read()

model = Model( text=text, mode='sync')
model.initialize( missing=util.randbool )
model.iterate( steps=5 )

for state in model.states:
    print state.ABA


