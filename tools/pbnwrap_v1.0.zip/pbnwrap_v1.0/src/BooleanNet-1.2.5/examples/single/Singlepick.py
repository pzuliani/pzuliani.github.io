import time, sys, os, random
step1 = time.time()

random.seed(1)

# make it import the current source
sys.path.insert(0, os.path.abspath(os.path.join( '..', '..')))

import boolean2
from boolean2 import util, state, network


import networkx
from networkx import component

# three nodes
rules = """
CIS* = Ca
Ca* = CIS and (not CaATPase)
CaATPase* = Ca
"""
REPEAT = 1
ITERATE = 3

def simulation( trans ):
    "One simulation step will update the transition graph"

    # create the model
    model = boolean2.Model( text=rules, mode='async')

    # generates all states, set limit to a value to keep only the first that many states
    # when limit is a number it will take the first that many initial states
    initializer = state.all_initial_states( model.nodes, limit=7 )
    
    # the data is the inital data, the func is the initializer
    for data, initfunc in initializer:
        print data
        model.initialize(missing=initfunc)
        model.iterate(ITERATE)
        print model.states
        trans.add( model.states[::1] )


# this will hold the transition graph
trans = network.TransGraph( logfile='singlepick.log', verbose=True )

# will run the simulation this many times


for num in range( REPEAT ):
    simulation ( trans )

sys.exit()

# generate the colormap based on components
colormap = network.component_colormap( trans.graph )

# saves the transition graph into a gml file
trans.save( 'singlepick.gml', colormap=colormap )


fc = open('conncomp.txt', 'wt')
result = []
strong_components = networkx.component.strongly_connected_components( trans.graph )
result.append(strong_components)
result = str(result)
fc.write(result)
fc.write('###')

for component in strong_components:
     sum1= 0.0
     sum2 = 0.0
     for node in component:
         sum1 = sum1 + trans.graph.in_degree(node)
         sum2 = sum2 + trans.graph.out_degree(node)
         
     sum1 = int(sum1)
     sum2 = int(sum2)
     avg_indegree = sum1 / len(component)
     avg_outdegree = sum2 / len(component)
     fc.write('avg_indegree is ' + str(avg_indegree))
     fc.write('###')
     fc.write('avg_outdegree is ' + str(avg_outdegree))
     fc.write('###')


from sets import Set
N1 = set()
SCC1 = networkx.component.strongly_connected_component_subgraphs(trans.graph)[0]
for nodes in SCC1:
    N1 = N1 |(set(trans.graph.neighbors(nodes)))
M1 = N1 - set(SCC1)
fc.write('outcomp1 = '+ str(M1))
fc.write('length coucomp1 = ' + str(len(M1)))


all = set( trans.graph.nodes() )
outside1 = all - set(SCC1)
L1 = set()

for node in outside1:
   for nbr in trans.graph.neighbors(node):
       if nbr in SCC1:
           L1 = L1 | set([node])
           break # does not need to look for more neigbors


fc.write('incomp1 = '+ str(L1))
fc.write('length incomp1 = ' +str(len(L1)))


N2 = set()
SCC2 = networkx.component.strongly_connected_component_subgraphs(trans.graph)[1]
for nodes in SCC2:
    N2 = N2 |(set(trans.graph.neighbors(nodes)))
M2 = N2 - set(SCC2)
fc.write('outcomp2 = '+ str(M2))
fc.write('length coucomp2 = ' + str(len(M2)))


outside2 = all - set(SCC2)
L2 = set()

for node in outside2:
   for nbr in trans.graph.neighbors(node):
       if nbr in SCC2:
           L2 = L2 | set([node])
           break # does not need to look for more neigbors

fc.write('incomp2 = '+ str(L2))
fc.write('length incomp2 = ' +str(len(L2)))


fc.close()

step2 = time.time()
print 'Elapsed seconds ', step2 - step1




