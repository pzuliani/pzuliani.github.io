# dynamically generated code
# abbreviations: c=concentration, d=decay, t=threshold, n=newvalue
# [(0, 'A', (1.0, 1.0, 0.5)), (1, 'B', (1.0, 1.0, 0.5)), (2, 'C', (1.0, 1.0, 0.5))]
c0, d0, t0 = 1.000000, 1.000000, 0.500000 # A
c1, d1, t1 = 1.000000, 1.000000, 0.500000 # B
c2, d2, t2 = 1.000000, 1.000000, 0.500000 # C
# custom imports
import localdefs
reload(localdefs)
from localdefs import *
dt = 0.02
x0 = c0, c1, c2
def derivs( x, t):
    c0, c1, c2 = x
    n0, n1, n2 = 0.0, 0.0, 0.0
    
    #1: A * = A
    c0  = generate_value( c1  >  t1 ,  c0 ,  t0 ,  d0 )
    
    #1: B * = B
    n1  = float(  ( c1 > t1 )  ) - d1 * c1
    
    #1: C * = A and B
    n2  = float(  ( c0 > t0 )  and  ( c1 > t1 )  ) - d2 * c2

    return ( n0, n1, n2 ) 
