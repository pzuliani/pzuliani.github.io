
import sys, random
import boolean2
from boolean2 import Model, util
import numpy
# from statlib import stats

# list the nodes that need be overriden
# case and spelling must match!

# these nodes will be activated at 25%
ACTIVATE_25 = set( [ 'SHP1', 'Cbl' ] )

# these nodes will be activated at 33%
ACTIVATE_33 = set( [ "Lck", "Itk", "Txk"] )

# create a custom value getter 
# that overrides the nodes value when obtained

def get_value( state, name, p ):
    "Custom value getter"

    # the value it would normally return
    value = getattr( state, name )

    # to override it must be both part of the listing and true
    if (name in ACTIVATE_25) and value:
        value = random.choice ( (True, False, False, False) )
        # comment this out to see what it sets it to
        #print '25%% node %s, override to=%s' % (name, value)


    if (name in ACTIVATE_33) and value:
        value = random.choice ( (True, False, False) )
        #print '33%% node %s, override to=%s' % (name, value)

    return value



def run( text, nodes, repeat, steps ):
    """
    Runs the simulation and collects the nodes into a collector, 
    a convenience class that can average the values that it collects.
    """
    coll = util.Collector()
    
    for i in xrange( repeat ):
        model  = Model( mode='async', text=text )
        model.parser.RULE_GETVALUE = get_value
        model.initialize( missing=util.false )#for random randbool
        model.iterate( steps=steps)
        coll.collect( states=model.states, nodes=nodes )

    avgs = coll.get_averages( normalize=True )
    SteadyState = model.report_cycles()
    print SteadyState 
    return avgs

if __name__ == '__main__':

    TEXT = file( 'Th-August-full-model-for-Istvan.txt').read()
    data = []
    # the nodes of interest that are collected over the run
    NODES  = boolean2.all_nodes( TEXT )
        
       
    
    #
    # raise this for better curves (will take about 2 seconds per repeat)
    # plots were made for repeat = 1000
    #
    REPEAT = 10
    STEPS  = 10

    # inital run
    values = run( text=TEXT, nodes=NODES, repeat=REPEAT, steps=STEPS) 
    data.append( values ) 
        

    # target nodes that need be turned off, may contain sublistst as elements
    nodes = [ 'Itk', 'Txk' ]
    
    for node in nodes:
        mtext = boolean2.modify_states( text=TEXT, turnoff=['Itk']  )
        mvalues = run( text=mtext, nodes=NODES, repeat=REPEAT, steps=STEPS) 
        data.append( mvalues ) 

#    mtext3 = boolean2.modify_states( text=TEXT, turnoff=['Itk','Txk'] )
#    mvalues = run( text=mtext3, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )

#    mtext4 = boolean2.modify_states( text=TEXT, turnoff=['Lck'] )
#    mvalues = run( text=mtext4, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )

#    mtext5 = boolean2.modify_states( text=TEXT, turnoff=['STAT4'] )
#    mvalues = run( text=mtext5, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )

#    mtext6 = boolean2.modify_states( text=TEXT, turnoff=['STAT6'] )
#    mvalues = run( text=mtext6, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )

#    mtext7 = boolean2.modify_states( text=TEXT, turnoff=['Tbet'] )
#    mvalues = run( text=mtext7, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )

#    mtext8 = boolean2.modify_states( text=TEXT, turnoff=['GATA3'] )
#    mvalues = run( text=mtext8, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )

#    mtext9 = boolean2.modify_states( text=TEXT, turnoff=['Itk', 'Tbet'] )
#    mvalues = run( text=mtext9, nodes=NODES, repeat=REPEAT, steps=STEPS) 
#    data.append( mvalues )
                    
    fname = 'Th-run.bin'
    util.bsave( data, fname=fname )
    print '- data saved into %s' % fname
    
    # ploting with matplotlib
#     import pylab 
#     labels, collect = [], []
#     
#     pylab.subplot(121)
#     for key, val in values.items():        
#         p = pylab.plot(values[key])
#         collect.extend(p)
#         
#     pylab.subplot(122)    
#     for key, val in mvalues.items():        
#         p1 = pylab.plot(mvalues[key])
#         collect.extend(p1)    
#     
#     for node in NODES:
#         labels.append("-%s" %node)
#     pylab.xlabel( 'Time Steps' )
#     pylab.ylabel( 'Percent (%)' )
#     pylab.legend( collect, labels, loc='best' )
#     pylab.savefig('Th-run.png')
#     
#     pylab.show()
