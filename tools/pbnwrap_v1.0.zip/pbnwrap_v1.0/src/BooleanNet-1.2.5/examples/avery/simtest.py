import boolean2
import random
from boolean2.plde import helper

text = """
A = True
B = True
C = True

1: A *= A
1: B *= B
1: C *= A and B
"""

#
# setting up simulation parameters
#
FULLT = 50 # time
STEPS = FULLT*50 # steps per time unit

values = [ 1, 0 ]
# setting up the ovveride function that will be called when 
# creating the differential equations
def override( node, indexer, tokens ):
    
    if node == 'A':
        # A activated by B at 50%, if B is on A will be on 50% of time

       
        concB  = helper.conc( 'B', indexer ) 
        threshB  = helper.threshold('B', indexer)
        # this will be the  current status of B in each loop
        statusB  = "%s > %s" % (concB, threshB)

        newvalA  = helper.conc( node, indexer )
        concA    = helper.conc( node, indexer )
        threshA  = helper.threshold(node, indexer)
        decayA   = helper.decay(node, indexer)
        
        # build the equation for this node
        expr    = "%s = generate_value(%s, %s, %s, %s)" % ( newvalA, statusB, concA, threshA, decayA)

        return expr

model = boolean2.Model( text=text, mode='plde' )
# comment this out to get the regular behavior
model.OVERRIDE = override
model.initialize()
model.iterate( fullt=FULLT, steps=STEPS, localdefs='localdefs')