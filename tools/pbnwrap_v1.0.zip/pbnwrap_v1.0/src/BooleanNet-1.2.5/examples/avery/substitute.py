
text = """
The concentration for A is %(concA)s.
The concentration for B is %(concB)s.
Compare %(concA)s to %(concB)s 
"""

for i in range(3):
    data = dict(concA=i, concB=i+1)
    out = text % data
    print out
    print '-' * 10
