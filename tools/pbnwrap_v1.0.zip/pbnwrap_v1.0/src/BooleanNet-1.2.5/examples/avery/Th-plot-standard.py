from pylab import *
from boolean2 import util
# compare smooth vs no smooth

def smooth(data, w=0): # remove for no smooth
    "Smooths data by a moving window of width 'w'" # remove for no smooth
    fw = float(w) # remove for no smooth
    def average( index ): # remove for no smooth
        return sum( data[index: index+w] )/fw # remove for no smooth
    indices = xrange( len(data) - w )    # remove for no smooth    
    out = map( average, indices ) # remove for no smooth
    return out # remove for no smooth

def make_plot():
    
    # contains averaged node information based on 1000 runs
    data = util.bload( 'Th-run.bin' )

     # each of these is a dictionary keyed by nodes
    run, run1, run2 = data
    
    # applies smoothing to all values
    for run in (run, run1, run2): # remove for no smooth
        for key, values in run.items(): # remove for no smooth
            run[key] = smooth( values, w=1 ) # 1 for no smooth, 10 for default

#   Plotting Expression
    #
    subplot(121)
       
    p1 = plot( run['IFNg'], 'ro-' )
    p2 = plot( run1['IFNg'], 'bo-' )
    p3 = plot( run2['IFNg'], 'bs-' )
#    p4 = plot( run['IFNg'], 'rs-' )
#    p5 = plot( run7['IFNg'], 'ko-' )
#    p6 = plot( run8['IFNg'], 'ks-' )
#    p7 = plot( run9['IFNg'], 'k^-' )
    
    xlabel( 'Time' )
    ylabel( 'Percentage' )
    title ( 'Th Simulation Cytokines')
    a = gca()
    a.set_ylim([0,1.5])
    xlim([0,30])
    #errorbar(x, y, yerr=p.std(x)/p.sqrt(len(x)))
    legend( [p1, p2, p3], 'WT Itk Txk'.split(), loc='best')
    
    subplot(122)
   
    p8 = plot( run['Tbet'], 'ro-' )
    p9 = plot( run1['Tbet'], 'bo-' )
    p10 = plot( run2['Tbet'], 'bs-' )
    p11 = plot( run['GATA3'], 'rs-' )
    p12 = plot( run1['GATA3'], 'ko-' )
    p13 = plot( run2['GATA3'], 'ks-' )
#    p14 = plot( run9['IL4'], 'k^-' )
    
 #   p9 = plot(t, run1['C'], 'bo-', ms=5 )
 #   p10 = plot(t, run1['PH'] , 'bD-', ms=5 )
 #   p11 = plot(t, run1['IL12I'], 'b.-', ms=5 )
 #   p12 = plot(t, run1['IL12II'], 'b^-', ms=5 )
 #   p7 = plot( run['IFNg'], 'ko-' )
 #   p8 = plot( run['IL4'], 'ks-' )
 #   
    xlabel( 'Time' )
    ylabel( 'Percentage' )
    title ( 'Th Simulation TF')
    a = gca()
    a.set_ylim([0,1.5])
    xlim([0,30])
    legend( [p8, p9, p10, p11, p12, p13], 'WT Itk Txk WT Itk Txk'.split(), loc='best')
    
if __name__ == '__main__':
    figure(num = None, figsize=(14, 7), dpi=80, facecolor='w', edgecolor='k')
    make_plot()
    savefig('Figure August model Th0.png')
    show()


#
# other drawing styles -->
# 'r' red line, 'g' green line, 'y' yellow line
## 'ro' red dots as markers, 'r.' smaller red dots, 'r+' red pluses
## 'r--' red dashed line, 'g^' green triangles, 'bs' blue squares
## 'rp' red pentagons, 'r1', 'r2', 'r3', 'r4' 
# errorbar(x, y, yerr=e)
# fontstyle='italic'
# Standard error is standard deviation over sqrt(N), so use p.std(x)/p.sqrt(len(x)) to get standard error for the data in x. 
# import pylab as p (open)
# p.rcParams (print parameters
# rcParams['axes.labelsize'] = 16.0 (14 is default)
# p.rcParams['xtick.labelsize'] = 16.0
# p.rcParams['ytick.labelsize'] = 16.0; lw=2
# lines.markersize (default is 6)
#right
#	center
#lower left
#	center right
#	upper left
#center left
#	upper right
#	lower right
	#upper center
	#lower center
	#best
