from random import randint

def generate_value(status, conc, thresh, decay):

    # when the status is true it generates a new state at 50% chance
    # otherwise returns the result of the original equation 
    if status:
        value = randint(0, 1)
    else:
        value = conc > thresh

    return value - conc * decay