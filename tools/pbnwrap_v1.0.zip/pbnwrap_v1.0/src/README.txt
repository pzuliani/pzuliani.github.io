The monitor folder contains the source code for the BLTL trace checker.

The pbnwrap folder contains the source code for the statistical routines.
