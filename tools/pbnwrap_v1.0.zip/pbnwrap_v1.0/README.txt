Installation
============
The BooleanNet statistical model checking 'wrapper' is called bnwrap. The Bounded LTL 
trace checker is just called checker. I have tested them under Linux and Cygwin 
(Windows 7) with no problems; bnwrap uses the GNU Scientific Library (GSL), so you need 
that to be installed.

--->Python 2.5 or higher is required by BooleanNet.

Usage
=====
The command line is the following:

   bnwrap <testfile> <BooleanNet-modelfile> <checker> <property> <trace>

where:
      <testfile> is a text file containing a sequence of test specifications;
      <BooleanNet-modelfile> is the file name of the BooleanNet model;
      <checker> is the file name of the trace checker executable;
      <property> is the file name of the BLTL property to check;
      <trace> is the name of the trace file computed by BooleanNet.

For example, try the following command:

./bnwrap test netsim.py ./checker prop trace.txt

python might output some warning message every time is executed - just ignore it.
Use the netsim.py file provided for encoding your BooleanNet models. Also, the command 
above assumes that the trace checker binary is in the same folder of bnwrap.
The command should take 30 seconds or so to complete. The final output should
be something like:

  BFTI 0.9 1000 1 1 0.01: Reject Null Hypothesis, successes = ??, samples = ??
  Elapsed time: ?? seconds

where the question mark figures vary from run to run, of course.


OpenMP version
==============
The parallel version of the wrapper is called pbnwrap. It uses the OpenMP library for 
shared-memory parallel programming. Usage is the same as the sequential version. 
The program tries to run with the maximum number of threads available on a given 
machine. Each thread performs a BooleanNet simulation and writes the output on a 
different file, using <trace> as the base file name. For example, if <trace> is 
trace.txt, then thread number 21 will always write its output in the file _21trace.txt

