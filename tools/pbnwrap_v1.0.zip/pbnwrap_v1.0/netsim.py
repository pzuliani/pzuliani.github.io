#
# Network simulator for BooleanNet statistical model checker
#
# * Copyright (C) 2011, 2012 Paolo Zuliani and Edmund M. Clarke.  All rights reserved.
# * By using this software the USER indicates that he or she has read, understood and will comply
# * with the following:
# *
# * 1. The USER is hereby granted non-exclusive permission to use, copy and/or
# * modify this software for internal, non-commercial, research purposes only. Any
# * distribution, including commercial sale or license, of this software, copies of
# * the software, its associated documentation and/or modifications of either is
# * strictly prohibited without the prior consent of the authors. Title to copyright
# * to this software and its associated documentation shall at all times remain with
# * the authors. Appropriated copyright notice shall be placed on all software
# * copies, and a complete copy of this notice shall be included in all copies of
# * the associated documentation. No right is granted to use in advertising,
# * publicity or otherwise any trademark, service mark, or the name of the authors.
# *
# * 2. This software and any associated documentation is provided "as is".
# *
# * THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
# * INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
# * USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
# * INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
# * RIGHTS OF A THIRD PARTY.
# *
# * The authors shall not be liable under any circumstances for any direct,
# * indirect, special, incidental, or consequential damages with respect to any
# * claim by USER or any third party on account of or arising from the use, or
# * inability to use, this software or its associated documentation, even if the
# * authors have been advised of the possibility of those damages.



import sys

# Get BooleanNet from local folder
# You may delete this if BooleanNet has been installed by root on your system
sys.path.append('./src/BooleanNet-1.2.5')


# BooleanNet's use of md5 is 'deprecated'.
# This will ignore md5 warnings
import warnings
with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=DeprecationWarning)
    import md5

import boolean2
import random
from boolean2 import util


# The model update rules start here
# You may load them from a file, or directly enter them
text = file('t-02.txt').read()

# End of model

#
# Beginning of the simulation and output code
#

# In Python 2.7 one can define myset as a list of elements
myset = set()
myset.add(2)
myset.add(3)

# Print usage
if not (len(sys.argv) in myset) :
    sys.exit("Usage: python <modelfile> <outputfile> [<seed>]")

# Initialize the random number generator with the given seed.
# The current time is used to initialize the generator when the
# random module is first imported.
if len(sys.argv) == 3 : 
    random.seed(int(sys.argv[2]))

# Create the trace (output) file
f = open(sys.argv[1],'w')

# Number of simulation steps
steps = 29

# Used for collecting the simulation data
coll = util.Collector()


for i in range(1):

    # Use mode='rank' for asynchronous semantics
    model = boolean2.Model( text=text, mode='async')
    model.initialize()
    model.iterate( steps=steps )

    # Collect data for all the nodes of the model
    coll.collect( states=model.states, nodes=model.nodes )
    
    # Print the first line of the output file. It is '# time <node1> <node2> ....'
    s = '# time'
    for node in model.nodes:
        s = s + ' ' + node
    print>>f, s

    # Print the time series for all the nodes of the model
    # Each line correspond to one step
    for j in range(steps+1):
    	r = ''
    	for node in model.nodes:
		if model.data[node][j] == False:
			r = r + ' 0' 
       		else:
			r = r + ' 1'
    	print>>f, j, r
   
f.close()
