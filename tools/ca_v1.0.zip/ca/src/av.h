/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * av.h		"AVerage"
 *
 * Header file per av.c
 */

/* Semplice routine per stampare messaggi e terminare il programma */
extern void error (char *format, ...);

#ifndef TRUE
#define TRUE 	1
#endif

#ifndef FALSE
#define FALSE 	0
#endif

#define ERROR	0
#define OK		1

#define MAX_FILENAME_LEN	256

/* Struttura per descrivere un frame di dati */
typedef struct _frame {

  /* Dimensioni del frame */
  int numRow;
  int numCol;
  int depth;

  /* Il "deposito" vero e proprio dei dati */
  float64 *store;

} frame;


/* Struttura per descrivere il reticolo dei dati in ingresso */
typedef struct _inputData {

  /* Dimensioni del frame */
  int numRow;
  int numCol;
  int depth;

  int numFrame;				/* numero di frame presenti in input */
  int effNumFrame;			/* numero di frame da leggere effettivamente */
  int frameLen;				/* lunghezza (in float64) di un frame */

} inputData;


/* Struttura per un buffer di frame */ 
typedef struct _frameBuf {

  frame *frameA;							/* un array di frame */
  int numFrame;								/* lunghezza dell'array */

} frameBuf;


/* Struttura per descrivere un sotto reticolo */
typedef struct _subLattice {

  /* Definizione di un piano del reticolo */
  int firstRow;
  int firstDepth;
  int lastRow;
  int lastDepth;

  /* Quali colonne interseca il sotto reticolo */
  int firstCol;
  int lastCol;

  /* Numero di nodi del reticolo */
  int len;

} subLattice;


/* Struttura contenente le opzioni specificate dall'utente */
typedef struct _optRec {

  u_int averageType;			/* il tipo di media da eseguire */
  u_int whatToExtract;			/* cosa estrarre dal vettore quantita' di moto */
  int firstFrame;				/* primo e ultimo frame su cui mediare */
  int lastFrame;
  float64 coefficent;			/* coefficiente moltiplicativo per i dati di output */

  subLattice  subLat;	 		/* il sotto reticolo in cui mediare */

  char outFileName[MAX_FILENAME_LEN];	/* nome file di output */
  char inFileName[MAX_FILENAME_LEN];	/* nome file di input */

  u_int setOptions;				/* le opzioni scelte dall'utente */

  int32 infile;					/* file di input (formato HDF) */

} userOption;


/* Le opzioni tra cui l'utente puo' scegliere */
#define OPT_AVERAGE_TYPE  (u_int)0x01
#define OPT_EXTRACT		  (u_int)0x02
#define OPT_FRAME_RANGE	  (u_int)0x04
#define	OPT_SUB_LATTICE	  (u_int)0x08
#define OPT_OUT_FILE	  (u_int)0x10
#define OPT_INFO		  (u_int)0x20
#define OPT_IN_FILE		  (u_int)0x40
#define OPT_COEFF		  (u_int)0x80

/* I vari tipi di media disponibili */
#define AVERAGE_ON_X	(u_int)0x01
#define AVERAGE_ON_Y	(u_int)0x02
#define AVERAGE_ON_Z	(u_int)0x04

/* Cosa estrarre dal reticolo dei dati */
#define EXTRACT_X		(u_int)0x01
#define EXTRACT_Y		(u_int)0x02
#define EXTRACT_Z		(u_int)0x04
#define EXTRACT_XY		(EXTRACT_X | EXTRACT_Y)
#define EXTRACT_YZ		(EXTRACT_Y | EXTRACT_Z)
#define EXTRACT_XZ		(EXTRACT_X | EXTRACT_Z)
#define EXTRACT_XYZ		(EXTRACT_XY | EXTRACT_Z)
#define EXTRACT_MODULUS	(u_int)0x08
#define EXTRACT_DENSITY	(u_int)0x10
#define EXTRACT_SPEED	(u_int)0x20

/* Un array di messaggi per l'utente */
char *msg[] = {
"Calcolo dei valori medi per velocita' e densita'.\n\
Uso: av [-h -v -c <coeff> -r<range>  -a{xyz}  -s<sublattice_def>] -e{xyzdmv} -o<outfile> -i<infile>\n\
Usa -h per avere un ulteriore aiuto.",

"Calcolo dei valori medi per velocita' e densita'.\n\
Uso: av [-h -v -c <coeff> -r<range>  -a{xyz}  -s<sublattice_def>] -e{xyzdmv} -o<outfile> -i<infile>\n\
Commenti:\n\
  -h  mostra questa schermata.\n\n\
  -v  all'inizio di ogni file di output scrive delle informazioni aggiuntive sul suo\n\
      contenuto.\n\n\
  -c  <coeff> coefficente moltiplicativo per i dati di output: e' un numero reale.\n\
      Per default vale 1.\n\n\
  -e  specifica quali quantita' estrarre dai dati in ingresso.\n\
      L'argomento puo' essere un qualunque sottoinsieme (non vuoto) di {x,y,z,d,m,v}\n\
      contenente almeno un elemento di {d,v,m}:\n\
        d per estrarre la densita';\n\
        v per estrarre la velocita';\n\
        m per estrarre il modulo delle velocita';\n\
        x, y, z le componenti da considerare per estrarre velocita' e/o modulo.\n\n\
  -r  definisce il range di frame da considerare per il processo di media. Il\n\
      primo frame ha indice 0. Es: -r0,4  media sui frame da 0 a 4 compreso.\n\
      Per default il range coincide con tutti i frame disponibili.\n\n\
  -s  definisce il sottoreticolo su cui mediare. La definizione e' la seguente:\n\
       -s firstRow,firstDepth,lastRow,lastDepth,firstCol,lastCol\n\
      firstRow,firstDepth, etc.. sono tutti numeri interi compresi tra 0 e dimensione\n\
      corrispondente del reticolo meno 1.\n\
      Es: -s 0,0,5,10,9,9  considera le righe tra 0 e 5 compreso, le profondita' tra\n\
          0 e 10 compreso e le colonne tra 9 e 9 compreso (cioe' solo la 9).\n\
      Per default il sottoreticolo coincide con l'intero reticolo in ingresso.\n\n\
  -a  specifica il tipo di media spaziale da eseguire. L'argomento puo' essere un\n\
      qualunque sottoinsieme (non vuoto) di {x,y,z}.\n\n\
  -i <infile>  specifica il nome del file di input.\n\n\
  -o <outfile>  nome base per i files di output.\n\n\
  Il programma scrive, in funzione dei comandi dati sulla linea, i seguenti files:\n\
  <outfile>.d        file contenente la densita';\n\
  <outfile>.m        file contenente il modulo della velocita';\n\
  <outfile>.{x|y|z}  files contenenti le componenti estratte della velocita'.\n\n\
Note:\n\
  - i comandi -e, -o e -i sono *obbligatori*;\n\
  - se si vuole estrarre il modulo o la velocita' bisogna anche specificare quali\n\
    componenti della velocita' considerare;\n\
  - il sistema di riferimento di av e' il seguente:\n\
                          x^  y^\n\
      colonne     == z      \\  |\n\
      righe       == y       \\ |\n\
      profondita' == x        \\|______> z\n",
			   "av: errore leggendo opzione -",
			   "av: <infile> non in formato HDF",
			   "av: non posso aprire",
			   "av: -e e -o sono obbligatorie",
			   "av: argomento non valido per opzione -",
			   "av: malloc() fallita",
			   "av: specificare le componenti velocita' in -e",
			   "av: specificare {d,v,m} in -e",
			   "av: SDreaddata() fallita",
			   "av: SDselect() fallita",
			   "av: SDendaccess() fallita",
			   "av: SDend() fallita",
			   "av: errore scrivendo file: "};

/* Indici per l'array di messaggi */
#define MSG_USAGE			0
#define MSG_HELP			1
#define MSG_BAD_OPTION		2
#define MSG_BAD_INFILE		3
#define MSG_CANT_OPEN_FILE  4
#define MSG_COMPULSORY_OPT	5
#define MSG_NOT_VALID_OPT	6
#define MSG_MALLOC_FAILED	7
#define MSG_SPECIFY_COMP	8
#define MSG_SPECIFY_DVM		9
#define MSG_SDREAD_FAILED	10
#define MSG_SDSELECT_FAILED	11
#define MSG_SDENDACC_FAILED	12
#define MSG_SDEND_FAILED	13
#define MSG_WRITE_ERROR		14
