/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * ca_cdef.h   "Cellular Automaton Common DEFinitions"
 *
 * Header file per definizioni comuni per il progetto automa cellulare rombododecadrico. 
 *
 */

#include <math.h>
#include <stdint.h>
#include "hdf.h"

#define NUMVECT  12					/* vettori velocita' del modello */
#define NUMRES	 25					/* numero di risorse utilizzabili dall'utente */
#define BUFLEN   256				/* lunghezza buffer di lettura */

#define OBSTACLE  0					/* marcature per i nodi del reticolo */
#define FLUID	  1

#ifndef TRUE
#define TRUE	1					/* le uniche costanti dell'algebra di Boole */
#endif

#ifndef FALSE
#define FALSE 	0
#endif

#define MAX_FILENAME_LEN	256

#define OK		1					/* due codici di ritorno per le funzioni */
#define ERROR	2


/* Il tipo intero usato per effettuare le misurazioni e la scrittura dei risultati.
 * ca usa la #define e il typedef per creare l'<output_file>;
 * fof necessita solo del typedef per leggere l'<output_file> di ca;
 * merge li usa entrambi per fondere gli <output_file> di ca;
 *
 * N.B. La #define e il typedef *devono* rappresentare lo stesso tipo.
 */
#define ENCODE_INT	DFNT_INT16
typedef int16_t 	encodeInt;


/* Lunghezza in bit di un unsigned int. Suppone un byte uguale a 8 bit. */
#define UINTLEN  (sizeof (u_int) * 8)

typedef double eVect[3];			/* un vettore dello spazio euclideo 3D */

/* Il prodotto scalare tra due vettori dello spazio euclideo 3D */
#define DOT_PRODUCT(a, b)     (a[0]*b[0] + a[1]*b[1] + a[2]*b[2])

/* Il modulo di un vettore a 3 componenti */
#define MODULUS(a)	(sqrt(DOT_PRODUCT(a, a)))

/* Ritorna la parola word con il bit di posizione pos al valore value; *assume* il
 * bit value allineato a dx
 */
#define setBit(word, pos, value) 	((value << pos) | (~((unsigned)1 << pos) & word))	

/* I dati di input della simulazione */
typedef struct _simulInData {
		/* Le risorse specificate dall'utente */
		int numCol, numRow, depth;	/* dimensioni del reticolo da elaborare */
		int	numIter;				/* iterazioni della simulazione */
 		int macroCellCol;			/* dimensioni di una macrocella */
 		int macroCellRow;
 		int macroCellDepth;
		int samplingStep;			/* passo di campionamento (numero di iterazioni) */
		int samplePerFrame;			/* numero di campioni per generare un frame */
		int transient;				/* iterazioni del transitorio */
		int injectionIn;			/* il tipo di iniezione da effettuare in ingresso */
		int injectionOut;			/* il tipo di iniezione da effettuare in uscita */
		int latticeStatus;			/* stato iniziale del reticolo */
		int boundaryCond;			/* condizioni al contorno del piano di inserzione */
		int dataCompression;		/* specifica se fare output compresso */
		int firstInjectionRowIn;	/* prima e ultima riga di iniezione in ingresso */
		int lastInjectionRowIn;
		int firstInjectionRowOut;	/* prima e ultima riga di iniezione in uscita */ 
		int lastInjectionRowOut;
		char collTabFileName[BUFLEN]; /* nome del file contenente la tabella delle
									   * collisioni
									   */
		char latticeFileName[BUFLEN]; /* nome del file contenente il reticolo da
									   * elaborare (per nodi ostacolo/fluido)
									   */
		char statusFileName[BUFLEN];  /* nome del file di stato */
		char outFileName[BUFLEN];	  /* nome del file di output */
		char logFileName[BUFLEN];	  /* nome del file di log */
		eVect  u;					/* velocita' delle particelle */
		double n;					/* densita' non ridotta (ovvero 0 < n < 12) */

		/* Questi sono calcolati sulla base dei valori delle risorse */
		int numFrame;				/* numero di frame in output */
	    int numColPE;				/* numero di colonne per ogni PE */
} simulInData;


/* I 12 velocity vectors del modello in coordinate intere */
int e[NUMVECT][3] = {{0,0,2}, {-2,0,0}, {0,0,-2}, {2,0,0}, {-1,-1,1}, {1,1,1},
				   	{-1,1,1}, {1,-1,1}, {1,1,-1}, {-1,-1,-1},
					{1,-1,-1}, {-1,1,-1}};


/* La matrice per trasformare i velocity vectors da coordinate intere a reali */
eVect inverse[3] = {{0.5, 0.0, 0.0},
					{0.0, 0.70710678, 0.0}, 		/* 1/sqrt(2) */
					{0.0, 0.0, 0.5}};


/* Array dei nomi delle risorse: *obstacle* deve sempre restare in fondo!!! */
char *resourceSet[NUMRES] = {"numIter", "numRow", "numCol", "depth", "density",
				 "collTableFile", "speed", "latticeFile", "outFile",
				 "macroCellCol", "macroCellRow", "macroCellDepth", "transient",
				 "samplingStep", "boundaryCondition", "latticeStatus",
				 "samplePerFrame", "dataCompression", "logFile", "injectionAreaIn",
				 "injectionAreaOut", "injectionIn", "injectionOut", "statusFile",
				 "obstacle"};


/* I valori (per l'utente) della risorsa boundaryCondition e relativi indici */
char *boundaryValue[2] = {"periodic", "tunnel"};
#define PERIODIC  0
#define TUNNEL    1


/* Valori (per l'utente) delle risorse injection{In|Out} e relativi indici */
char *injectionValue[3] = {"parabolic", "flat", "none"};
#define PARABOLIC 0
#define FLAT	  1
#define NONE	  2


/* Valori (per l'utente) della risorsa latticeStatus. I primi 2 indici sono gli
 * stessi della risorsa injection.
 */
char *latticeStatusValue[3] = {"parabolicFill", "flatFill", "empty"};
#define EMPTY	2


/* Valori (per l'utente) della risorsa dataCompression. */
char *dataCompValue[2] = {"yes", "no"};
#define YES 0
#define NO  1


/* Indici per identificare le risorse. *NON* cambiare l'ordine!! Se si vuole aggiungere una
 * una risorsa inserirla appena prima dell'ultima (cioe' obstacle).
 * Questo perche' obstacle e' l'unica risorsa opzionale, tutte le altre devono essere
 * obbligatoriamente specificate.
 */
#define RES_NUMITER				0
#define RES_NUMROW				1
#define RES_NUMCOL 				2
#define RES_DEPTH  				3
#define RES_DENSITY				4
#define RES_TABFILE				5
#define RES_SPEED  				6
#define RES_LATFILE				7
#define RES_OUTFILE				8
#define RES_MACRO_COL   		9
#define RES_MACRO_ROW   		10
#define RES_MACRO_DEPTH 		11
#define RES_TRANSIENT   		12
#define RES_SAMPLE_STEP 		13
#define RES_BOUND_COND			14
#define RES_LATTICE_STATUS  	15
#define RES_SAMPLE_PER_FRAME	16
#define RES_DATA_COMPRESSION	17
#define RES_LOGFILE   			18
#define RES_INJECTION_AREA_IN  	19
#define RES_INJECTION_AREA_OUT 	20
#define RES_INJECTION_IN   		21
#define RES_INJECTION_OUT  		22
#define RES_STATUS_FILE  		23
#define RES_OBSTACLE   			24
#define RES_UNKNOWN 			-1
