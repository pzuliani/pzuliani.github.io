/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * ca.h   "Cellular Automaton"
 *
 * Header file per ca_per.c e ca_tun.c.
 *
 */

/* Stampa messaggi su stderr e poi termina il programma */
extern void error (char *format, ...);

/* Cerca una stringa in un dato insieme di stringhe */
extern int searchStr (char **strSet, int strSetDim, char *keyStr);

/* Conta il numero di bit a 1 in word */
extern int bitcount (register unsigned int word);

#define NUMSTATE 4096					/* possibili configurazioni di un nodo */

#ifdef _CRAYMPP
#define PLANES_PER_BUFFER 5				/* i PE si spediscono 5 piani ad ogni iterazione */
#endif

/* due macro fondamentali per realizzare la propagazione */
#define getFirstBit(word)   (word << (UINTLEN - 1))		/* ritorna il MSB allineato a sx */
#define getLastBit(word)    (word >> (UINTLEN - 1))		/* ritorna il LSB allienato a dx */


/* ritorna (allineato a dx) il bit di posizione pos di word */
#define getBit(word, pos)			((word >> pos) & (unsigned)1)


/* Messaggi vari per l'utente */
char thisPE[20];				/* stringa da appendere ai msg di errore. Usata solo
								   sui sistemi CRAY MPP */

char *msg[] = {"Motore automa cellulare rombododecaedrico.\nUso: ca [-h] <resource_file>\n\
Usa -h per avere un ulteriore aiuto.",
			   "ca: non posso leggere numero di collisioni da colltable_file",
			   "ca: errore leggendo colltable_file",
			   "ca: non posso aprire ",
			   "ca: resource_file errato, usare crcf",
			   "ca: errore leggendo lattice_file, usare crcf",
			   "ca: shmalloc() fallita",
			   "ca: ATTENZIONE E' NECESSARIO RICOMPILARE! Fare make error",
			   "ca: SDwritedata() fallita",
			   "ca: malloc() fallita",
			   "ca: SDcreate() fallita",
			   "ca: SDendaccess() fallita",
			   "ca: SDsetcompress() fallita",
			   "ca: SDselect() fallita",
			   "ca: SDend() fallita",
			   "ca: SDstart() fallita",
			   "ca: fseek() fallita",
			   "Motore automa cellulare rombododecaedrico.\nUso: ca [-h] <resource_file>\n\
Commenti:\n\
   <resource_file>: file di risorse;\n\n\
   ca riconosce (dal <resource_file>) le seguenti risorse *obbligatorie*:\n\
     - numRow, numCol, depth:\n\
          dimensioni del reticolo elaborato da ca;\n\
          depth deve essere un multiplo della lunghezza di un unsigned int;\n\
     - numIter: numero di iterazioni della simulazione;\n\
     - samplingStep: passo di campionamento;\n\
     - samplePerFrame: numero di campioni per frame;\n\
     - transient: durata del transitorio (in iterazioni);\n\
     - dataCompression: {yes | no}\n\
          specifica se si vuole l'output compresso;\n\
     - outFile: nome del file di output generato da ca;\n\
     - density: densita' di particelle (tra 0 e 12);\n\
     - speed: velocita' del fluido (elencare le componenti x, y e z);\n\
     - latticeFile: nome del file di reticolo (specifica i nodi ostacolo/fluido);\n\
     - latticeStatus: {flatFill | parabolicFill | empty}\n\
          inizializzazione del reticolo alla partenza della simulazione;\n\
     - collTableFile: nome del file contenente la tabella di collisione;\n\
     - logFile: nome del file di log;\n\
     - injectionAreaIn:\n\
          area di iniezione all'ingresso del fluido;\n\
          elencare la prima e ultima riga di iniezione; la prima riga ha indice 0;\n\
     - injectionAreaOut:\n\
          area di iniezione all'uscita del fluido;\n\
          elencare la prima e ultima riga di iniezione; la prima riga ha indice 0;\n\
     - injectionIn: {flat | parabolic | none}\n\
          tipo di iniezione all'ingresso del fluido;\n\
     - injectionOut: {flat | parabolic | none}\n\
          tipo di iniezione all'uscita del fluido;\n"};

/* indici per l'array dei messaggi utente */
#define MSG_USAGE 			   0
#define MSG_CANT_READ_NUMCOLL  1
#define MSG_BAD_COLLTABLE_FILE 2
#define MSG_CANT_OPEN_FILE	   3
#define MSG_BAD_RESOURCE_FILE  4
#define MSG_BAD_LATTICE_FILE   5
#define MSG_SHMALLOC_FAILED    6
#define MSG_NEED_TO_RECOMPILE  7
#define MSG_SDWRITE_FAILED	   8
#define MSG_MALLOC_FAILED	   9
#define MSG_SDCREATE_FAILED	   10
#define MSG_SDENDACCESS_FAILED 11
#define MSG_SDSETCOMP_FAILED   12
#define MSG_SDSELECT_FAILED    13
#define MSG_SDEND_FAILED       14
#define MSG_SDSTART_FAILED     15
#define MSG_FSEEK_FAILED	   16
#define MSG_HELP 			   17
