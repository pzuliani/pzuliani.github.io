/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * crcf.h   "Check ResourCe File"
 *
 * Header file per crcf.c.
 *
 */


/* Cerca una stringa in un dato insieme di stringhe */
extern int searchStr (char **strSet, int strSetDim, char *keyStr);

/* Ritorna la lunghezza di un file */
extern long fsize (char *fileName);

/* Stampa messaggi su stderr e poi termina il programma */
extern void error (char *format, ...);


/* Struttura per definire un ostacolo nel reticolo */
typedef struct {
  u_int firstRow,
		firstDepth,
		lastRow,
		lastDepth,
		firstCol,
		lastCol;
} obstacle;

/* messaggi vari per l'utente */
char *msg[] = {"Controlla la validita' del <resource_file>.\nUso: crcf [-h] <resource_file>\nUsa -h per avere un ulteriore aiuto.",
			   "crcf: non posso aprire ",
			   "crcf: linea",
			   "formato resource_file errato",
			   "risorsa sconosciuta:",
			   "errore I/O",
			   "valore risorsa errato",
			   "crcf: risorsa non specificata:",
			   "risorsa gia' specificata",
			   "crcf: valore densita' errato (0<density<12)",
			   "crcf: modulo velocita' maggiore di 1",
			   "crcf: dimensione <lattice_file> non corrispondente",
			   "crcf: valore risorsa depth non multiplo di u_int",
			   "crcf: dimensione macro cella non congruente",
			   "crcf: transitorio troppo grande",
			   "crcf: intervallo di campionamento non congruente",
			   "crcf: ostacolo",
			   "definizione errata: colonne",
			   "definizione errata: righe",
			   "definizione errata: profondita'",
			   "crcf: numero di campioni per frame non congruente",
			   "crcf: area di iniezione ingresso errata",
			   "crcf: area di iniezione uscita errata",
			   "crcf: probabilita' minore di 0 per vettore",
			   "crcf: probabilita' maggiore di 1 per vettore",
			   "Controlla la validita' del <resource_file>.\nUso: crcf [-h] <resource_file>\n\
Commenti:\n\
   <resource_file>: il file di risorse della simulazione;\n\n\
   crcf controlla che tutte le risorse obbligatorie siano state specificate e abbiano\n\
   dei valori che non diano luogo ad incongruenze.\n\n\
   crcf riconosce come *obbligatorie* le seguenti risorse:\n\
     - numRow, numCol, depth:\n\
          dimensioni del reticolo elaborato da ca;\n\
          depth deve essere un multiplo della lunghezza di un unsigned int;\n\n\
     - numIter: numero di iterazioni della simulazione;\n\n\
     - samplingStep: passo di campionamento;\n\n\
     - samplePerFrame: numero di campioni per frame;\n\n\
     - transient: durata del transitorio (in iterazioni);\n\n\
     - dataCompression: {yes | no}\n\
          specifica se si vuole l'output compresso;\n\n\
     - outFile: nome del file di output generato da ca;\n\n\
     risorse specifiche di ca:\n\
        - density:\n\
             densita' di particelle (tra 0 e 12);\n\n\
        - speed:\n\
             velocita' del fluido (elencare le componenti x, y e z);\n\n\
        - latticeFile:\n\
             nome del file di reticolo (specifica i nodi ostacolo/fluido);\n\n\
        - latticeStatus: {flatFill | parabolicFill | empty}\n\
             inizializzazione del reticolo alla partenza della simulazione;\n\n\
        - collTableFile:\n\
             nome del file contenente la tabella di collisione;\n\n\
        - logFile:\n\
             nome del file di log;\n\n\
        - injectionAreaIn:\n\
             area di iniezione all'ingresso del fluido;\n\
             elencare la prima e ultima riga di iniezione; la prima riga ha indice 0;\n\n\
        - injectionAreaOut:\n\
             area di iniezione all'uscita del fluido;\n\
             elencare la prima e ultima riga di iniezione; la prima riga ha indice 0;\n\n\
        - injectionIn: {flat | parabolic | none}\n\
             tipo di iniezione all'ingresso del fluido;\n\n\
        - injectionOut: {flat | parabolic | none}\n\
             tipo di iniezione all'uscita del fluido;\n\n\
     risorse specifiche di glf:\n\
        - boundaryCondition: {tunnel | periodic}\n\
             tunnel = un reticolo con contorno di nodi ostacolo (cioe' un 'tubo');\n\
             periodic = un reticolo di soli nodi fluido;\n\n\
     risorse specifiche di fof:\n\
        - macroCellRow, macroCellCol, macroCellDepth:\n\
             dimensioni della macrocelle da elaborare;\n\n\
   la seguente risorsa e' *opzionale* e riguarda solo glf:\n\
     - obstacle: permette la definizione di un ostacolo nella seguente forma:\n\
          firstRow firstDepth lastRow lastDepth firstCol lastCol\n\
		  dove firstRow, etc.. sono tutti numeri interi compresi tra 0 e\n\
		  dimensione corrispondente del reticolo meno 1.\n"};


/* indici per l'array dei messaggi utente */
#define USAGE 			     	0
#define CANT_OPEN_FILE	     	1
#define MSG_HEADER		     	2
#define BAD_RESOURCE_FILE    	3
#define UNKNOWN_RESOURCE      	4
#define IOERROR			     	5
#define BAD_RESOURCE_VALUE   	6
#define UNSPEC_RESOURCE	     	7
#define ALREADY_SET_RESOURCE 	8	 
#define BAD_DENSITY_VALUE	 	9
#define BAD_SPEED_VALUE			10
#define BAD_LATTICE_FILE		11
#define BAD_DEPTH_VALUE			12
#define BAD_MACRO_DIM			13
#define BAD_TRANSIENT			14
#define BAD_SAMPLE_STEP			15
#define BAD_OBSTACLE_HDR 		16
#define BAD_OBSTACLE_COL 		17
#define BAD_OBSTACLE_ROW 		18
#define BAD_OBSTACLE_DEPTH 		19
#define BAD_SAMPLE_PER_FRAME	20
#define BAD_INJECTION_AREA_IN	21
#define BAD_INJECTION_AREA_OUT	22
#define PROBABILITY_TOO_SMALL	23
#define PROBABILITY_TOO_BIG		24
#define HELP 			     	25
