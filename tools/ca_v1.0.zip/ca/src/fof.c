/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * fof.c	"Filter Output File"
 *
 * Filtro per l'output_file prodotto da ca: estrae i microrisultati ed effettua le
 * medie su macrocelle.
 *
 * Simboli definibili:
 *
 *		USE_DFSD_INTERFACE
 * L'interfaccia SD ha ancora qualche problema. Uso interfaccia SD in lettura, DFSD in scrittura.
 * Quando SD sara' Ok bastera' togliere la #define oppure togliere gli #ifdef con il preprocessore,
 * dato che sara' l'interfaccia SD ad essere usata in futuro.
 *
 *		DEBUG
 * Ogni funzione scrive il proprio nome su stdout quando viene chiamata.
 */

#define USE_DFSD_INTERFACE


#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>

#include "mfhdf.h"
#include "ca_cdef.h"
#include "fof.h"

FILE *error_logfile;


/*
 * Semplice parsing della linea di comando.
 *
 * Input:
 *		int argc, char *argv[]: i soliti noti...
 *		optionRec *optRecPtr: le opzioni dell'utente;
 *
 * Note:
 *		se si verifica un errore nella lettura delle risorse emette un msg di errore e
 *		termina il programma.
 */
void parseCommandLine (int argc, char *argv[], optionRec *optRecPtr)
{
  extern int opterr;
  char opt;

#ifdef DEBUG
  printf (": parseCommandLine()\n");
#endif

  opterr = 0;					/* cosi' getopt() non segnala errori all'utente */

  while ((opt = getopt (argc, argv, "hd")) != -1)

	switch (opt) {

	  /* Richiesta di aiuto */
	  case 'h':
		printf ("%s\n", msg[HELP]);
		exit (1);

	  /* "Duplicazione" dei frame */
	  case 'd':
		optRecPtr->doubleFrame = TRUE;
		break;

	  default:
		goto end_parsing;
	}

end_parsing:
  if (argc < 3)
	error ("%s\n", msg[USAGE]);

  strcpy (optRecPtr->rc_file, argv[optind]);
  strcpy (optRecPtr->fofOutFileName, argv[optind+1]);
}


/*
 * Carica un macro piano di risultati della simulazione dall'output file prodotto da ca.
 *
 * Input:
 *		int32 sds_id: DataSet da cui leggere;
 *		encodeInt *i_buf[]: buffer dove scaricare i risultati microscopici.
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 *		numMacroPlane: l'indice del macropiano da caricare (primo e' 0);
 *
 */
void loadMacroPlane (int32 sds_id, encodeInt *i_buf[], macroDataRec *macroRecPtr, int numMacroPlane)
{
  static char *funName = ": loadMacroPlane()";

  int32 start[1], edge[1];
  register int i;
  static encodeInt *buf = NULL;								/* buffer di lettura */
  register encodeInt *p;									/* per sveltire gli accessi a memoria */

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  edge[0] = macroRecPtr->macroPlaneDimNode * 4;

  /* Alla prima chiamata alloca un buffer di lettura */
  if (buf == NULL) {
	buf = (encodeInt *) malloc (sizeof (encodeInt) * edge[0]);
	if (buf == NULL)
	  error ("%s %s\n", msg[MALLOC_FAILED], funName);
  }

  /* Si posiziona all'inizio del macropiano da leggere */
  start[0] = numMacroPlane * macroRecPtr->macroPlaneDimNode * 4;

  /* Legge i microrisultati */
  if (SDreaddata (sds_id, start, NULL, edge, (VOIDP) buf) == FAIL)
	error ("%s %s\n", msg[SDREAD_FAILED], funName);

  /* Separa le quantita' appena lette */
  for (i = 0, p = buf; i < macroRecPtr->macroPlaneDimNode; i++) {

	i_buf[D_BUF][i] = *p++;								/* densita' */
	i_buf[X_BUF][i] = *p++;								/* componenti della q.di moto */
	i_buf[Y_BUF][i] = *p++;
	i_buf[Z_BUF][i] = *p++;
  }
}


/*
 * Medie spazio-temporali per densita' e velocita' per un frame di dati.
 *
 * Input:
 *		encodeInt *i_buf[]: i micro risultati;
 *		float64 *o_buf[]: buffer per i macro risultati (ovvero le medie spazio-temporali);
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 *
 */
void doAverage (encodeInt *i_buf[], float64 *o_buf[], simulInData *simRecPtr, macroDataRec *macroRecPtr)
{
  int planeDim,							/* dimensione di un piano (in nodi) */
	  base;
  register u_int j, k, x,				/* un po' di contatori */
				w, y,
				count,
				pos;
  int totalSample;						/* numero totale di campioni (nel tempo e nello spazio) per 
										 * una macrocella
										 */
  int32 	tmp[4];

#ifdef DEBUG
  printf (": doAverage()\n");
#endif

  planeDim = simRecPtr->numRow * simRecPtr->depth;
  totalSample = macroRecPtr->macroCellDim * simRecPtr->samplePerFrame;
  count = 0;

  /***************************************************/
  /* Media spaziale per le macrocelle del macropiano */
  /***************************************************/
  for (k = 0; k < macroRecPtr->numMacroRow; k++) {
	for (j = 0; j < macroRecPtr->macroDepth; j++, count++) {

	  /* Punta all'inizio dei risultati per la macrocella k, j */
	  base = k * simRecPtr->depth * simRecPtr->macroCellRow +
		  j * simRecPtr->macroCellDepth;

	  /* Azzera buffer temporaneo */
	  memset (tmp, 0, sizeof (int32) * 4);

	  /*************************************************************/
	  /* Media spaziale per la macrocella k, j (riga, profondita') */
	  /*************************************************************/
	  for (w = 0; w < simRecPtr->macroCellCol; w++) {

		/* Posizioni d'inizio delle macrocolonne */
		pos = base + w * planeDim;

		/* Effettua la somma per righe */
		for (y = 0; y < simRecPtr->macroCellRow; y++) {

		  /* Somma tutti gli elementi della riga */
		  for (x = pos; x < pos + simRecPtr->macroCellDepth; x++) {
			  tmp[D_BUF] += i_buf[D_BUF][x];
			  tmp[X_BUF] += i_buf[X_BUF][x];
			  tmp[Y_BUF] += i_buf[Y_BUF][x];
			  tmp[Z_BUF] += i_buf[Z_BUF][x];
		  }

		  /* Inizio della prossima riga della macrocella */
		  pos += simRecPtr->depth;
		}
	  }

	  /* Calcolo valore macroscopico densita' */
	  o_buf[D_BUF][count] = tmp[D_BUF] / (float64) totalSample;

	  /* Le tre componenti della velocita' */
	  for (x = X_BUF; x <= Z_BUF; x++)

		/* Oppure: o_buf[D_BUF][count] == 0.0, ma forse e' meglio lavorare su interi */
		if (tmp[D_BUF] == 0)
		  o_buf[x][count] = 0.0;
		else
		  /* Converte anche da coordinate intere a reali */
	  	  o_buf[x][count] = (DOT_PRODUCT ((tmp+1), inverse[x-1]) / totalSample) / o_buf[D_BUF][count];

	}
  }
}


/*
 * Legge i valori delle risorse dal <resource_file>.
 *
 * Input:
 *		simulInData *simRecPtr: puntatore al record dove verranno memorizzati i valori letti;
 *		char *fileName: nome del <resource_file>.
 *
 */
void readResourceFile (simulInData *simRecPtr, char *fileName)
{
  char *funName = ": readResourceFile()";

  FILE *fp;
  int  resource,										/* indice di risorsa */
	   inputError = FALSE;									/* segnala errore di input */
  char *buf,
	   dummy[BUFLEN],
	   inBuf[BUFLEN],									/* buffer di lettura */
	   resName[BUFLEN];									/* nome di una risorsa */

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Apre il resource_file */
  if ((fp = fopen (fileName, "r")) == NULL)
	error ("%s '%s' %s\n", msg[CANT_OPEN_FILE], fileName, funName);

  /* Lettura del resource_file per linee */
  while ((fgets (buf = inBuf, BUFLEN, fp) != NULL) && (!inputError)) {

	/* Salta commenti e linee vuote */
	if ((*buf == '#') || (*buf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
	if (sscanf (buf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  inputError = TRUE;
	  break;
	}

	while (*buf++ != ':');					/* si sposta sul valore della risorsa */

	/* Cerca la risorsa nell'insieme delle risorse e memorizza il relativo valore nel
	 * record dei parametri.
	 */
	switch (resource = searchStr (resourceSet, NUMRES, resName)) {
	  case RES_NUMITER:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numIter) == 0);
					break;
	  case RES_NUMROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numRow) == 0);
					break;
	  case RES_NUMCOL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numCol) == 0);
					break;
	  case RES_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->depth) == 0);
					break;
	  case RES_MACRO_COL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->macroCellCol) == 0);
					break;
	  case RES_MACRO_ROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->macroCellRow) == 0);
					break;
	  case RES_MACRO_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->macroCellDepth) == 0);
					break;
	  case RES_SAMPLE_STEP:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplingStep) == 0);
					break;
	  case RES_SAMPLE_PER_FRAME:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplePerFrame) == 0);
					break;
	  case RES_TRANSIENT:
					inputError = (sscanf (buf, " %d ", &simRecPtr->transient) == 0);
					break;
	  case RES_DATA_COMPRESSION:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;

					/* Cerca di assegnare il valore alla risorsa */
					if ((simRecPtr->dataCompression = searchStr (dataCompValue, 2, dummy)) == RES_UNKNOWN)
					  inputError = TRUE;

				    break;
	  case RES_OUTFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->outFileName) == 0);
					break;
	  case RES_UNKNOWN:
					inputError = TRUE; break;
	  default:										/* salta le risorse che non servono */
					inputError = FALSE;
	}
  }

  /* Se uscendo dal ciclo non e' EOF allora si e' verificato un errore */
  if (!feof (fp) || inputError) {
	fclose (fp);
	error ("%s\n", msg[BAD_RESOURCE_FILE]);
  }
  fclose (fp);
}


/*
 * Scrive un piano di macrorisultati in un buffer di scrittura. 
 *
 * Input:
 *		float64 *o_buf[]: i risultati da scrivere;
 *		float64 *buf: buffer in cui scrivere;
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 *		int numPlane: indice del macropiano (primo e` 0);
 *
 * Note:
 *		questa funzione decide la struttura del file di output: un singolo dataset contiene in 
 *		sequenza un frame di risultati per la densita' e tre frame per le componenti della q. di moto
 *		(x, y, z).
 *
 */
void writeMacroPlane (float64 *o_buf[], float64 *buf, macroDataRec *macroRecPtr, int numPlane)
{
  int i,
	frameDim;						/* lunghezza di un frame di macrorisultati di una quantita' */

#ifdef DEBUG
  printf (": writeMacroPlane()\n");
#endif

  frameDim = macroRecPtr->macroPlaneDim * macroRecPtr->numMacroCol;

  /* Si posiziona per la prima scrittura */
  buf += numPlane * macroRecPtr->macroPlaneDim;

  for (i = 0; i < 4; i++, buf += frameDim)
	memmove (buf, o_buf[i], sizeof (float64) * macroRecPtr->macroPlaneDim);
}


/*
 * Appende un nuovo DataSet al file di output.
 *
 * Input:
 *		float64 *block: puntatore al blocco di dati;
 *		int blockLen: lunghezza del blocco (in float64);
 *		int32 sd_id: scientific data ID;
 *		int compression: se si desidera o meno la compressione dei dati;
 *
 * Note:
 *		gestisce direttamente le situazioni di errore.
 *
 */
#ifdef USE_DFSD_INTERFACE
void appendData (float64 *block, int blockLen, char *fileName)
#else
void appendData (float64 *block, int blockLen, int32 sd_id, int compression)
#endif
{
  static char *funName = ": appendData()";

  int32 start[1], 						/* gli indici da cui iniziare a scrivere */
		dim[1];							/* dimensioni dell'array */
#ifndef USE_DFSD_INTERFACE
  int32 sds_id;							/* Scientific Data Set (SDS) ID */
  comp_info c_info;						/* info sulla compressione da adottare */
#endif

  /* Inizializzazioni */
  dim[0] = blockLen;
  start[0] = 0;

#ifdef USE_DFSD_INTERFACE

  if (DFSDadddata (fileName, 1, dim, (VOIDP) block) == FAIL)
	error ("%s %s\n", msg[SDWRITE_FAILED], funName);

#else

  /* Crea un SDS per tutto l'array */
  if ((sds_id = SDcreate (sd_id, "Pippo", DFNT_FLOAT64, 1, dim)) == FAIL)
	error ("%s %s\n", msg[SDCREATE_FAILED], funName);

  /* Configura l'SDS per la compressione, se lo si desidera */
  if (compression == YES) {
	c_info.deflate.level = 1;
	if (SDsetcompress (sds_id, COMP_CODE_DEFLATE, &c_info) == FAIL)
	  error ("%s %s\n", msg[SDSETCOMP_FAILED], funName);
  }

  /* Scrittura su file */
  if (SDwritedata (sds_id, start, NULL, dim, (VOIDP) block) == FAIL) {
	SDendaccess (sds_id);
	SDend (sd_id);
	error ("%s %s\n", msg[SDWRITE_FAILED], funName);
  }

  /* Libera la memoria occupata dal Data Object */
  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[SDENDACCESS_FAILED], funName);

#endif
}


/*
 * Elaborazione di un frame: caricamento, calcolo medie, scrittura su file.
 *
 * Input:
 *		encodeInt *i_buf[]: buffer per la lettura di microrisultati;
 *		float64 *o_buf[]: buffer per la scrittura di *macro* risultati;
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 *		int32 infile: file id per l'<output_file> di ca;
 *
 */
void processFrame (encodeInt *i_buf[], float64 *o_buf[], int32 infile, optionRec *optRecPtr,
				   macroDataRec *macroRecPtr, simulInData *simRecPtr)
{
  static char *funName = ": processFrame()";

  register int i;
  int32 input_sds;
  static uint16 index = 1;				/* il primo frame e' nel dataset 1 */
  int32 frameLen;						/* lunghezza totale del frame (in float64) */

  static float64 *writeBuf[2] = {NULL, NULL};		/* buffer per contenere un intero frame di risultati per le
													 * 4 quantita'
										 			 */
  static int z = 0;									/* indice del buffer libero */

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Crea un access ID all'<output_file> di ca: punta al primo frame */
  if ((input_sds = SDselect (infile, index)) == FAIL)
	error ("%s %s\n", msg[SDSELECT_FAILED], funName);

  frameLen = macroRecPtr->macroPlaneDim * macroRecPtr->numMacroCol * 4;

  /* Alloca i buffers solo la prima volta */
  if (writeBuf[0] == NULL) {

	if ((writeBuf[0] = (float64 *) malloc (sizeof (float64) * frameLen)) == NULL)
	  error ("%s %s\n", msg[MALLOC_FAILED], funName);

	/* Alloca il secondo buffer solo se e` stata richiesta la duplicazione dei frame */
	if (optRecPtr->doubleFrame)
	  if ((writeBuf[1] = (float64 *) malloc (sizeof (float64) * frameLen)) == NULL)
		error ("%s %s\n", msg[MALLOC_FAILED], funName);
  }

  /* Elabora un macropiano alla volta */
  for (i = 0; i < macroRecPtr->numMacroCol; i++) {

	/* Carica un macropiano di risultati della simulazione dall'<output_file> di ca,
	 * separando densita` e velocita`.
	 */
	loadMacroPlane (input_sds, i_buf, macroRecPtr, i);

	/* Calcolo delle medie spaziali e temporali */
	doAverage (i_buf, o_buf, simRecPtr, macroRecPtr);

	/* Scrive il macropiano nel buffer di scrittura */
	writeMacroPlane (o_buf, writeBuf[0], macroRecPtr, i);
  }

  if (SDendaccess (input_sds) == FAIL)
	error ("%s %s\n", msg[SDENDACC_FAILED], funName);

  /* Devo duplicare i frame? */
  if (optRecPtr->doubleFrame && (index > 1)) {
	register double *p, *q;

	p = writeBuf[!z];
	q = writeBuf[z];

	/* Calcola il frame dummy */
	for (i = 0; i < frameLen; i++, p++)
	  *p = (*p + *q++) / 2.0;

	/* Scrive il frame dummy su file */
#ifdef USE_DFSD_INTERFACE
	appendData (writeBuf[!z], frameLen, optRecPtr->fofOutFileName);
#else
	appendData (writeBuf[!z], frameLen, optRecPtr->fofOutFile, simRecPtr->dataCompression);
#endif
  }

  /* Scrittura su file del buffer di scrittura */
#ifdef USE_DFSD_INTERFACE
  appendData (writeBuf[0], frameLen, optRecPtr->fofOutFileName);
#else
  appendData (writeBuf[0], frameLen, optRecPtr->fofOutFile, simRecPtr->dataCompression);
#endif

  if (optRecPtr->doubleFrame)
	z = !z;								/* se non c'e' duplicazione z e' sempre 0 */

  index++;								/* indice del prossimo frame */
}


/*
 * Il nome e' abbastanza esplicativo...
 *
 * Input:
 *		int32 outfile: file ID per l'<output_file> di ca;
 *		optionRec *optRecPtr: opzioni dell'utente;
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 *
 */
void  doItAll (int32 outfile, optionRec *optRecPtr, macroDataRec *macroRecPtr, simulInData *simRecPtr)
{
  char *funName = ": doItAll()";

  int  i;
  encodeInt *i_buf[4];				/* buffer di lettura: 1 per densita', 3 per velocita' */
  float64 *o_buf[4];				/* buffer di scrittura : 1 per densita', 3 per velocita' */

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

#ifdef USE_DFSD_INTERFACE

  if (DFSDsetNT (DFNT_FLOAT64) == FAIL)
	error ("%s %s\n", msg[SDSELECT_FAILED], funName);

  {
  int32 dim[1];

  dim[0] = macroRecPtr->macroPlaneDim * macroRecPtr->numMacroCol * 4;

  if (DFSDsetdims (1, dim) == FAIL)
	error ("%s %s\n", msg[SDCREATE_FAILED], funName);
  }

#endif

  /* Allocazione memoria per i buffer */
  for (i = 0; i < 4; i++) {
	/* Micro risultati */
	if ((i_buf[i] = (encodeInt *) malloc (sizeof (encodeInt) * macroRecPtr->macroPlaneDimNode)) == NULL)
	  error ("%s %s\n", msg[MALLOC_FAILED], funName);

	/* Macro risultati */
  	if ((o_buf[i] = (float64 *) malloc (macroRecPtr->macroPlaneDim * sizeof (float64))) == NULL)
	  error ("%s %s\n", msg[MALLOC_FAILED], funName);
  }

  /* Elaborazione di un frame alla volta */
  for (i = 0; i < simRecPtr->numFrame; i++)
	processFrame (i_buf, o_buf, outfile, optRecPtr, macroRecPtr, simRecPtr);

  /* Fine: deallocazione strutture dati */
  for (i = 0; i < 4; i++) {
	free (i_buf[i]);
	free (o_buf[i]);
  }
}


/*
 * Apertura files di I/O.
 *
 * Input:
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		char *fofOutFileName: nome file di output di fof;
 *
 * Output:
 *		(per indirizzo)
 *		int32 *outFile, *fofOutFile: HDF ID per i file di output di ca e di fof.
 */
#ifdef USE_DFSD_INTERFACE
void openFiles (int32 *outFile, simulInData *simRecPtr)
#else
void openFiles (int32 *outFile, simulInData *simRecPtr, optionRec *optRecPtr)
#endif
{
  char *funName = ": openFiles()";

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Apre l'<output_file> prodotto da ca. Prima controlla se e' un file HDF valido */
  if (Hishdf (simRecPtr->outFileName)) {
	if ((*outFile = SDstart (simRecPtr->outFileName, DFACC_READ)) == FAIL)
	  error ("%s '%s' %s\n", msg[SDSTART_FAILED], simRecPtr->outFileName, funName);
  }
  else
	error ("%s\n", msg[BAD_OUTPUT_FILE]);

#ifndef USE_DFSD_INTERFACE
  /* Apre file di output per fof */
  if ((optRecPtr->fofOutFile = SDstart (optRecPtr->fofOutFileName, DFACC_CREATE)) == FAIL)
	error ("%s '%s'\n", msg[SDSTART_FAILED], fofOutFileName);
#endif
}


/*
 * Inizializzazioni varie.
 *
 * Input:
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 */
void init (macroDataRec *macroRecPtr, simulInData *simRecPtr)
{
  div_t dummy;
  int numSample;

#ifdef DEBUG
  printf (": init()\n");
#endif

  macroRecPtr->numMacroRow = simRecPtr->numRow / simRecPtr->macroCellRow;
  macroRecPtr->numMacroCol = simRecPtr->numCol / simRecPtr->macroCellCol;
  macroRecPtr->macroDepth = simRecPtr->depth / simRecPtr->macroCellDepth;
  macroRecPtr->macroPlaneDim = macroRecPtr->numMacroRow * macroRecPtr->macroDepth;
  macroRecPtr->macroCellDim = simRecPtr->macroCellRow * simRecPtr->macroCellCol * simRecPtr->macroCellDepth;
  macroRecPtr->macroPlaneDimNode = macroRecPtr->macroPlaneDim * macroRecPtr->macroCellDim;

  /* Calcola il numero di frame presenti nel file di output di ca */
  dummy = div (simRecPtr->numIter - simRecPtr->transient, simRecPtr->samplingStep);
  numSample = dummy.quot;
  dummy = div (numSample, simRecPtr->samplePerFrame);

  simRecPtr->numFrame = dummy.quot;
}


/*
 * Controlla la validita' dell'output file di ca.
 *
 * Input:
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		int32 outFile: ID del file;
 */ 
void checkOutFile (int32 outfile, simulInData *simRecPtr)
{
  char *funName = ": checkOutFile()";

  int32 sds_id;
  int32 start[1], edge[1];
  encodeInt	info[4];

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Il primo DataSet contiene un header informativo */
  if ((sds_id = SDselect (outfile, 0)) == FAIL)
	error ("%s\n", msg[SDSELECT_FAILED]);

  /* Legge il DataSet */
  start[0] = 0;
  edge[0] = 4;
  if (SDreaddata (sds_id, start, NULL, edge, (VOIDP) info) == FAIL)
	error ("%s %s\n", msg[SDREAD_FAILED], funName);

  /* Controlla la lunghezza del frame */
  if ((info[0] != simRecPtr->numRow) || (info[1] != simRecPtr->numCol) || 
	(info[2] != simRecPtr->depth))
	error ("%s\n", msg[BAD_FRAME_DIM]);

  /* Controlla il numero di frame */
  if (info[3] != simRecPtr->numFrame)
	error ("%s\n", msg[BAD_FRAME_NUM]);

  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[SDENDACC_FAILED], funName);
}


/*
 * Scrive un header informativo all'inizio di <fof_output_file>.
 *
 * Input:
 *		macroDataRec *macroRecPtr: info sulle macrocelle;
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		optionRec *optRecPtr: opzioni dell'utente;
 */
void writeHeader (optionRec *optRecPtr, simulInData *simRecPtr, macroDataRec *macroRecPtr)
{
  char *funName = ": writeHeader()";

  int32 header[4];
  int32 edge[1];

#ifndef USE_DFSD_INTERFACE
  int32 start[1];
  int32 sds_id;

  start[0] = 0;
#endif

  edge[0] = 4;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Header contenente le dimensioni dei successivi frame e loro numero */
  header[0] = macroRecPtr->numMacroCol;
  header[1] = macroRecPtr->numMacroRow;
  header[2] = macroRecPtr->macroDepth;

  if (optRecPtr->doubleFrame)
	header[3] = 2*simRecPtr->numFrame - 1;
  else
	header[3] = simRecPtr->numFrame;

#ifdef USE_DFSD_INTERFACE

  if (DFSDsetNT (DFNT_INT32) == FAIL)
	error ("%s %s\n", msg[SDSELECT_FAILED], funName);

  if (DFSDputdata (optRecPtr->fofOutFileName, 1, edge, (VOIDP) header) == FAIL)
	error ("%s %s\n", msg[SDWRITE_FAILED], funName);

#else

  /* Crea il dataset */
  if ((sds_id = SDcreate (optRecPtr->fofOutFile, "Pippo", DFNT_INT32, 1, edge)) == FAIL)
	error ("%s %s\n", msg[SDCREATE_FAILED], funName);

  /* Scrittura */
  if (SDwritedata (sds_id, start, NULL, edge, (VOIDP) header) == FAIL)
	error ("%s %s\n", msg[SDWRITE_FAILED], funName);

  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[SDENDACC_FAILED], funName);

#endif
}


void main (int argc, char *argv[])
{
  int32 outFile;					/* l'output_file generato da ca */

  macroDataRec macroRec;			/* info sulle macrocelle */
  simulInData simRec;				/* parametri della simulazione */
  optionRec optRec;					/* opzioni dell'utente */

  optRec.doubleFrame = FALSE;

  /* Cosi' error() scrive su stderr */
  error_logfile = stderr;

  /* Parsing della linea di comando */
  parseCommandLine (argc, argv, &optRec);

  /* Legge il <resource_file> */
  readResourceFile (&simRec, optRec.rc_file);

  /* Inizializzazione di alcuni parametri */
  init (&macroRec, &simRec);

  /* Apertura files */
#ifdef USE_DFSD_INTERFACE
  openFiles (&outFile, &simRec);
#else
  openFiles (&outFile, &simRec, &optRec);
#endif

  /* Controllo dell'output file di ca */
  checkOutFile (outFile, &simRec);

  /* Scrive un piccolo header informativo */
  writeHeader (&optRec, &simRec, &macroRec);

  /* Lettura di <output_file>, calcolo delle medie e scrittura su file */
  doItAll (outFile, &optRec, &macroRec, &simRec);

  /* Fine lavoro */
#ifndef USE_DFSD_INTERFACE
  SDend (optRec.fofOutFile);
#endif
  SDend (outFile);
}
