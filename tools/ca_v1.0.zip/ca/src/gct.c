/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * gct.c	"Generate Collision Table"
 *
 * Genera automaticamente la tabella delle collisioni dell'automa cellulare
 * rombododecaedrico a partire dal <collision_file> generato da gc.
 *
 * L'output e' su stdout.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>

/* Inverte una stringa di len caratteri */
extern void reverse (char str[], int len);		

/* Stampa messaggi su stderr ed esce */
extern void error (char *format, ...);

FILE *error_logfile;

typedef struct _collRec {				/* identifica una classe di collisioni */
			int dim,					/* dimensione delle classe */
				numPart;				/* numero di particelle coinvolte */
			char **store;
		} collRec;

#define NUMVECT  12						/* 12 sono i velocity vectors */
#define NUMSTATE 4096					/* i possibili stati di un nodo */ 
#define BUFLEN   100

#define MAX(a, b)	((a) > (b) ? (a) : (b))		/* cosi' come sul K&R */


char *msg = "\nGenerazione tabella delle collisioni dell'automa cellulare rombododecaedrico\n";

char *usage = "Uso: gct <collision_file>\nL'output e' su stdout.\n";

/*
 * Converte da binario a intero.
 *
 * Input: la stringa binaria allineata a destra (LSB a dx) e relativa lunghezza.
 * 
 * Output: l'intero corrispondente.
 *
 * Note: converte solo in interi positivi. 
 */
u_int btoi (char binStr[], int dim)
{
  register u_int pow = 1, result = 0;
  register int i;

  for (i = dim - 1; i >= 0; i--) { 
	 if (binStr[i] == '1')
	 	result += pow;
	 pow <<= 1;
  }

  return (result);
}


/*
 * Generazione del mintermine a partire dalle collisioni generate da gc.
 *
 * Input: numPart e' il numero di particelle coinvolte nella collisione;
 *		  buf e' la stringa contenente lo stato di collisione;
 *
 * Output: minterm e' il mintermine generato, in cui: 
 *		   minterm[i] = '1' sse particella i appartiene alla collisione
 */
void genMinterm (int numPart, char buf[], char minterm[])
{
  int i, intBuf;
  char *p;

  if (buf == NULL) return;

  /* estrae numPart interi dalla stringa rappresentante la collisione */
  p = buf;
  i = 0;

  do {
	if (sscanf (p, "%d", &intBuf) != 1)
		error ("genMinterm: formati dati errato (sscanf)\n");
	minterm[intBuf] = '1';

	/* quando ne trova abbastanza esce */
	if (++i == numPart)
		break;

	/* si posiziona sul prossimo intero */
	p = strchr (p, ' ');
	if (p == NULL)
		error ("genMinterm: formati dati errato (' ') %s\n", buf);
	p++;
  } while (1);			/* non e' necessario mettere una condizione */
}


/*
 * Cerca il numero massimo di possibili stati post-collisione.
 *
 * Input: il file di collisioni, il numero di collisioni per ogni massa possibile. 
 * 
 * Output: il numero cercato.
 */
int findMaxState (FILE *fp, int numColl[])
{
  char buf[BUFLEN],
	   currState[NUMVECT],
	   precState[NUMVECT];
  int  j, 
	   numPart,
	   count,
	   max = 1;
	   

  for (numPart = 2; numPart < NUMVECT - 1; numPart++) {

	if (numColl[numPart] == 0)
	  continue;
   
	/* salta commenti e keyword */
 	do
	  fgets (buf, BUFLEN, fp);
	while ((*buf != '$') && (!feof (fp)));

	/* azzeramento */
	memset (precState, '0', sizeof (char) * NUMVECT);
	count = 1;

	fgets (buf, BUFLEN, fp);
	genMinterm (numPart, buf, precState);
 
	for (j = 0; j < numColl[numPart] - 1; j++) {

	  fgets (buf, BUFLEN, fp);
	  if (*buf == '$')					/* '$' indica l'inizio di una nuova classe */ 
		fgets (buf, BUFLEN, fp);
 
	  memset (currState, '0', sizeof (char) * NUMVECT);

	  /* genera il minterm per lo stato pre-collisione */
	  genMinterm (numPart, buf, currState);

	  if (strncmp (currState, precState, NUMVECT) == 0) {
		count++;
		max = MAX(max, count);
 	  }
	  else {
		count = 1;
		strncpy (precState, currState, NUMVECT);
	  }
	}
  }

  return max;
}


/*
 * Carica la classi di collisioni in memoria.
 * 
 * Input: puntatore al file, numero di collisioni, il buffer delle classi, il numero massimo
 *		  di possibili stati post-collisione.
 *
 * Output: il numero delle classi caricate.
 */
int loadClass (FILE *fp, int numColl[], collRec classBuf[], int maxState)
{
  int i = 0, 
	  j,k, count,							/* contatori */
	  numPart;

  char *buf, **inBuf,							/* buffer di input */
	   **p,
		currState[NUMVECT + 1],
		precState[NUMVECT + 1];


  /* buffer di lettura */
  inBuf = (char **) malloc (sizeof (char *) * (maxState + 1));
  for (k = 0; k < maxState + 1; k++)
	inBuf[k] = (char *) malloc (sizeof (char) * BUFLEN);

  /* carattere di fine stringa */
  currState[NUMVECT] = precState[NUMVECT] = '\0';

  /* si posiziona all'inizio delle classi */
  buf = inBuf[0];
  do
	buf = fgets (buf, BUFLEN, fp);
  while ((*buf != '$') && (!ferror(fp)));

  if (ferror(fp) || feof(fp))
	error ("%s\n", "gct: errore leggendo input!");

  for (numPart = 2; numPart < NUMVECT - 1; numPart++) {

	/* se la classe e' vuota passa alla prossima iterazione */
	if (numColl[numPart] == 0)
		continue;

	/* azzeramento */
	memset (precState, '0', sizeof (char) * NUMVECT);	
	count = 0;
	j = 0;

	do {

	  buf = inBuf[count];

	  /* lettura linea per linea */
	  do {
	    buf = fgets (buf, BUFLEN, fp);

		if (ferror(fp) || feof(fp))
		  error ("%s\n", "gct: errore leggendo input!");

	    /* salta i commenti e le linee di controllo */
		if ((*buf == '#') || (*buf == '$'))
		  continue;
		else
		  break;
	  } while (!feof (fp));

	  memset (currState, '0', sizeof (char) * NUMVECT);			

	  /* genera il minterm per lo stato pre-collisione */
	  genMinterm (numPart, buf, currState);

	  /* alla prima collisione forza l'inizio di una classe */
	  if (j == 0)
		strcpy (precState, currState);

	  if (strcmp (currState, precState) == 0)
		count++;
	  else {
		/* Nuova classe! */

		/* aggiorna lo stato */
		strcpy (precState, currState);

		/* copia la classe nel buffer delle classi */
		p = classBuf[i].store = (char **) malloc (sizeof (char *) * count);
		classBuf[i].dim = count;
		classBuf[i].numPart = numPart;
		for (k = 0; k < count; k++) {
			p[k] = (char *) malloc (sizeof (char) * BUFLEN);
			strcpy (p[k], inBuf[k]);
		}

		/* copia l'ultimo stato all'inizio del buffer di lettura */
		strcpy (inBuf[0], buf);
		count = 1;
		i++;
	  }
	} while (++j < numColl[numPart]);
	  
	/* ultimo stato della classe */ 
	p = classBuf[i].store = (char **) malloc (sizeof (char *) * count);
	classBuf[i].dim = count;
	classBuf[i].numPart = numPart;
	for (k = 0; k < count; k++) {
		p[k] = (char *) malloc (sizeof (char) * BUFLEN);
		strcpy (p[k], inBuf[k]);
	}

	i++;
  }

  /* libera la memoria ed esce */
  for (k = 0; k < maxState + 1; k++)
	free (inBuf[k]);
  free (inBuf);

  return i;
}


/*
 * Legge il numero di collisioni per numero di particelle.
 *
 * Input: il puntatore al collision_file.
 *
 * Output: l'array dove memorizzare i numeri.
 */
void readNumColl (FILE *fp, int store[])
{
  char buf[BUFLEN];
  int j;

  /* ci sono collisioni solo da 2 a 10 particelle */
  j = 2;
  do {
	fgets (buf, BUFLEN, fp);
	if (*buf != '#') 						/* se inizia con '#' allora e' commento */
	  sscanf (buf, "%d", &store[j++]);
  } while ((j < NUMVECT - 1) && (!feof (fp)));

  if (feof (fp)) 
	error ("%s\n", "gct: End Of File inaspettato");
}


void main (int argc, char *argv[])
{
  FILE *inFile;
  char **myargv = argv,						/* argv personale */
		*buf,
		state[NUMVECT + 1];					/* un buffer per scrivere uno stato */

  collRec classBuf[NUMSTATE];				/* buffer delle classi */

  u_int k;

  int  numColl[NUMVECT]={0},				/* numero di collisioni per particelle */
	   numCollState[NUMVECT]={0},
	  *stateSet,
	   numPart,								/* numero di particelle nella collisione */
	   numClass,							/* numero di classi lette */
   	   i, j, 								/* contatori */
	   maxState;							/* numero massimo di stati post-collisione */


  /* Cosi' error() scrive su stderr */
  error_logfile = stderr;

  fprintf (stderr, msg);				/* titolo */

  /* un piccolo parsing dell'input */
  if (argc < 2) 
	error ("%s\n", usage);
  if ((inFile = fopen (*++myargv, "r")) == NULL) 
	error ("%s %s\n", "gct: non posso aprire ", *myargv);

  /* alloca la memoria per l'insieme degli stati */ 
  stateSet = (int *) malloc (sizeof (int) * NUMSTATE);
  memset (stateSet, 1, sizeof (int) * NUMSTATE);
  memset (numCollState, 0, sizeof (int) * NUMVECT);

  /* legge il numero di collisioni per numero di particelle */
  readNumColl (inFile, numColl);

  /* cerca il numero massimo di possibili stati post-collisione */
  maxState = findMaxState (inFile, numColl);

  /* 'riavvolge' il file */
  rewind (inFile);

  /* carica in memoria le classi */
  numClass = loadClass (inFile, numColl, classBuf, maxState);

  /* scrive il numero delle classi */
  printf ("%d", numClass);

  /* generazione della tabella */
  for (i = 0; i < numClass; i++) {

    /* conversione in decimale e scrittura dello stato rappresentante la classe */
	memset (state, '0', sizeof (char) * NUMVECT);
	numPart = classBuf[i].numPart;
	genMinterm (numPart, (classBuf[i].store)[0], state);
	reverse (state, NUMVECT);
	k = btoi (state, NUMVECT);
	printf ("\n%d %d#", k, classBuf[i].dim);

	/* segnala che e' uno stato di collisione */
    stateSet[k] = 0;
	numCollState[numPart]++;

    /* conversione in decimale e scrittura degli altri membri della classe */
	for (j = 0; j < classBuf[i].dim; j++) {
	  memset (state, '0', sizeof (char) * NUMVECT);
	  buf = memchr ((classBuf[i].store)[j], '-', BUFLEN);			/* si sposta sullo stato post-collisione */
	  if (buf == NULL)
		error ("errore formato dati %d ", numPart);
	  buf+=2;
	  genMinterm (numPart, buf, state);
	  reverse (state, NUMVECT);
	  printf ("%d ", btoi (state, NUMVECT));
	}
  }


  /* elaborazione degli stati non collisione: viene scritta solo la loro codifica decimale */ 
  printf ("\n# Inizio stati non collisione\n"); 
  for (i = 0; i < NUMSTATE; i++) {
	if (stateSet[i]) 
	  printf ("%d\n", i); 
  }

  printf ("# Numero di classi di collisione per particelle:\n");
  for (i = 0; i < NUMVECT; i++)
	printf ("%d\n", numCollState[i]);

  fclose (inFile);
}
