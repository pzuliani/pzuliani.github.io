/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * merge.c
 *
 * "Fonde" in unico file HDF tutti i file di output scritti dai processori di un sistema
 * parallelo.
 * Da qui' in avanti output_file e' il valore della risorsa outFile del file di risorse.
 * I file da fondere hanno il nome secondo la convenzione:
 *			numero_processore.output_file
 * Il file generato da merge ha nome output_file.
 *
 * Macro disponibili:	USE_DFSD_INTERFACE
 *
 * Nota:
 *		merge serve solo se si lavora con un sistema parallelo!!
 */

#include <stdio.h>
#include <stdlib.h>

#include "mfhdf.h"
#include "ca_cdef.h"
#include "merge.h"

/* L'interfaccia SD delle routine HDF ha ancora qualche problema */
#define USE_DFSD_INTERFACE

/* Cosi' error() (funzione esterna) scrive su standard error */
FILE *error_logfile = stderr;

#ifdef USE_DFSD_INTERFACE
int16 headerRef;							/* reference del dataset contenente l'header */
#endif


/*
 * Semplice parsing della linea di comando.
 *
 * Input:
 *		int argc, char *argv[]: i soliti noti...
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 *
 * Output:
 *		char *rc_file: il nome del file di risorse;
 *
 * Note:
 *		se si verifica un errore nella lettura delle risorse emette un msg di errore e
 *		termina il programma.
 */
void parseCommandLine (int argc, char *argv[], mergeData *mergeRecPtr, char *rc_file)
{
  extern int opterr;
  extern char *optarg;
  char opt;

  opterr = 0;					/* cosi' getopt() non segnala errori all'utente */

  /* L'unica opzione e' -h per l'help */
  while ((opt = getopt (argc, argv, "ho:")) != -1)

	switch (opt) {

	  /* Richiesta di aiuto */
	  case 'h':
		printf ("%s\n", msg[MSG_HELP]);
		exit (1);

	  /* Nome file di output */
	  case 'o':
		strcpy (mergeRecPtr->outFileName, optarg);
		mergeRecPtr->setOptions |= OPT_OUTFILE;
		break;

	  default:
		goto end_parsing;
	}

end_parsing:
  if (argc < 3)
	error ("%s\n", msg[MSG_USAGE]);

  mergeRecPtr->numFile = atoi (argv[optind+1]);
  strcpy (rc_file, argv[optind]);
}


/*
 * Legge i valori delle risorse dal resource_file.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		char *fileName: nome del resource_file.
 *
 * Note:
 *		se si verifica un errore nella lettura delle risorse emette un msg di errore e
 *		termina il programma.
 *
 */
void readResourceFile (simulInData *simRecPtr, char *fileName)
{
  char	*funName = ": readResourceFile()";

  FILE *fp;
  int  resource,							/* indice di risorsa */
	   inputError = FALSE;					/* segnala errore di input */
  char *buf,
	   dummy[BUFLEN],
	   inBuf[BUFLEN],						/* buffer di lettura */
	   resName[BUFLEN];						/* nome di una risorsa */

  /* Apre il resource_file */
  if ((fp = fopen (fileName, "r")) == NULL)
	error ("%s '%s' %s\n", msg[MSG_CANT_OPEN_FILE], fileName, funName);

  /* Lettura del resource_file per linee */
  while ((fgets (buf = inBuf, BUFLEN, fp) != NULL) && (!inputError)) {

	/* Salta commenti e linee vuote */
	if ((*buf == '#') || (*buf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
	if (sscanf (buf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  inputError = TRUE;
	  break;
	}

	while (*buf++ != ':');			/* si sposta sul valore della risorsa */

	/* Cerca la risorsa nell'insieme delle risorse e memorizza il relativo valore nel
	 * record dei parametri.
	 */
	switch (resource = searchStr (resourceSet, NUMRES, resName)) {
	  case RES_NUMITER:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numIter) == 0);
					break;
	  case RES_NUMROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numRow) == 0);
					break;
	  case RES_NUMCOL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numCol) == 0);
					break;
	  case RES_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->depth) == 0);
				break;
	  case RES_SAMPLE_STEP:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplingStep) == 0);
					break;
	  case RES_SAMPLE_PER_FRAME:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplePerFrame) == 0);
					break;
	  case RES_TRANSIENT:
					inputError = (sscanf (buf, " %d ", &simRecPtr->transient) == 0);
					break;
	  case RES_OUTFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->outFileName) == 0);
					break;
	  case RES_UNKNOWN:
					inputError = TRUE; break;
	  default:
					inputError = FALSE;
	}
  }

  /* Se uscendo dal ciclo non e' EOF allora si e' verificato un errore */
  if (!feof (fp) || inputError) {
	fclose(fp);
	error ("%s\n", msg[MSG_BAD_RESOURCE_FILE]);	
  }

  fclose(fp);
}


/*
 * Modifica i nomi file per l'ambiente MPP.
 * Aggiunge al nome del file un prefisso formato dal numero del PE.
 *
 * Input:
 *		int pe: il numero del PE;
 *
 * Input/Output:
 *		char *fileName: il nome base del file; il nuovo nome viene *sovrascritto*
 *						sul precedente;
 */
void makeMPPFileName (char *fileName, int pe)
{
  #define PREFIX_LENGTH         5           /* 5 cifre per il prefisso del nome del file. */
											/* Sono sufficenti per i teorici 2048 PE del */
											/* Cray T3D/E..... */

  char prefix[PREFIX_LENGTH+1],             /* il prefisso */
	   buf[BUFLEN];
  int numZeroes;                 /* numero di cifre del prefisso da porre a zero */
  int i, j;

  /* Crea un prefisso composto dal numero di PE preceduto da tanti zeri quanti sono necessari a
   * formare una stringa di PREFIX_LENGTH cifre.
   * Ad esempio per il PE 24 il prefisso sara' 00024, per il PE 119 sara' 00119, etc..
   */
  sprintf (buf, "%d", pe);
  numZeroes = PREFIX_LENGTH - strlen (buf);
  memset (prefix, '0', numZeroes);
  for (i = numZeroes, j = 0; i < PREFIX_LENGTH; i++, j++)
	prefix[i] = buf[j];

  prefix[PREFIX_LENGTH] = 0;					/* terminatore di stringa */

  /* Modifica i nomi per i file di output e di log */
  sprintf (buf, "%s.%s", prefix, fileName);
  strcpy (fileName, buf);
}


/*
 * Apre tutti i files (input e output).
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void openFiles (simulInData *simRecPtr, mergeData *mergeRecPtr)
{
  char *funName = ": openFiles()";

  char fileName[256];
  int i;
  int32 fid;

  /* Alloca l'array dei descrittori */
  if ((mergeRecPtr->infile = (int32 *) malloc (sizeof (int32) * mergeRecPtr->numFile)) == NULL)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Apre files di input */
  for (i = 0; i < mergeRecPtr->numFile; i++) {

	/* Prepara il nome del prossimo file da leggere */
	strcpy (fileName, simRecPtr->outFileName);
	makeMPPFileName (fileName, i);

	/* Apre un <output_file> prodotto da ca. Prima controlla se e' un file HDF valido */
	fid = Hopen (fileName, DFACC_READ,-1);
	if (fid != FAIL) {
	  Hclose (fid);
	  if ((mergeRecPtr->infile[i] = SDstart (fileName, DFACC_READ)) == FAIL)
		error ("%s '%s' %s\n", msg[MSG_SDSTART_FAILED], fileName, funName);
	}
	else
	  error ("%s: '%s'\n", msg[MSG_BAD_OUTPUT_FILE], fileName);
  }

#ifndef USE_DFSD_INTERFACE

  /* Apre l'unico file di output: il file "fuso" */
  if ((mergeRecPtr->outfile = SDstart (mergeRecPtr->outFileName, DFACC_CREATE)) == FAIL)
	error ("%s '%s' %s\n", msg[MSG_SDSTART_FAILED], fileName, funName);

#endif
}


/*
 * Inizializzazioni preliminari.
 *
 * Input:
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void init (mergeData *mergeRecPtr)
{
  mergeRecPtr->setOptions = 0;				/* nessuna opzione */
}


/*
 * Inizializzazioni post-lettura <resource_file>.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void initAgain (simulInData *simRecPtr, mergeData *mergeRecPtr)
{
  div_t dummy;
  int numSample;

  /* Calcola il numero di frame presenti nel file di output di ca */
  dummy = div (simRecPtr->numIter - simRecPtr->transient, simRecPtr->samplingStep);
  numSample = dummy.quot;
  dummy = div (numSample, simRecPtr->samplePerFrame);

  simRecPtr->numFrame = dummy.quot;

  /* Se non e' specificato il nome del file di output allora considera quello
   * della risorsa outFile.
   */ 
  if (!(mergeRecPtr->setOptions & OPT_OUTFILE))
	strcpy (mergeRecPtr->outFileName, simRecPtr->outFileName);
}


/*
 * Controlla gli header di tutti i file in input.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void checkHeaders (simulInData *simRecPtr, mergeData *mergeRecPtr)
{
  char *funName = ": checkOutFile()";

  int i;
  encodeInt hdr[4];						/* l'header presente in ogni file */
  int32 sds_id;							/* dataset ID */
  int32 start[1], edge[1];
  int32 numDataSet,						/* il numero di dataset nel file */
		dummy;

  int totCol, totRow, totDepth;			/* dimemsioni totali del reticolo */

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Inizializzazioni varie */
  start[0] = 0;
  edge[0] = 4;
  totCol = totRow = totDepth = 0;

  /* Legge un header alla volta e somma le dimensioni di ogni frame */
  for (i = 0; i < mergeRecPtr->numFile; i++) {

	/* Il primo DataSet contiene un header informativo */
	if ((sds_id = SDselect (mergeRecPtr->infile[i], 0)) == FAIL)
	  error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

	/* Legge il DataSet */
	if (SDreaddata (sds_id, start, NULL, edge, (VOIDP) hdr) == FAIL)
	  error ("%s %s\n", msg[MSG_SDREAD_FAILED], funName);

	/* Somma le dimensioni del frame */
	totRow += hdr[0];
	totCol += hdr[1];
	totDepth += hdr[2];

	/* Legge il numero di datasets presenti nel file: */
	SDfileinfo (mergeRecPtr->infile[i], &numDataSet, &dummy);

	/* deve essere uguale al numero di frame scritto nell'header e... */
	if (hdr[3] != numDataSet - 1)
	  error ("%s %d\n", msg[MSG_BAD_DATASET_NUM], i);

	/* ...al numero teorico di frame ottenuto leggendo il <resource_file> */
	if (hdr[3] != simRecPtr->numFrame)
	  error ("%s %d\n", msg[MSG_BAD_FRAME_NUM], i);

	if (SDendaccess (sds_id) == FAIL)
	  error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);
  }

  totRow /= mergeRecPtr->numFile;
  totDepth /= mergeRecPtr->numFile;

  if ((totCol != simRecPtr->numCol) || (totRow != simRecPtr->numRow) ||
	  (totDepth != simRecPtr->depth))
	error ("%s\n", msg[MSG_BAD_FRAME_DIM]);
}


/*
 * Inizializzazioni necessarie alla scrittura di un nuovo dataset.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 *
 * Output:
 *		int32: id del dataset appena creato;
 */
#ifdef USE_DFSD_INTERFACE
void startNewDataSet (simulInData *simRecPtr, mergeData *mergeRecPtr)
#else
int32 startNewDataSet (simulInData *simRecPtr, mergeData *mergeRecPtr)
#endif
{
  char *funName = ": startNewDataSet()";

  int32 size[1];
#ifndef USE_DFSD_INTERFACE
  int32 retVal;
#endif

#ifdef DEBUG
  printf ("%s\n", funName);
#endif


  size[0] = simRecPtr->numCol * simRecPtr->numRow * simRecPtr->depth * 4;

#ifdef USE_DFSD_INTERFACE

  DFSDclear();

  if (DFSDsetNT (ENCODE_INT) == FAIL)
	error ("%s %s\n", msg[MSG_SDSTART_FAILED], funName);

  if (DFSDsetdims (1, size) == FAIL)
	error ("%s %s\n", msg[MSG_SDCREATE_FAILED], funName);

  if (DFSDstartslab (mergeRecPtr->outFileName) == FAIL)
	error ("%s %s\n", msg[MSG_SDSTART_FAILED], funName);

#else

  retVal = SDcreate (mergeRecPtr->outfile, "Pippo", ENCODE_INT, 1, size);
  if (retVal == FAIL)
	error ("%s %s\n", msg[MSG_SDCREATE_FAILED], funName);
  else
	return retVal;

#endif
}


/*
 * Scrive un header all'inizio del file di output.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void writeHeader (simulInData *simRecPtr, mergeData *mergeRecPtr)
{
  char *funName = ": writeHeader()";

  encodeInt hdr[4];
  int32 edge[1];
#ifndef USE_DFSD_INTERFACE
  int32 sds_id;
  int32 start[1];
#endif

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  edge[0] = 4;

  /* Prepara l'header: contiene le dimensioni dei successivi frame e il loro numero */
  hdr[0] = simRecPtr->numRow;
  hdr[1] = simRecPtr->numCol;
  hdr[2] = simRecPtr->depth;
  hdr[3] = simRecPtr->numFrame;

#ifdef USE_DFSD_INTERFACE

  if (DFSDsetNT (ENCODE_INT) == FAIL)
	error ("%s %s\n", msg[MSG_SDSTART_FAILED], funName);

  if (DFSDputdata (mergeRecPtr->outFileName, 1, edge, (VOIDP) hdr) == FAIL)
	error ("%s %s\n", msg[MSG_SDWRITE_FAILED], funName);

  headerRef = DFSDlastref();
  if (headerRef == FAIL)
	error ("%s %s\n", msg[MSG_SDCREATE_FAILED], funName);

#else

  if ((sds_id = SDcreate (mergeRecPtr->outfile, "Pippo", ENCODE_INT, 1, edge)) == FAIL)
	error ("%s %s\n", msg[MSG_SDCREATE_FAILED], funName);

  start[0] = 0;

  if (SDwritedata (sds_id, start, NULL, edge, (VOIDP) hdr) == FAIL)
	error ("%s %s\n", msg[MSG_SDWRITE_FAILED], funName);

  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);

#endif
}


/*
 * Aggiorna l'header del file di output: scrive il numero di frame.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: i dati per la "fusione";
 */
void updateHeader (simulInData *simRecPtr, mergeData *mergeRecPtr)
{
  char *funName = ": updateHeader()";

  int32 start[1], edge[1];
#ifndef USE_DFSD_INTERFACE
  int32 sds_id;
#endif

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  edge[0] = 1;

  /* L'header e' il DataSet 0 */
#ifdef USE_DFSD_INTERFACE

  start[0] = 4;						/* gli slab DFSD partono da 1!!!!! */

  if (DFSDwriteref (mergeRecPtr->outFileName, headerRef) == FAIL)
	error ("%s %s\n", msg[MSG_SDCREATE_FAILED], funName);

  if (DFSDstartslab (mergeRecPtr->outFileName) == FAIL)
	error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

  if (DFSDwriteslab (start, NULL, edge, (VOIDP) &(simRecPtr->numFrame)) == FAIL)
	error ("%s %s\n", msg[MSG_SDWRITE_FAILED], funName);

  if (DFSDendslab() == FAIL)
	error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);

#else

  start[0] = 3;

  if ((sds_id = SDselect (mergeRecPtr->outfile, 0)) == FAIL)
	error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

  if (SDwritedata (sds_id, start, NULL, edge, (VOIDP) &simRecPtr->numFrame) == FAIL)
	error ("%s %s\n", msg[MSG_SDWRITE_FAILED], funName);

  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);

#endif
}


/*
 * Legge un intero frame (dataset) da file.
 *
 * Input:
 *		int32 fileID: file ID;
 *		int numFrame: l'indice del frame da leggere (il primo frame ha indice 0);
 *
 * Output:
 *		encodeInt *: buffer di lettura;
 *		int *bufLen: lunghezza del buffer ritornato;
 *
 * Note:
 *		alloca la memoria necessaria a leggere tutto il frame.
 */
encodeInt *readFrame (int32 fileID, int numFrame, int *bufLen)
{
  char *funName = ": readFrame()";

  int32 sds_id, rank, num_type, attr;				/* tutta roba per HDF */
  int32 dim_sizes[MAX_VAR_DIMS], start[1];
  char name[MAX_NC_NAME];

  encodeInt *buf;									/* il buffer di lettura */

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  start[0] = 0;

  /* Si posiziona sul dataset richiesto: il primo dataset contiene un header */
  if ((sds_id = SDselect (fileID, numFrame+1)) == FAIL)
	error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

  /* Legge le informazioni relative al dataset: interessa solo la dimensione */
  if (SDgetinfo (sds_id, name, &rank, dim_sizes, &num_type, &attr) == FAIL)
	error ("%s %s\n", msg[MSG_SDGETINFO_FAILED], funName);

  /* Alloca la memoria necessaria a leggerlo tutto */
  if ((buf = (encodeInt *) malloc (sizeof (encodeInt) * dim_sizes[0])) == NULL)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Lettura */
  if (SDreaddata (sds_id, start, NULL, dim_sizes, (VOIDP) buf) == FAIL)
	error ("%s %s\n", msg[MSG_SDREAD_FAILED], funName);

  /* Rilascia il dataset */
  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);

  *bufLen = dim_sizes[0];
  return buf;
}


/*
 * Appende un frame in fondo al file.
 *
 * Input:
 *		int32 sds_id: dataset id in cui scrivere;
 *		encodeInt *buf: i dati da scrivere;
 *		int bufLen: lunghezza del buffer;
 *		int numFrame: indice del frame da scrivere;
 *
 */
#ifdef USE_DFSD_INTERFACE
void appendFrame (encodeInt *buf, int bufLen, int numFrame)
#else
void appendFrame (int32 sds_id, encodeInt *buf, int bufLen, int numFrame)
#endif
{
  char *funName = ": appendFrame()";

  static int32 start[1];
  int32 edge[1];

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  edge[0] = bufLen;

  /* Il frame 0 indica che stiamo scrivendo in un nuovo dataset */
  if (numFrame == 0)
#ifdef USE_DFSD_INTERFACE
	start[0] = 1;				/* gli indici degli slab DFSD partono da 1!!!! */
#else
	start[0] = 0;
#endif

#ifdef USE_DFSD_INTERFACE
  if (DFSDwriteslab (start, NULL, edge, (VOIDP) buf) == FAIL)
	error ("%s %s\n", msg[MSG_SDWRITE_FAILED], funName);
#else
  if (SDwritedata (sds_id, start, NULL, edge, (VOIDP) buf) == FAIL) 
	error ("%s %s\n", msg[MSG_SDWRITE_FAILED], funName);
#endif

  start[0] += bufLen;
}


/*
 * Fusione di tutti i file in input.
 *
 * Input:
 *		simulInData *simRecPtr: dati di input della simulazione;
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void doMerging (simulInData *simRecPtr, mergeData *mergeRecPtr)
{
  char *funName = ": doMerging()";

  int i, j;
  encodeInt *buf;
  int bufLen;
#ifndef USE_DFSD_INTERFACE
  int32 sds_id;
#endif

  /* Scrive l'header */
  writeHeader (simRecPtr, mergeRecPtr);

  for (i = 0; i < simRecPtr->numFrame; i++) {

	/* Predispone per un nuovo dataset */
#ifdef USE_DFSD_INTERFACE
	startNewDataSet (simRecPtr, mergeRecPtr);
#else
	sds_id = startNewDataSet (simRecPtr, mergeRecPtr);
#endif

	/* Lettura di frame da ogni file e scrittura su disco */
	for (j = 0; j < mergeRecPtr->numFile; j++) {

	  /* Lettura di un intero frame */
	  buf = readFrame (mergeRecPtr->infile[j], i, &bufLen);

	  /* Scrittura */
#ifdef USE_DFSD_INTERFACE
	  appendFrame (buf, bufLen, j);
#else
	  appendFrame (sds_id, buf, bufLen, j);
#endif

	  free (buf);
	}

#ifdef USE_DFSD_INTERFACE
	if (DFSDendslab() == FAIL)
	  error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);	
#else
	if (SDendaccess (sds_id) == FAIL)
	  error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);	
#endif

  }

  /* Aggiorna l'header
  updateHeader (simRecPtr, mergeRecPtr);*/
}


/*
 * Chiude tutti i files aperti dal programma.
 *
 * Input:
 *		mergeData *mergeRecPtr: le informazioni per la 'fusione';
 */
void closeFiles (mergeData *mergeRecPtr)
{
  char *funName = ": closeFiles()";

  int i;

#ifndef USE_DFSD_INTERFACE
  /* Chiude file di output */
  if (SDend (mergeRecPtr->outfile) == FAIL)
	error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);	
#endif

  /* Chiude file di input */
  for (i = 0; i < mergeRecPtr->numFile; i++)
	if (SDend (mergeRecPtr->infile[i]) == FAIL)
	  error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);	
}


void main (int argc, char *argv[])
{
  simulInData simRec;					/* i parametri della simulazione */
  mergeData mergeRec;					/* i dati per la 'fusione' */
  char rc_file[256];					/* resource file */

  /* Inizializzazioni preliminari */
  init (&mergeRec);

  /* Parsing della linea di comando */
  parseCommandLine (argc, argv, &mergeRec, rc_file);

  /* Lettura <resource_file> */
  readResourceFile (&simRec, rc_file);

  /* Ancora inizializzazioni */
  initAgain (&simRec, &mergeRec);

  /* Apre tutti i files */
  openFiles (&simRec, &mergeRec);

  /* Controlla le intestazioni di tutti i files di input */
  checkHeaders (&simRec, &mergeRec);

  /* Fusione */
  doMerging (&simRec, &mergeRec);

  /* Chiude tutto */
  closeFiles (&mergeRec);
}
