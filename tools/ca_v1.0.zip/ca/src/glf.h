/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * glf.h 	"Generate Lattice File"
 *
 * Header file per glf.c.
 *
 */

/* Cerca una stringa in un dato insieme di stringhe */
extern int searchStr (char **strSet, int strSetDim, char *keyStr);

/* Stampa messaggi su stderr e poi termina il programma */
extern void error (char *format, ...);

/* Struttura per definire un ostacolo nel reticolo */
typedef struct {
  u_int firstRow,
		firstDepth,
		lastRow,
		lastDepth,
		firstCol,
		lastCol;
} obstacle;

/* messaggi vari per l'utente */
char *msg[] = {"Genera il <lattice_file> a partire dai parametri del <resource_file>.\
\nUso: glf [-h] <resource_file> <lattice_file>\n\
Usa -h per avere un ulteriore aiuto.",
			   "glf: non posso aprire ",
			   "glf: formato <resource_file> errato, usare crcf",
			   "glf: errore scrivendo <lattice_file>",
			   "glf: profondita' non congruente, usare crcf",
"Genera il <lattice_file> a partire dai parametri del <resource_file>.\n\
Uso: glf [-h] <resource_file> <lattice_file>\n\
Commenti:\n\
   glf riconosce le seguenti risorse *obbligatorie*:\n\
     - numCol, numRow, depth: le dimensioni del reticolo;\n\n\
     - boundaryCondition: {tunnel|periodic}\n\
          tunnel = un reticolo con contorno di nodi ostacolo (cioe' un 'tubo');\n\
          periodic = un reticolo di soli nodi fluido;\n\n\
   la seguente risorsa e' *opzionale*:\n\
     - obstacle: permette la definizione di un ostacolo nella seguente forma:\n\
          firstRow firstDepth lastRow lastDepth firstCol lastCol\n\
		  dove firstRow, etc.. sono tutti numeri interi compresi tra 0 e\n\
		  dimensione corrispondente del reticolo meno 1.\n"};
             
/* indici per l'array dei messaggi utente */
#define MSG_USAGE 			   0
#define MSG_CANT_OPEN_FILE	   1
#define MSG_BAD_RESOURCE_FILE  2
#define MSG_WRITE_ERROR		   3
#define MSG_BAD_DEPTH          4
#define MSG_HELP			   5
