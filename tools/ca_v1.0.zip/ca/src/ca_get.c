/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * ca_get.c   "Cellular Automaton"
 *
 * Motore principale per l'automa cellulare rombododecaedrico.
 * _get perche' usa delle shmem_get() per parte parallela su Cray MPP.
 *
 * Nota: per permettere la portabilita' del sorgente si e' fatto uso della compilazione condizionale:
 *		il simbolo _CRAYMPP e' definito automaticamente dal compilatore C per Cray MPP; il simbolo
 *		_CRAY e' definito da cc per tutti i sistemi Cray.
 */

/*
 * Macro disponibili: DEBUG, USE_DFSD_INTERFACE
 */
#define USE_DFSD_INTERFACE			/* l'interfaccia SD ha ancora qualche problema. Quando sara' ok togliere
									 * questa #define.
									 */


#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/times.h>

#include "mfhdf.h"
#include "ca_cdef.h"
#include "ca.h"


#ifdef USE_DFSD_INTERFACE
int16 headerRef;					/* il reference dell'header nel file di output */
#endif


/* Il file di log in cui vengono scritte informazioni sulle prestazioni del prg ed 
 * eventuali messaggi di errore.
 * E' usato dalla funzione esterna error().
 */
FILE *error_logfile;


/*
 * Semplice parsing della linea di comando.
 *
 * Input:
 *		int argc, char *argv[]: i soliti noti...
 *
 * Output:
 *		char *rc_file: il nome del file di risorse;
 *
 * Note:
 *		se si verifica un errore nella lettura delle risorse emette un msg di errore e
 *		termina il programma.
 */
void parseCommandLine (int argc, char *argv[], char *rc_file)
{
  extern int opterr;
  extern char *optarg;
  char opt;

#ifdef DEBUG
  printf (": parseCommandLine()\n");
#endif

  opterr = 0;					/* cosi' getopt() non segnala errori all'utente */

  /* L'unica opzione e' -h per l'help */
  while ((opt = getopt (argc, argv, "h")) != -1)

	switch (opt) {

	  /* Richiesta di aiuto */
	  case 'h':
		printf ("%s\n", msg[MSG_HELP]);
		exit (1);

	  default:
		goto end_parsing;
	}

end_parsing:
  if (argc < 2) {
	fprintf (stderr, "%s\nSu questa macchina un unsigned int e' di %d bit.\n", msg[MSG_USAGE], UINTLEN);
	exit (1);
  }

  strcpy (rc_file, argv[optind]);
}


/*
 * Generazione tabella delle velocita'.
 *
 * Input:
 *		encodeInt **store: dove memorizzare i risultati;
 * Output:
 *		nessuno.
 */
void genSpeedTable (encodeInt **store)
{
  register u_int i, k;
  encodeInt sum[3];										/* somme parziali */

  for (i = 0; i < NUMSTATE; i++) {
	memset (sum, 0, sizeof (encodeInt) * 3);			/* azzera le somme parziali */

	for (k = 0; k < NUMVECT; k++)

	  /* Se il vettore k e' presente nello stato i allora lo sommo */
	  if ((i >> k) & 01) {
		sum[0] += (encodeInt) e[k][0];
		sum[1] += (encodeInt) e[k][1];
		sum[2] += (encodeInt) e[k][2];
	  }

	/* Ricopia la somma nel deposito */
	memmove (store[i], sum, sizeof (encodeInt) * 3);
  }
}


/*
 * Legge il reticolo degli ostacoli dal <lattice_file>.
 *
 * Input:
 *		simulInData *simRecPtr: puntatore al record dei parametri della simulazione;
 *		u_int **obstacle: il reticolo degli ostacoli.
 * Output:
 *		nessuno.
 *
 * Nota:
 *		suppone la memoria per il reticolo gia' allocata.
 */
void loadLatticeFile (simulInData *simRecPtr, u_int **obstacle)
{
  char *funName = ":loadLatticeFile()";

  int i,
	  planeDim;								/* numeri di blocchi (u_int) per piano */
  FILE *fp;

  if ((fp = fopen (simRecPtr->latticeFileName, "r")) == NULL)
	error ("%s '%s' %s %s\n", msg[MSG_CANT_OPEN_FILE], simRecPtr->latticeFileName, thisPE, funName);

  planeDim = simRecPtr->numRow * (simRecPtr->depth / UINTLEN);

#ifdef _CRAYMPP
  {
  long offset;				/* posizione da cui iniziare la lettura del lattice_file */
  div_t result;

  result = div (simRecPtr->numCol, _num_pes());

  /* Ogni PE si posiziona sul punto da cui cominciare a leggere */
  offset = _my_pe() * planeDim * sizeof (u_int) * result.quot;
  if (fseek (fp, offset, SEEK_SET) != 0)
	error ("%s %s %s\n", msg[MSG_FSEEK_FAILED], thisPE, funName);
  }
#endif

  /* Legge un piano alla volta  e controlla per eventuali errori in lettura */
  for (i = 0; i < simRecPtr->numColPE; i++)
	if (fread (*++obstacle, sizeof (u_int), planeDim, fp) < planeDim)
	  error ("%s %s %s\n", msg[MSG_BAD_LATTICE_FILE], thisPE, funName);

  fclose (fp);
}


/*
 * Ritorna il valore del paraboloide convesso centrato in (a,b) valutato nel punto (x,y).
 * Non e' un paraboloide di rotazione.
 *
 * Input:
 *		int a, b: (a, b) centro del paraboloide; a e' sulle ascisse, b sulle ordinate;
 *		int x, y: (x, y) punto in cui valutare il paraboloide;
 *
 * Output:
 *		double : il valore del paraboloide in (x,y);
 *
 * Note:
 *		l'output e' normalizzato in [0,1].
 */
double paraboloid (int a, int b, int x, int y)
{
  return (((x-2*a)*(y-2*b)*x*y) / (double) (a*a*b*b));
}


/*
 * Calcolo probabilita' di presenza delle particelle per un piano di nodi.
 *
 * Input:
 *		double *store[NUMVECT]: il piano dove verranno memorizzati i risultati;
 *		simulInData *simRecPtr: puntatore al record contenente i dati di input della
 *                                                              simulazione;
 *		int injectionType: tipo di iniezione (piatta o parabolica);
 *		int xlen, ylen: dimensione del piano;
 *
 * Note: i vettori velocita' sono dichiarati globali.
 */
void  computeProb (int *store[NUMVECT], simulInData *simRecPtr, int injectionType, int xlen, int ylen)
{
  register int i, j, k;

  double reducedDensity;                                /* densita' ridotta */
  eVect e_real[NUMVECT];                                /* i velocity vectors in coordinate reali */

#ifdef DEBUG
  printf (": computeProb()\n");
#endif

  reducedDensity = simRecPtr->n / (double) NUMVECT;

  /* Trasforma i velocity vectors in coordinate reali */
  for (i = 0; i < NUMVECT; i++) {
	e_real[i][0] = DOT_PRODUCT (inverse[0], e[i]);
	e_real[i][1] = DOT_PRODUCT (inverse[1], e[i]);
	e_real[i][2] = DOT_PRODUCT (inverse[2], e[i]);
  }

  /* Calcolo delle probabilita' */
  switch (injectionType) {
	case PARABOLIC:
	  {
		register int pos;								/* indice per l'array deposito */
		register double dummy;

		eVect u_parab;									/* il vettore velocita' parabolico */
		int a, b;										/* centro del paraboloide */

		a = xlen / 2;
		b = ylen / 2;
		pos = 0;

		for (i = 0; i < ylen; i++)
		  for (j = 0; j < xlen; j++) {

			/* Calcola il profilo parabolico per la velocita' */
			dummy = paraboloid (a, b, j, i);
			u_parab[0] = simRecPtr->u[0] * dummy;
			u_parab[1] = simRecPtr->u[1] * dummy;
			u_parab[2] = simRecPtr->u[2] * dummy;

			/* Calcolo probabilita' per tutte le direzioni */
			for (k = 0; k < NUMVECT; k++)
			  store[k][pos] =  (int) (RAND_MAX * reducedDensity * (1 + 3 * DOT_PRODUCT (e_real[k], u_parab)));

			pos++;
		  }
	  }
	  break;
	case FLAT:
	  for (i = 0; i < NUMVECT; i++)

		/* Calcolo approssimazione lineare alla distribuzione di Chapman-Enskog */
		store[i][0] = (int) (RAND_MAX * reducedDensity * (1 + 3 * DOT_PRODUCT (e_real[i], simRecPtr->u)));
  }
}


/*
 * Legge i valori delle risorse dal resource_file.
 *
 * Input:
 *		simulInData *simRecPtr: puntatore al record dove verranno memorizzati i valori letti;
 *		char *fileName: nome del resource_file.
 *
 * Output:
 *		OK risorse lette correttamente;
 *		ERROR errore nella lettura.
 */
int readResourceFile (simulInData *simRecPtr, char *fileName)
{
  FILE *fp;
  int  resource,							/* indice di risorsa */
	   inputError = FALSE;					/* segnala errore di input */
  char *buf,
	   dummy[BUFLEN],
	   inBuf[BUFLEN],						/* buffer di lettura */
	   resName[BUFLEN],						/* nome di una risorsa */
	   *funName = ": readResourceFile()";

  /* Apre il resource_file */
  if ((fp = fopen (fileName, "r")) == NULL)
	error ("%s '%s' %s %s\n", msg[MSG_CANT_OPEN_FILE], fileName, thisPE, funName);

  /* Lettura del resource_file per linee */
  while ((fgets (buf = inBuf, BUFLEN, fp) != NULL) && (!inputError)) {

	/* Salta commenti e linee vuote */
	if ((*buf == '#') || (*buf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
	if (sscanf (buf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  inputError = TRUE;
	  break;
	}

	while (*buf++ != ':');			/* si sposta sul valore della risorsa */

	/* Cerca la risorsa nell'insieme delle risorse e memorizza il relativo valore nel
	 * record dei parametri.
	 */
	switch (resource = searchStr (resourceSet, NUMRES, resName)) {
	  case RES_NUMITER:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numIter) == 0);
					break;
	  case RES_NUMROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numRow) == 0);
					break;
	  case RES_NUMCOL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numCol) == 0);
					break;
	  case RES_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->depth) == 0);
				break;
	  case RES_DENSITY:
					inputError = (sscanf (buf, " %lf ", &simRecPtr->n) == 0);
					break;
	  case RES_SAMPLE_STEP:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplingStep) == 0);
					break;
	  case RES_SAMPLE_PER_FRAME:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplePerFrame) == 0);
					break;
	  case RES_TRANSIENT:
					inputError = (sscanf (buf, " %d ", &simRecPtr->transient) == 0);
					break;
	  case RES_TABFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->collTabFileName) == 0);
					break;
	  case RES_LATFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->latticeFileName) == 0);
					break;
	  case RES_LOGFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->logFileName) == 0);
					break;
	  case RES_OUTFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->outFileName) == 0);
					break;
	  case RES_DATA_COMPRESSION:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;

					/* Cerca di assegnare il valore alla risorsa */
					if ((simRecPtr->dataCompression = searchStr (dataCompValue, 2, dummy)) == RES_UNKNOWN)
					  inputError = TRUE;

					break;
	  case RES_INJECTION_IN:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;

					/* Cerca di assegnare il valore alla risorsa */
					if ((simRecPtr->injectionIn = searchStr (injectionValue, 3, dummy)) == RES_UNKNOWN)
					  inputError = TRUE;

					break;
	  case RES_INJECTION_OUT:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;

					/* Cerca di assegnare il valore alla risorsa */
					if ((simRecPtr->injectionOut = searchStr (injectionValue, 3, dummy)) == RES_UNKNOWN)
					  inputError = TRUE;

					break;
	  case RES_INJECTION_AREA_IN:
					inputError = (sscanf (buf, " %d %d", &simRecPtr->firstInjectionRowIn,
											&simRecPtr->lastInjectionRowIn) != 2);
					break;
	  case RES_INJECTION_AREA_OUT:
					inputError = (sscanf (buf, " %d %d", &simRecPtr->firstInjectionRowOut,
											&simRecPtr->lastInjectionRowOut) != 2);
					break;
	  case RES_LATTICE_STATUS:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;

					/* Cerca di assegnare il valore alla risorsa */
					if ((simRecPtr->latticeStatus = searchStr (latticeStatusValue, 2, dummy)) == RES_UNKNOWN)
					  inputError = TRUE;

					break;
	  case RES_SPEED:
					inputError = (sscanf (buf, " %lf %lf %lf ", &simRecPtr->u[0], &simRecPtr->u[1], &simRecPtr->u[2]) != 3);
					break;
	  case RES_UNKNOWN:
					inputError = TRUE; break;
	  default:
					inputError = FALSE;
	}
  }

  /* Se uscendo dal ciclo non e' EOF allora si e' verificato un errore */
  if (!feof (fp) || inputError) {
	fclose(fp);
	return ERROR;
  }
  fclose(fp);
  return OK;
}


/*
 * Appende un nuovo DataSet al file di output.
 *
 * Input:
 *              encodeInt *block: puntatore al blocco di dati;
 *              int blockLen: lunghezza del blocco (in encodeInt);
 *              int32 sd_id: scientific data ID;
 *              int compression: se si desidera o meno la compressione dei dati;
 *
 * Note:
 *              gestisce direttamente le situazioni di errore.
 *
 */
#ifdef USE_DFSD_INTERFACE
void appendData (encodeInt *block, int blockLen, char *fileName)
#else
void appendData (encodeInt *block, int blockLen, int32 sd_id, int compression)
#endif
{
  static char *funName = ": appendData()";

  int32 dim[1];								/* dimensioni dell'array */

#ifndef USE_DFSD_INTERFACE
  int32 sds_id;							/* Scientific Data Set (SDS) ID */
  int32 start[1];						/* gli indici da cui iniziare a scrivere */
  comp_info c_info;						/* info sulla compressione da adottare */
#endif

  /* Inizializzazioni */
  dim[0] = blockLen;

#ifdef USE_DFSD_INTERFACE

  if (DFSDadddata (fileName, 1, dim, (VOIDP) block) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDWRITE_FAILED], thisPE, funName);

#else

  /* Crea un SDS per tutto l'array */
  if ((sds_id = SDcreate (sd_id, "Pippo", ENCODE_INT, 1, dim)) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDCREATE_FAILED], thisPE, funName);

  /* Configura l'SDS per la compressione, se lo si desidera */
  if (compression == YES) {
	c_info.deflate.level = 1;
	if (SDsetcompress (sds_id, COMP_CODE_DEFLATE, &c_info) == FAIL)
	  error ("%s %s %s\n", msg[MSG_SDSETCOMP_FAILED], thisPE, funName);
  }

  start[0] = 0;

  /* Scrittura su file */
  if (SDwritedata (sds_id, start, NULL, dim, (VOIDP) block) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDWRITE_FAILED], thisPE, funName);

  /* Libera la memoria occupata dal Data Object */
  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDENDACCESS_FAILED], thisPE, funName);

#endif
}


/*
 * Scrive sequenzialmente un frame di risultati della simulazione sull'output file.
 *
 * Input:
 *              encodeInt *block: puntatore al blocco di dati;
 *              int blockLen: lunghezza del blocco (in encodeInt);
 *              int32 sd_id: scientific data ID;
 *              simulInData *simRecPtr: parametri di simulazione;
 *
 * Note:
 *              gestisce direttamente le situazioni di errore.
 *
 */
void writeFrame (encodeInt *block, int blockLen, int32 sd_id, simulInData *simRecPtr)
{
  static char *funName = ": writeFrame()";

#ifndef USE_DFSD_INTERFACE
  int32 sds_id;
#endif
  int32 start[1], edge[1];
  static encodeInt numFrame = 1;

  /* Scrittura vera e propria del frame su file */
#ifdef USE_DFSD_INTERFACE
  appendData (block, blockLen, simRecPtr->outFileName);
#else
  appendData (block, blockLen, sd_id, simRecPtr->dataCompression);
#endif

  edge[0] = 1;

  /* Aggiorna l'header del file: incrementa il numero di frame scritti.
   * L'header e' il DataSet 0.
   */
#ifdef USE_DFSD_INTERFACE

  start[0] = 4;						/* gli slab DFSD partono da 1!!!!! */

  if (DFSDwriteref (simRecPtr->outFileName, headerRef) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDCREATE_FAILED], thisPE, funName);

  if (DFSDstartslab (simRecPtr->outFileName) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDSELECT_FAILED], thisPE, funName);

  if (DFSDwriteslab (start, NULL, edge, (VOIDP)&numFrame) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDWRITE_FAILED], thisPE, funName);

  if (DFSDendslab() == FAIL)
	error ("%s %s %s\n", msg[MSG_SDENDACCESS_FAILED], thisPE, funName);

#else

  start[0] = 3;

  if ((sds_id = SDselect (sd_id, 0)) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDSELECT_FAILED], thisPE, funName);

  if (SDwritedata (sds_id, start, NULL, edge, (VOIDP) &numFrame) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDWRITE_FAILED], thisPE, funName);

  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDENDACCESS_FAILED], thisPE, funName);

#endif

  numFrame++;
}


/*
 * Carica la tabella delle collisioni.
 *
 * Input:
 *              char *fileName: il nome del file contenente la tabella;
 *              u_int *table[]: puntatori alle configurazioni di collisione. 
 *
 */
void  loadCollTable (char *fileName, u_int *table[])
{
  FILE *fp;
  int i, j,
	  numCollState;						/* numero stati di collisione */
  u_int state,							/* stato pre-collisione */
	   classDim;						/* dimensione di una classe */
  char *p, buf[BUFLEN],
		*funName = ": loadCollTable()";

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Apre il colltable_file */
  if ((fp = fopen (fileName, "r")) == NULL)
	error ("%s '%s' %s %s\n", msg[MSG_CANT_OPEN_FILE], fileName, thisPE, funName);

  /* All'inizio del file c'e' il numero di stati di collisione */
  if (fgets (buf, BUFLEN, fp) == NULL)
	error ("%s %s %s\n", msg[MSG_BAD_COLLTABLE_FILE], thisPE, funName);

  if (sscanf (buf, "%d", &numCollState) == 0)
	error ("%s %s %s\n", msg[MSG_CANT_READ_NUMCOLL], thisPE, funName);

  /* Mette a NULL tutti i puntatori della tabella: ovvero tutte le classi vuote */
  for (i = 0; i < NUMSTATE; i++)
	table[i] = NULL;

  /* Lettura e caricamento delle classi di collisione */
  for (i = 0; i < numCollState; i++) {

	/* Lettura linea */
	if (fgets (buf, BUFLEN, fp) == NULL)
	  error ("%s %s %s\n", msg[MSG_BAD_COLLTABLE_FILE], thisPE, funName);

	/* Lettura stato pre-collisione e dimensione della classe */
	if (sscanf (buf, "%d %d", &state, &classDim) != 2)
	  error ("%s %s %s\n", msg[MSG_BAD_COLLTABLE_FILE], thisPE, funName);

	/* Alloca la memoria per la classe */
	table[state] = (u_int *) malloc (sizeof (u_int) * (classDim + 1));
	if (table[state] == NULL)
	  error ("%s %s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

	memset (table[state], 0, sizeof (u_int) * (classDim + 1));
	table[state][0] = classDim;

	/* Lettura stati post-collisione */
	p = buf;
	while (*p++ != '#');
	for (j = 1; j <= classDim; j++) {
		if (sscanf (p, " %d ", &table[state][j]) == 0)  /* lettura intero rappresentante lo stato */
		  error ("%s %s %s\n", msg[MSG_BAD_COLLTABLE_FILE], thisPE, funName);
		while (*p++ != ' ');                                    /* si sposta sul prossimo intero */
	}
  }

  fclose (fp);
}


/*
 * Inietta particelle in un tutto il reticolo secondo l'approssimazione di Chapman-Enskog.
 *
 * Input:
 *              u_int ***m: il reticolo dei nodi;
 *              u_int  **o: il reticolo ostacolo;
 *              simulInData *simRecPtr: puntatore al record contenente i dati di input della
 *                                                              simulazione;
 *
 * Output
 *              nessuno
 */
void  initLattice (u_int ***m, u_int **o, simulInData *simRecPtr)
{
  char *funName = ": initLattice()";

  register int i, j, k, z, pos;
  register double rnd;
  u_int nonObstacle;				/* 0 ostacolo, 1 non ostacolo */
  int planeDimInt;					/* dimensione di un piano di nodi (in interi) */
  int *prob[NUMVECT];			/* probabilita' di presenza nelle 12 direzioni */
  struct timeval time;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  planeDimInt = simRecPtr->numRow * (simRecPtr->depth / UINTLEN);

  /* Inizializza tutti i nodi a vuoto */
  for (j = 1; j <= simRecPtr->numColPE; j++)
	for (i = 0; i < NUMVECT; i++)
	  memset (m[j][i], 0, planeDimInt * sizeof (u_int));

  /* Inietta particelle, se lo si desidera */
  if (simRecPtr->latticeStatus != EMPTY) {

	/* Alloca gli array per le probabilita' di presenza */
	switch (simRecPtr->latticeStatus) {
	  case PARABOLIC:
		for (i = 0; i < NUMVECT; i++)
		  /* Alloca probabilita' per ogni direzione e per ogni nodo di un piano */
		  if ((prob[i] = (int *) malloc (sizeof (int) * simRecPtr->numRow * simRecPtr->depth)) == NULL)
			error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
		break;
	  case FLAT:
		for (i = 0; i < NUMVECT; i++)
		  /* Alloca probabilita' per ogni direzione: basta un solo intero */
		  if ((prob[i] = (int *) malloc (sizeof (int))) == NULL)
			error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
	}

	/* Legge l'ora di sistema per poi inizializzare il generatore di random */
	gettimeofday (&time, NULL);
	srand (time.tv_usec);

	/* Calcola le probabilita' di presenza delle particelle */
	computeProb (prob, simRecPtr, simRecPtr->latticeStatus, simRecPtr->depth, simRecPtr->numRow);

	/* L'iniezione viene eseguita per piani. Qui inietta solo nei piani del reticolo;
	 * i piani di iniezione vengono elaborati in main().
	 */
	switch (simRecPtr->latticeStatus) {
	  case PARABOLIC:
		for (i = 1; i <= simRecPtr->numColPE; i++)

		  /* Iniezione in un piano */
		  for (j = 0, pos = 0; j < planeDimInt; j++) {

			nonObstacle = o[i][j];

			/* Calcola un random nell'intervallo [0,RAND_MAX] */
			rnd = rand ();

			/* Iniezione nel singolo nodo in tutte le direzioni. I nodi ostacolo restano vuoti. */
			for (k = 0; k < UINTLEN; k++) {

			  if (getBit (nonObstacle, k))
				for (z = 0; z < NUMVECT; z++)
				  m[i][z][j] = setBit (m[i][z][j], k, (u_int)((rnd < prob[z][pos]) ? 1:0));

			  pos++;
			}
		  }
		break;
	  case FLAT:
		for (i = 1; i <= simRecPtr->numColPE; i++)

		  /* Iniezione in un piano */
		  for (j = 0; j < planeDimInt; j++) {

			nonObstacle = o[i][j];

			/* Calcola un random nell'intervallo [0,RAND_MAX] */
			rnd = rand ();

			/* Iniezione nel singolo nodo in tutte le direzioni. I nodi ostacolo restano vuoti. */
			for (z = 0; z < NUMVECT; z++)
			   m[i][z][j] = nonObstacle & (u_int) ((rnd < prob[z][0]) ? ~0:0);
		  }
	}

	/* Libera la memoria inutile */
	for (i = 0; i < NUMVECT; i++)
	  free (prob[i]);
  }
}


#ifdef _CRAYMPP
/*
 * Modifica i nomi file per l'ambiente MPP.
 * Aggiunge al nome del file un prefisso formato dal numero del PE.
 *
 * Input:
 *		int pe: il numero del PE;
 *
 * Input/Output:
 *		char *fileName: il nome base del file; il nuovo nome viene *sovrascritto*
 *						sul precedente;
 */
void makeMPPFileName (char *fileName, int pe)
{
  #define PREFIX_LENGTH         5           /* 5 cifre per il prefisso del nome del file. */
											/* Sono sufficenti per i teorici 2048 PE del */
											/* Cray T3D/E..... */

  char prefix[PREFIX_LENGTH+1],             /* il prefisso */
	   buf[BUFLEN];
  int numZeroes;                 /* numero di cifre del prefisso da porre a zero */
  int i, j;

  /* Crea un prefisso composto dal numero di PE preceduto da tanti zeri quanti sono necessari a
   * formare una stringa di PREFIX_LENGTH cifre.
   * Ad esempio per il PE 24 il prefisso sara' 00024, per il PE 119 sara' 00119, etc..
   */
  sprintf (buf, "%d", pe);
  numZeroes = PREFIX_LENGTH - strlen (buf);
  memset (prefix, '0', numZeroes);
  for (i = numZeroes, j = 0; i < PREFIX_LENGTH; i++, j++)
	prefix[i] = buf[j];

  prefix[PREFIX_LENGTH] = 0;					/* terminatore di stringa */

  /* Modifica i nomi per i file di output e di log */
  sprintf (buf, "%s.%s", prefix, fileName);
  strcpy (fileName, buf);
}
#endif


/*
 * Apre l'<output_file> della simulazione.
 *
 * Input:
 *		simulInData *simRecPtr: i dati di input della simulazione;
 *
 * Output:
 *		int32:  FAIL se non riesce ad aprire un file HDF, altrimenti e' un identificatore valido
 *				per un file HDF.
 *
 */
int32 openOutFile (simulInData *simRecPtr)
{
  char *funName = ": openOutFile()";

#ifdef USE_DFSD_INTERFACE
  int32 edge[1] = {4};
  int32 dummy[1];
#else
  int32 sd_id;
#endif

  encodeInt info[4];

#ifdef DEBUG
  printf (": openOutFile()\n");
#endif

  /* L'SDS 0 e' un DataSet speciale contenente solo due interi: le dimensioni dei successivi
   * frame di dati e il numero di frame presenti nel file.
   */
  info[0] = simRecPtr->numRow;
  info[1] = simRecPtr->numColPE;
  info[2] = simRecPtr->depth;
  info[3] = 0;

#ifdef _CRAYMPP
  /* Ogni PE apre il file di output con un nome 'personalizzato': qui crea il nome */
  makeMPPFileName (simRecPtr->outFileName, _my_pe());
#endif

#ifdef USE_DFSD_INTERFACE

  if (DFSDsetNT (ENCODE_INT) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDSTART_FAILED], thisPE, funName);

  if (DFSDputdata (simRecPtr->outFileName, 1, edge, (VOIDP) info) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDWRITE_FAILED], thisPE, funName);

  headerRef = DFSDlastref();
  if (headerRef == FAIL)
	error ("%s %s %s\n", msg[MSG_SDCREATE_FAILED], thisPE, funName);

  dummy[0] = simRecPtr->numRow * simRecPtr->depth * simRecPtr->numColPE * 4;
  if (DFSDsetdims (1, dummy) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDCREATE_FAILED], thisPE, funName);

  return SUCCEED;

#else

  /* Apre <output_file> */
  if ((sd_id = SDstart (simRecPtr->outFileName, DFACC_CREATE)) == FAIL)
	error ("%s %s %s\n", msg[MSG_SDSTART_FAILED], thisPE, funName);

  /* Scrive le informazioni, senza compressione */
  appendData (info, 4, sd_id, NO);

  return sd_id;

#endif
}


/*
 * Apre il file di log.
 *
 * Input:
 *		simulInData *simRecPtr: i dati di input della simulazione;
 *
 * Output:
 *		FILE *: puntatore al file aperto;
 *
 */
FILE *openLogFile (simulInData *simRecPtr)
{
#ifdef DEBUG
  printf (": openLogFile()\n");
#endif

#ifdef _CRAYMPP
  /* Ogni PE apre un suo file di log. Se tutto e' ok a fine simulazione 
   * deve restare solo il file di log del PE 0, gli altri vengono cancellati.
   */
  if (_my_pe() != 0)
    /* Crea un nome unico per ogni PE */ 
    makeMPPFileName (simRecPtr->logFileName, _my_pe());

#endif
  return fopen (simRecPtr->logFileName, "w");
}


/*
 * Calcola le probabilita' di iniezione in ingresso e uscita.
 *
 * Input/Output:
 *		int *probIn[NUMVECT], *probOut[NUMVECT]: gli array in cui scrivere le probabilita';
 *		simulInData *simRecPtr: i dati di input della simulazione;
 *
 */
void  computeProbability (int *probIn[NUMVECT], int *probOut[NUMVECT], simulInData *simRecPtr)
{
#ifdef _CRAYMPP
  /* Calcolo delle probabilita' di presenza delle particelle nelle 12 direzioni
   * per il PE 0.
   */
  if (_my_pe() == 0)
#endif
	if (simRecPtr->injectionIn != NONE)
	  computeProb (probIn, simRecPtr, simRecPtr->injectionIn, simRecPtr->depth,
					(simRecPtr->lastInjectionRowIn - simRecPtr->firstInjectionRowIn + 1));

#ifdef _CRAYMPP
  /* Calcolo delle probabilita' di presenza delle particelle nelle 12 direzioni
   * per l'ultimo PE.
   */
  if (_my_pe() == _num_pes() - 1)
#endif
	if (simRecPtr->injectionOut != NONE)
	  computeProb (probOut, simRecPtr, simRecPtr->injectionOut, simRecPtr->depth,
					(simRecPtr->lastInjectionRowOut - simRecPtr->firstInjectionRowOut + 1));
}


void  main (int argc, char *argv[])
{
  char *funName = ": main()";
  char rc_file[MAX_FILENAME_LEN];

  int latticeDim,						/* numero di nodi del reticolo */
	  resultLatticeDim,					/* dimensione del reticolo dei risultati */
	  planeDim,							/* dimensione (in nodi) di un piano del reticolo */
	  planeDimInt,						/* dimensione (in u_int) di un piano del reticolo */
	  planeDimByte,						/* dimensione (in byte) di un piano del reticolo */
	  iteration,						/* contatore delle iterazioni */
	  numSample,						/* numero campioni estratti */
	  effNumCol,						/* numero colonne effettive del reticolo */
	  lastPlane,						/* indice dell'ultimo piano del reticolo */ 
	  lastRowBlock;						/* indice del primo blocco dell'ultima riga di un piano */ 

  register encodeInt *resultLattice,	/* reticolo dei risultati (densita' e velocita') */
					*resultPtr;

  encodeInt **speedTable;			/* tabella delle velocita': ad ognuno dei 4096 stati associa
									 * la sua quantita' di moto (vettoriale)
									 */

  register int numBlock;			  /* blocchi di celle per ogni riga del piano */

  int isTimeToSample;		          /* segnala quando e' ora di campionare */

  u_int
	  **planePtr,						  /* utensili */
	  *tmp[NUMVECT],

	  ***m,                               /* il reticolo dei nodi */ 
	  **o,                                /* il reticolo degli ostacoli:
										   * 0 e' ostacolo
										   * 1 non e' ostacolo
										   */
	  **collTable,                        /* la tabella delle collisioni */

	   collBuf[NUMVECT],                  /* buffer per le collisioni con ostacolo */

	  *buf[2][NUMVECT];					  /* 2 buffer necessari per simulare la 
	        							   * simultaneita' della propagazione
										   */

  int *probIn[NUMVECT],					/* probabilita' di iniezione di una particella in ingresso e uscita */
	  *probOut[NUMVECT];		 

  int firstInjBlockIn,					/* indici del primo e ultimo blocco in cui iniettare in ingresso e uscita */
	  lastInjBlockIn,
	  firstInjBlockOut,
	  lastInjBlockOut;

#ifdef _CRAYMPP
  u_int *receiveBuf[2];					/* buffers di comunicazione tra i processori */
  u_int *sendBuf;
#endif

  int32 outFile;						/* HDF file id per il file di output */

  simulInData   simRec;					/* i dati di input della simulazione */ 

  register int i,						/* contatore di uso generale */
			   j,						/* indice della colonna in aggiornamento */
			   z;						/* indice del piano buffer di propagazione */

  struct tms    start, stop;			/* per ottenere dal kernel i tempi di utilizzo */
  struct timeval time;					/* per leggere l'orologio di sistema */

  double utime, stime,					/* user time, system time */
		 speed;							/* velocita' di aggiornamento */

#ifdef _CRAYMPP
  long start_tick, stop_tick;			/* per leggere il real time clock */
#endif

  /*************************/
  /* Controlli preliminari */
  /*************************/

  /* Prepara una stringa da appendere ai messaggi di errore */
#ifdef _CRAYMPP
  sprintf (thisPE, ", PE %d", _my_pe());					/* scrive il numero del PE */
#else
  thisPE[0] = '\0';											/* stringa vuota */
#endif

  /* Un controllo vitale per il funzionamento del prg. Controlla se 
   * l'unita' di misura adottata da sizeof e' un byte di 8 bit.
   */
  if (UINTLEN != (i = bitcount ((u_int) ~0))) {
	fprintf (stderr, "%s %s\n(u_int = %d bit)", msg[MSG_NEED_TO_RECOMPILE], thisPE, i);
	exit(1);
  }

  /* Lettura della linea di comando */
  parseCommandLine (argc, argv, rc_file);

  /********************************************************/
  /* Lettura delle risorse e inizializzazioni preliminari */
  /********************************************************/

  /* Lettura delle risorse */
  if (readResourceFile (&simRec, rc_file) == ERROR) {
	fprintf (stderr, "%s %s %s\n", msg[MSG_BAD_RESOURCE_FILE], thisPE, funName);
	exit(1);
  }

  /* Apre il file di log */
  if ((error_logfile = openLogFile (&simRec)) == NULL) {
	printf ("%s '%s' %s\n", msg[MSG_CANT_OPEN_FILE], simRec.logFileName, thisPE);
	exit(1);
  }

  /* Inizializzazione di alcuni indici */
  numSample = 0;
  numBlock = simRec.depth / UINTLEN;
  planeDim = simRec.numRow * simRec.depth;
  planeDimInt = planeDim / UINTLEN;
  planeDimByte = planeDimInt * sizeof (u_int);
  lastRowBlock = planeDimInt - numBlock;
  firstInjBlockIn = numBlock * simRec.firstInjectionRowIn;
  lastInjBlockIn =  numBlock * simRec.lastInjectionRowIn + numBlock - 1;
  firstInjBlockOut = numBlock * simRec.firstInjectionRowOut;
  lastInjBlockOut =  numBlock * simRec.lastInjectionRowOut + numBlock - 1;

#ifdef _CRAYMPP
  {
  div_t result;

  result = div (simRec.numCol, _num_pes());

  /* L'ultimo PE elabora eventuali piani di resto */
  simRec.numColPE = result.quot + ((_my_pe() == _num_pes() - 1) ? result.rem : 0);
  }
#else
  simRec.numColPE = simRec.numCol;
#endif

  latticeDim = planeDim * simRec.numColPE;
  lastPlane = simRec.numColPE + 1;                              /* indice dell'ultimo piano del reticolo */

  /*****************************************************************/
  /* Fase di allocazione della memoria per tutte le strutture dati */
  /*****************************************************************/

  /* Allocazione del reticolo per i risultati. Ho bisogno di 4 int per ogni nodo: tre per le
   * componenti della velocita' e uno per la densita'.
   */
  resultLatticeDim = latticeDim * 4;
  resultLattice = (encodeInt *) malloc (resultLatticeDim * sizeof (encodeInt));

  if (resultLattice == NULL)
	error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
	
  /* Azzera il reticolo dei risultati */
  memset (resultLattice, 0, resultLatticeDim * sizeof (encodeInt));

  /* Allocazione tabella delle velocita': 3 interi per le componenti velocita' di un nodo */
  if ((speedTable = (encodeInt **) malloc (NUMSTATE * sizeof (encodeInt *))) == NULL)
	error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  for (i = 0; i < NUMSTATE; i++)
	if ((speedTable[i] = (encodeInt *) malloc (sizeof (encodeInt) * 3)) == NULL)
	  error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Allocazione della memoria per il reticolo.
   * Qui alloca l'array di puntatori ai piani: ogni processore elabora un fetta di reticolo
   * di uguali dimensioni se il numero di colonne del reticolo e' multiplo del numero di 
   * processori. In caso contrario le colonne rimanenti sono elaborate dall'ultimo PE.
   */
  {
  register u_int ***dummy;
  register u_int **dummyPlane;

  effNumCol = simRec.numColPE + 2;                                      /* 2 sono i piani di iniezione */
  m = dummy = (u_int ***) malloc (sizeof (u_int **) * effNumCol);
  if (m == NULL)
	error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Allocazione puntatori ai piani nelle 12 direzioni */
  planePtr = dummyPlane = (u_int **) malloc (sizeof (u_int *) * NUMVECT * effNumCol);
  if (planePtr == NULL)
	error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Carica i puntatori nell'array di puntatori ai piani */
  for (i = 0; i < effNumCol; i++) {
	*dummy++ = dummyPlane;
	dummyPlane += NUMVECT;
	}
  }

  /* Allocazione del reticolo vero e proprio: la gestione delle condizioni al contorno e'
   * diversa a seconda dell'architettura.
   */
#ifdef _CRAYMPP

  /* Allocazione piani del reticolo (i piani 'reali' dove scorre il fluido) e dei piani
   * di iniezione.
   */
  for (i = 0; i < NUMVECT * effNumCol; i++)
	if ((*planePtr++ = (u_int *) malloc (planeDimByte)) == NULL)
	  error ("%s %s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

#else

  /* Se e' stata richiesta l'iniezione di particelle allora alloca il piano di
   * iniezione di sx (ingresso del fluido).
   */
  if (simRec.injectionIn != NONE)
	{
	  for (i = 0; i < NUMVECT; i++)
		if ((*planePtr++ = (u_int *) malloc (planeDimByte)) == NULL)
		  error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
	}
  else
	/* Salta all'inizio dei piani reticolo senza allocare */
	planePtr += NUMVECT;

  /* Allocazione piani del reticolo: ovvero i piani 'reali' dove scorre il fluido */
  for (i = 0; i < NUMVECT * simRec.numColPE; i++)
	if ((*planePtr++ = (u_int *) malloc (planeDimByte)) == NULL)
	  error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Alloca il piano di iniezione in uscita */
  if (simRec.injectionOut != NONE)
	for (i = 0; i < NUMVECT; i++)
	  if ((*planePtr++ = (u_int *) malloc (planeDimByte)) == NULL)
		error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

#endif

  /* Alloca 2 buffer della dimensione di un piano */
  for (z = 0; z < 2; z++)
	for (i = 0; i < NUMVECT; i++)
	  if ((buf[z][i] = (u_int *) malloc (planeDimByte)) == NULL)
		error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Alloca la memoria per il reticolo degli ostacoli. Alloco anche i puntatori ai piani
   * per le iniezioni solo per uniformita' con le altre strutture dati (u_int ***m) ma
   * *NON* verranno successivamente utilizzati.
   */
  planePtr = o = (u_int **) malloc (sizeof (u_int *) * effNumCol);
  if (o == NULL)
	error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Alloca solo i piani richiesti dall'utente */
  for (i = 0; i < simRec.numColPE; i++)
	if ((*++planePtr = (u_int *) malloc (planeDimByte)) == NULL)
	  error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Alloca i puntatori della tabella di collisione */
  if ((collTable = (u_int **) malloc (sizeof (u_int *) * NUMSTATE)) == NULL)
	error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);

  /* Alloca array per le probabilita' di iniezione in ingresso. In caso di condizioni periodiche non alloca memoria */
#ifdef _CRAYMPP
  if (_my_pe() == 0)
#endif
	switch (simRec.injectionIn) {
	  case PARABOLIC:
		{
		  int injPlaneDim;				/* dimensione del piano di iniezione */

		  injPlaneDim = (lastInjBlockIn - firstInjBlockIn + 1) * UINTLEN;

		  /* Probabilita' per ogni direzione e per ogni nodo del piano di iniezione */
		  for (i = 0; i < NUMVECT; i++)
			if ((probIn[i] = (int *) malloc (sizeof (int) * injPlaneDim)) == NULL)
			  error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
		}
		break;
	  case FLAT:
		/* Probabilita' per ogni direzione */
		for (i = 0; i < NUMVECT; i++)
		  if ((probIn[i] = (int *) malloc (sizeof (int))) == NULL)
			error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
	}

  /* Alloca array per le probabilita' di iniezione in uscita. In caso di condizioni periodiche non alloca memoria */
#ifdef _CRAYMPP
  if (_my_pe() == _num_pes() - 1)
#endif
	switch (simRec.injectionOut) {
	  case PARABOLIC:
		{
		  int injPlaneDim;				/* dimensione del piano di iniezione */

		  injPlaneDim = (lastInjBlockOut - firstInjBlockOut + 1) * UINTLEN;

		  /* Probabilita' per ogni direzione e per ogni nodo del piano di iniezione */
		  for (i = 0; i < NUMVECT; i++)
			if ((probOut[i] = (int *) malloc (sizeof (int) * injPlaneDim)) == NULL)
			  error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
		}
		break;
	  case FLAT:
		/* Probabilita' per ogni direzione */
		for (i = 0; i < NUMVECT; i++)
		  if ((probOut[i] = (int *) malloc (sizeof (int))) == NULL)
			error ("%s%s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
	}

#ifdef _CRAYMPP
  /* Alloca i buffer di comunicazione tra i processori */

  /* Buffer per la ricezione */
  for (i = 0; i < 2; i++)
	if ((receiveBuf[i] = (u_int *) shmalloc (planeDimByte * PLANES_PER_BUFFER)) == NULL)
	  error ("%s %d %s\n", msg[MSG_SHMALLOC_FAILED], _my_pe(), funName);

  /* Buffer per la trasmissione */
  if ((sendBuf = (u_int *) malloc (planeDimByte * PLANES_PER_BUFFER)) == NULL)
	error ("%s %s %s\n", msg[MSG_MALLOC_FAILED], thisPE, funName);
#endif

  /****************************************************/
  /* Inizializzazione delle strutture dati principali */ 
  /****************************************************/

  /* Generazione tabella della velocita' */
  genSpeedTable (speedTable);

  /* Carica il <lattice_file> */
  loadLatticeFile (&simRec, o);

  /* Inizializzazione del reticolo: iniezione di particelle in tutti i nodi */
  initLattice (m, o, &simRec);

  /* Caricamento tabella di collisione */
  loadCollTable (simRec.collTabFileName, collTable);

  /* Calcolo probabilita' di presenza delle particelle */
  computeProbability (probIn, probOut, &simRec);
  
  /* Apertura <output_file> */
  if ((outFile = openOutFile (&simRec)) == FAIL)
	error ("%s '%s' %s %s\n", msg[MSG_CANT_OPEN_FILE], simRec.outFileName, thisPE, funName);

#ifdef _CRAYMPP
  if (_my_pe() == 0) {					/* il PE 0 misura anche le prestazioni del prg */
	times (&start);						/* per misurare le prestazioni del prg */
	start_tick = rtclock();				/* legge il realtime clock */
  }
#else
	times (&start);                    /* per misurare le prestazioni del prg */
#endif

  /****************************/
  /* Algoritmo di simulazione */
  /****************************/

  /* Ciclo di simulazione */
  for (iteration = 1; iteration <= simRec.numIter; iteration++) {

#ifdef DEBUG
	printf ("Iterazione: %d\n", iteration);
#endif

	/* E' una iterazione in cui campionare? */
	isTimeToSample = ((iteration > simRec.transient) && ((iteration - simRec.transient) % simRec.samplingStep == 0));

	/* "Insemina" il generatore di numeri casuali */
	gettimeofday (&time, NULL);
	srand (time.tv_usec);

#ifdef _CRAYMPP
	{
	  register u_int *p;

	  /*************************************/
	  /* Preparazione dei piani da spedire */
	  /*************************************/

	  /* I piani per il vicino di dx */
	  if ((_my_pe() != _num_pes() - 1) || (simRec.injection == NONE)) {

		/* Prepara i piani da spedire: solo le direzioni 0, 4, 5, 6, 7 */
		p = outBuf[1];
		memmove (p, m[simRec.numColPE][0], planeDimByte);
		p += planeDimInt;
		for (j = 4; j <= 7; j++, p += planeDimInt)
		  memmove (p, m[simRec.numColPE][j], planeDimByte);

	  }

	  /* I piani per il vicino di sx */
	  if ((_my_pe() != 0) || (simRec.injection == NONE)) {

		/* Prepara i piani da spedire: solo le direzioni 2, 8, 9, 10, 11 */
		p = outBuf[0];
		memmove (p, m[1][2], planeDimByte);
		p += planeDimInt;
		for (j = 8; j <= 11; j++, p += planeDimInt)
		  memmove (p, m[1][j], planeDimByte);

	  }

	  /********************/
	  /* Sincronizzazione */
	  /********************/
	  barrier();

	  /****************************************/
	  /* Ricezione dei piani intercomunicanti */
	  /****************************************/

	  if ((_my_pe() != _num_pes() - 1) || (simRec.injection == NONE)) {

		/* Prende i piani dal vicino di dx */
		shmem_get (inBuf[1], outBuf[0], planeDimInt * PLANES_PER_BUFFER,
				  (_my_pe()+1) % _num_pes());

		/* Ricopia i piani dal buffer di comunicazione al reticolo.
		 * Servono solo le direzioni 2, 8, 9, 10, 11.
		 */
		p = inBuf[1];
		memmove (m[lastPlane][2], p, planeDimByte);
		p += planeDimInt;
		for (j = 8; j <= 11; j++, p += planeDimInt)
		  memmove (m[lastPlane][j], p, planeDimByte);
	  }

	  if ((_my_pe() != 0) || (simRec.injection == NONE)) {

		/* Prende i piani dal vicino di sx */
		shmem_get (inBuf[0], outBuf[1], planeDimInt * PLANES_PER_BUFFER,
				  (_my_pe()==0) ? (_num_pes()-1) : (_my_pe()-1));

		/* Ricopia i piani dal buffer di comunicazione al reticolo.
		 * Servono solo le direzioni 0, 4, 5, 6, 7.
		 */
		p = inBuf[0];
		memmove (m[0][0], p, planeDimByte);
		p += planeDimInt;
		for (j = 4; j <= 7; j++, p += planeDimInt)
		  memmove (m[0][j], p, planeDimByte);
	  }
	}
#endif	

	/***************************************/
	/* Iniezione di particelle in ingresso */
	/***************************************/

#ifdef _CRAYMPP
	/* Iniezione solo per il PE 0 */
	if (_my_pe() == 0)
#endif
	  switch (simRec.injectionIn) {
		register int rnd;

		case PARABOLIC:
		  {
			register int pos;

			pos = 0;

			for (i = firstInjBlockIn; i <= lastInjBlockIn; i++) {

			  /* Un random in [0,RAND_MAX] */
			  rnd = rand();

			  /* Iniezione nel singolo blocco */
			  for (z = 0; z < UINTLEN; z++, pos++) {

				/* Iniezione: solo direzioni 0, 4, 5, 6, 7, le altre non servono */
				m[0][0][i] = setBit (m[0][0][i], z, (u_int)((rnd < probIn[0][pos]) ? 01:0));
				for (j = 4; j <= 7; j++)
				  m[0][j][i] = setBit (m[0][j][i], z, (u_int)((rnd < probIn[j][pos]) ? 01:0));
			  }
			}
		  }
		  break;
		case FLAT:
		  for (i = firstInjBlockIn; i <= lastInjBlockIn; i++) {

			/* Un random in [0,RAND_MAX] */
			rnd = rand();

			/* Iniezione: solo direzioni 0, 4, 5, 6, 7, le altre non servono */
			m[0][0][i] = (u_int)((rnd < probIn[0][0]) ? ~0:0);
			for (j = 4; j <= 7; j++)
			  m[0][j][i] = (u_int)((rnd < probIn[j][0]) ? ~0:0);
		  }
		  break;
#ifndef _CRAYMPP
		case NONE:
			/* Condizioni al contorno periodiche: fa in modo che i puntatori
			 * dei piani di iniezione puntino agli estremi del reticolo.
			 */
			memmove (m[0], m[lastPlane - 1], sizeof (u_int **) * NUMVECT);
#endif
	  }

	/*************************************/
	/* Iniezione di particelle in uscita */
	/*************************************/

#ifdef _CRAYMPP
	/* Iniezione solo per l'ultimo PE */
	if (_my_pe() == _num_pes() - 1)
#endif
	  switch (simRec.injectionOut) {
		register int rnd;

		case PARABOLIC:
		  {
			register int pos;

			pos = 0;

			for (i = firstInjBlockOut; i <= lastInjBlockOut; i++) {

			  /* Un random in [0,RAND_MAX] */
			  rnd = rand();

			  /* Iniezione nel singolo blocco */
			  for (z = 0; z < UINTLEN; z++, pos++) {

				/* Iniezione: solo direzioni 2, 8, 9, 10, 11 le altre non servono */
				m[lastPlane][2][i] = setBit (m[lastPlane][2][i], z, (u_int)((rnd < probOut[2][pos]) ? 01:0));
				for (j = 8; j <= 11; j++)
				  m[lastPlane][j][i] = setBit (m[lastPlane][j][i], z, (u_int)((rnd < probOut[j][pos]) ? 01:0));
			  }
			}
		  }
		  break;
		case FLAT:
		  for (i = firstInjBlockOut; i <= lastInjBlockOut; i++) {

			/* Un random in [0,RAND_MAX] */
			rnd = rand();

			/* Iniezione: solo direzioni 2, 8, 9, 10, 11 le altre non servono */
			m[lastPlane][2][i] = (u_int)((rnd < probOut[2][0]) ? ~0:0);
			for (j = 8; j <= 11; j++)
			  m[lastPlane][j][i] = (u_int)((rnd < probOut[j][0]) ? ~0:0);
		  }
		  break;
#ifndef _CRAYMPP
		case NONE:
			/* Condizioni al contorno periodiche: fa in modo che i puntatori
			 * dei piani di iniezione puntino agli estremi del reticolo.
			 */
			memmove (m[lastPlane], m[1], sizeof (u_int **) * NUMVECT);
#endif
	  }

#ifdef DEBUG
	printf ("%s\n", "Iniezione OK");
#endif

	/**********************************************/
	/* Propagazione per il primo piano (indice 1) */
	/**********************************************/

	/******************/
	/* Direzioni 0, 2 */
	/******************/
	memmove (buf[0][0], m[0][0], planeDimByte);
	memmove (buf[0][2], m[2][2], planeDimByte);

	for (i = 0; i < planeDimInt; i++) {
	  register int  neighborSx,
					neighborDx,
					neighbor;

	  /******************/
	  /* Direzioni 1, 3 */
	  /******************/

	  neighborDx = (i % numBlock == 0) ? i + (numBlock - 1): i - 1;
	  neighborSx = (i % numBlock == numBlock - 1) ? i - (numBlock - 1): i + 1;

	  buf[0][1][i] = (m[1][1][i] << 1) | getLastBit(m[1][1][neighborDx]);
	  buf[0][3][i] = (m[1][3][i] >> 1) | getFirstBit(m[1][3][neighborSx]);

	  /*************************/
	  /* Direzioni 5, 8, 6, 11 */
	  /*************************/

	  /* Se sto aggiornando la prima riga allora i vicini sono nell'ultima riga */
	  neighbor = (i < numBlock) ? i + planeDimInt - numBlock: i - numBlock;

	  /* Calcola la posizione del vicino di sinistra: per l'ultimo blocco di ogni riga e'
	   * il primo della riga stessa altrimenti e' semplicemente il successivo.
	   */
	  if (i % numBlock == numBlock - 1)
		neighborSx = neighbor - (numBlock - 1);
	  else
		neighborSx = neighbor + 1;

	  buf[0][5][i] = (m[0][5][neighbor] >> 1) | getFirstBit(m[0][5][neighborSx]);
	  buf[0][8][i] = (m[2][8][neighbor] >> 1) | getFirstBit(m[2][8][neighborSx]);

	  /* Calcola la posizione del vicino di destra: per il primo blocco di ogni riga e'
	   * l'ultimo della riga stessa
	   */
	  if (i % numBlock == 0)
		neighborDx = neighbor + (numBlock - 1);
	  else
		neighborDx = neighbor - 1;

	  buf[0][6][i] = (m[0][6][neighbor] << 1) | getLastBit(m[0][6][neighborDx]);
	  buf[0][11][i] = (m[2][11][neighbor] << 1) | getLastBit(m[2][11][neighborDx]);

	  /*************************/
	  /* Direzioni 4, 9, 7, 10 */
	  /*************************/

	  /* Se sto aggiornando l'ultima riga allora i vicini sono nella prima riga */
	  neighbor = (i >= lastRowBlock) ? i % numBlock: i + numBlock;

	  if (i % numBlock == 0)
		neighborDx = neighbor + (numBlock - 1);
	  else
		neighborDx = neighbor - 1;

	  buf[0][4][i] = (m[0][4][neighbor] << 1) | getLastBit(m[0][4][neighborDx]);
	  buf[0][9][i] = (m[2][9][neighbor] << 1) | getLastBit(m[2][9][neighborDx]);

	  /* Calcola la posizione del vicino di sinistra: per l'ultimo blocco di ogni riga e'
	   * il primo della riga stessa
	   */
	  if (i % numBlock == numBlock - 1)
		neighborSx = neighbor - (numBlock - 1);
	  else
		neighborSx = neighbor + 1;

	  buf[0][7][i] = (m[0][7][neighbor] >> 1) | getFirstBit(m[0][7][neighborSx]);
	  buf[0][10][i] = (m[2][10][neighbor] >> 1) | getFirstBit(m[2][10][neighborSx]);
	}

#ifdef DEBUG
	printf ("%s\n", "Propagazione primo piano OK");
#endif

	/**********************************/
	/* Collisione e micro misurazioni */
	/**********************************/

	/* Imposta il puntatore all'inizio del piano */
	resultPtr = resultLattice;

	/* Collisione per il piano 1: e' appena stato aggiornato e si trova nel piano 0 del
	 * buffer.
	 */
	for (i = 0; i < planeDimInt; i++) {
	  register u_int nonObstacle,								/* bit di presenza ostacolo */
					 obstacle;
	  register u_int k, y;										/* contatori */

	  nonObstacle = o[1][i];
	  obstacle = ~nonObstacle;

	  /* Collisione per nodi ostacolo */
	  collBuf[0] = obstacle & buf[0][2][i];
	  collBuf[1] = obstacle & buf[0][3][i];
	  collBuf[2] = obstacle & buf[0][0][i];
	  collBuf[3] = obstacle & buf[0][1][i];
	  collBuf[4] = obstacle & buf[0][8][i];
	  collBuf[5] = obstacle & buf[0][9][i];
	  collBuf[6] = obstacle & buf[0][10][i];
	  collBuf[7] = obstacle & buf[0][11][i];
	  collBuf[8] = obstacle & buf[0][4][i];
	  collBuf[9] = obstacle & buf[0][5][i];
	  collBuf[10] = obstacle & buf[0][6][i];
	  collBuf[11] = obstacle & buf[0][7][i];

	  /* Scrittura nel buffer del nuovo stato solo per i nodi ostacolo */
	  for (k = 0; k < NUMVECT; k++) 
		buf[0][k][i] = (buf[0][k][i] & nonObstacle) | collBuf[k];


	  /* Collisioni per nodi non ostacolo */
	  for (y = 0; y < UINTLEN; y++) {
		register u_int state;										/* per calcolare lo stato pre-collisione */
  
		/* Estrae lo stato bit per bit */
		state = getBit (buf[0][0][i], y) | getBit (buf[0][1][i], y) << 1 | getBit (buf[0][2][i], y) << 2 | getBit (buf[0][3][i], y) << 3 | getBit (buf[0][4][i], y) << 4 | getBit (buf[0][5][i], y) << 5 | getBit (buf[0][6][i], y) << 6 | getBit (buf[0][7][i], y) << 7 | getBit (buf[0][8][i], y) << 8 | getBit (buf[0][9][i], y) << 9 | getBit (buf[0][10][i], y) << 10 | getBit (buf[0][11][i], y) << 11;

		/* Estrae bit di ostacolo per nodo y della parola i nel piano 1:
		 *      se non e' nodo ostacolo ed e' stato di collisione ... 
		 */
		if (getBit (nonObstacle, y)) {
		  if (collTable[state] != NULL) {
			register u_int newState;								/* stato post-collisione */

			/* Accesso alla tabella delle collisioni per determinare stato post-collisione */
			newState = collTable[state][((u_int)rand() % collTable[state][0]) + 1];

			/* Estrazione dei bit del nuovo stato, scrittura nel reticolo */
			for (k = 0; k < NUMVECT; k++)
			  buf[0][k][i] = setBit (buf[0][k][i], y, getBit (newState, k));

			/* Misura della densita' e della velocita' per stato di collisione */
			if (isTimeToSample) {

			  *resultPtr++ += (encodeInt) bitcount (newState);					/* densita' */
			  for (k = 0; k < 3; k++)
				*resultPtr++ += speedTable[newState][k];						/* velocita' */
			}
		  }
		  else
			/* Misura della densita' e velocita' per stato di non collisione */
			if (isTimeToSample) {

			  *resultPtr++ += (encodeInt) bitcount (state);						/* densita' */
			  for (k = 0; k < 3; k++)
				*resultPtr++ += speedTable[state][k];							/* velocita' */
			}
		}
		else
		  if (isTimeToSample)
			resultPtr += 4;											/* salta i nodi ostacolo */
	  }
	}

#ifdef DEBUG
	printf ("%s\n", "Collisione primo piano OK");
#endif

	/****************************************/
	/* Propagazione per i piani j con j > 1 */
	/****************************************/

	/* "Insemina" il generatore di numeri casuali */
	gettimeofday (&time, NULL);
	srand (time.tv_usec);

	z = 1;														/* indice del buffer libero */
	j = 1;
	while (j < simRec.numColPE) {

	  /******************/
	  /* Direzioni 0, 2 */
	  /******************/
	  j++;
	  memmove (buf[z][0], m[j-1][0], planeDimByte);
	  memmove (buf[z][2], m[j+1][2], planeDimByte);

	  for (i = 0; i < planeDimInt; i++) {
		register int  neighborSx,
					  neighborDx,
					  neighbor;

		/******************/
		/* Direzioni 1, 3 */
		/******************/

		neighborDx = (i % numBlock == 0) ? i + (numBlock - 1): i - 1;
		neighborSx = (i % numBlock == numBlock - 1) ? i - (numBlock - 1): i + 1;

		buf[z][1][i] = (m[j][1][i] << 1) | getLastBit(m[j][1][neighborDx]);
		buf[z][3][i] = (m[j][3][i] >> 1) | getFirstBit(m[j][3][neighborSx]);

		/*************************/
		/* Direzioni 5, 8, 6, 11 */
		/*************************/

		/* Se sto aggiornando la prima riga allora i vicini sono nell'ultima riga */
		neighbor = (i < numBlock) ? i + planeDimInt - numBlock: i - numBlock;

		/* Calcola la posizione del vicino di sinistra: per l'ultimo blocco di ogni riga e'
		 * il primo della riga stessa altrimenti e' semplicemente il successivo.
		 */
		if (i % numBlock == numBlock - 1)
		  neighborSx = neighbor - (numBlock - 1);
		else
		  neighborSx = neighbor + 1;

		buf[z][5][i] = (m[j-1][5][neighbor] >> 1) | getFirstBit(m[j-1][5][neighborSx]);
		buf[z][8][i] = (m[j+1][8][neighbor] >> 1) | getFirstBit(m[j+1][8][neighborSx]);

		/* Calcola la posizione del vicino di destra: per il primo blocco di ogni riga e'
		 * l'ultimo della riga stessa
		 */
		if (i % numBlock == 0)
		  neighborDx = neighbor + (numBlock - 1);
		else
		  neighborDx = neighbor - 1;

		buf[z][6][i] = (m[j-1][6][neighbor] << 1) | getLastBit(m[j-1][6][neighborDx]);
		buf[z][11][i] = (m[j+1][11][neighbor] << 1) | getLastBit(m[j+1][11][neighborDx]);

		/*************************/
		/* Direzioni 4, 9, 7, 10 */
		/*************************/

		/* Se sto aggiornando l'ultima riga allora i vicini sono nella prima riga */
		neighbor = (i >= lastRowBlock) ? i % numBlock: i + numBlock;

		if (i % numBlock == 0)
		  neighborDx = neighbor + (numBlock - 1);
		else
		  neighborDx = neighbor - 1;

		buf[z][4][i] = (m[j-1][4][neighbor] << 1) | getLastBit(m[j-1][4][neighborDx]);
		buf[z][9][i] = (m[j+1][9][neighbor] << 1) | getLastBit(m[j+1][9][neighborDx]);

		/* Calcola la posizione del vicino di sinistra: per l'ultimo blocco di ogni riga e'
		 * il primo della riga stessa
		 */
		if (i % numBlock == numBlock - 1)
		  neighborSx = neighbor - (numBlock - 1);
		else
		  neighborSx = neighbor + 1;

		buf[z][7][i] = (m[j-1][7][neighbor] >> 1) | getFirstBit(m[j-1][7][neighborSx]);
		buf[z][10][i] = (m[j+1][10][neighbor] >> 1) | getFirstBit(m[j+1][10][neighborSx]);
	  }

#ifdef DEBUG
	  printf ("%s %d\n", "Propagazione OK piano:", j);
#endif

	  /**********************************/
	  /* Collisione e micro misurazioni */
	  /**********************************/

	  /* Collisione per il piano j: e' appena stato aggiornato e si trova nel piano z del
	   * buffer.
	   */
	  for (i = 0; i < planeDimInt; i++) {
		register u_int nonObstacle,							/* bit di presenza ostacolo */
					   obstacle;
		register u_int k, y;								/* contatori */

		nonObstacle = o[j][i];
		obstacle = ~nonObstacle; 

		/* Collisione per nodi ostacolo */ 
		collBuf[0] = obstacle & buf[z][2][i];
		collBuf[1] = obstacle & buf[z][3][i];
		collBuf[2] = obstacle & buf[z][0][i];
		collBuf[3] = obstacle & buf[z][1][i];
		collBuf[4] = obstacle & buf[z][8][i];
		collBuf[5] = obstacle & buf[z][9][i];
		collBuf[6] = obstacle & buf[z][10][i];
		collBuf[7] = obstacle & buf[z][11][i];
		collBuf[8] = obstacle & buf[z][4][i];
		collBuf[9] = obstacle & buf[z][5][i];
		collBuf[10] = obstacle & buf[z][6][i];
		collBuf[11] = obstacle & buf[z][7][i];

		/* Scrittura nel buffer del nuovo stato solo per i nodi ostacolo */
		for (k = 0; k < NUMVECT; k++)
		  buf[z][k][i] = (buf[z][k][i] & nonObstacle) | collBuf[k];


		/* Collisione per nodi non ostacolo */
		for (y = 0; y < UINTLEN; y++) {
		  register u_int state;								/* stato pre-collisione */

		  /* Estrae lo stato bit per bit */
		  state = getBit (buf[z][0][i], y) | getBit (buf[z][1][i], y) << 1 | getBit (buf[z][2][i], y) << 2 | getBit (buf[z][3][i], y) << 3 | getBit (buf[z][4][i], y) << 4 | getBit (buf[z][5][i], y) << 5 | getBit (buf[z][6][i], y) << 6 | getBit (buf[z][7][i], y) << 7 | getBit (buf[z][8][i], y) << 8 | getBit (buf[z][9][i], y) << 9 | getBit (buf[z][10][i], y) << 10 | getBit (buf[z][11][i], y) << 11;

		  /* Estrae bit di ostacolo per nodo y della parola i nel piano j: 
		   *    se non e' nodo ostacolo ed e' stato di collisione... 
		   */
		  if (getBit (nonObstacle, y)) {
			if (collTable[state] != NULL) {
			  register u_int newState;						/* stato post-collisione */

			  /* Accesso alla tabella delle collisioni per determinare stato post-collisione */
			  newState = collTable[state][((u_int)rand() % collTable[state][0]) + 1];

			  /* Estrazione dei bit del nuovo stato e scrittura nel reticolo */
			  for (k = 0; k < NUMVECT; k++)
				buf[z][k][i] = setBit (buf[z][k][i], y, getBit (newState, k));

			  /* Misura della densita' e velocita' per stato di collisione */
			  if (isTimeToSample) {

				*resultPtr++ += (encodeInt) bitcount (newState);			/* densita' */
				for (k = 0; k < 3; k++)
				  *resultPtr++ += speedTable[newState][k];					/* velocita' */
			  }
			}
			else
			  /* Misura della densita' e velocita' per stato di non collisione */
			  if (isTimeToSample) {

				*resultPtr++ += (encodeInt) bitcount (state);				/* densita' */
				for (k = 0; k < 3; k++)
				  *resultPtr++ += speedTable[state][k];						/* velocita' */
			  }
		  }
		  else
			if (isTimeToSample)
			  resultPtr += 4;						/* se e' nodo ostacolo vado avanti */
		}
	  }
	  /* Terminato aggiornamento per i piani j con j > 1 */
#ifdef DEBUG
	  printf ("%s %d\n", "Collisione OK piano:", j);
#endif

	  /* Scambio tra buffer e matrici reticolo del penultimo piano aggiornato */
	  memmove (tmp, m[j-1], sizeof (u_int *) * NUMVECT);
	  z = !z;
	  memmove (m[j-1], buf[z], sizeof (u_int *) * NUMVECT);
	  memmove (buf[z], tmp, sizeof (u_int *) * NUMVECT);
	}
	/* Terminato aggiornamento per tutto il reticolo */

	/* Scambio tra buffer e matrici reticolo dell'ultimo piano */
	memmove (tmp, m[j], sizeof (u_int *) * NUMVECT);
	z = !z;													/* vedere la semantica della not sul K&R...*/
	memmove (m[j], buf[z], sizeof (u_int *) * NUMVECT);
	memmove (buf[z], tmp, sizeof (u_int *) * NUMVECT);

	/****************************************/
	/* Scrittura risultati su <output_file> */
	/****************************************/

	/* Controlla se si e' in un passo di campionamento */
	if (isTimeToSample)

		/* Eventuale scrittura di un frame sul file di output */
		if (++numSample == simRec.samplePerFrame) {

		  writeFrame (resultLattice, resultLatticeDim, outFile, &simRec);
#ifdef DEBUG
		  printf ("Scrittura frame\n");
#endif
		  /* Azzera reticolo delle misurazioni e contatore dei campioni estratti */
		  memset (resultLattice, 0, resultLatticeDim * sizeof (encodeInt));
		  numSample = 0;
		}
  }

#ifndef USE_DFSD_INTERFACE
  /******************************************/
  /* Fine simulazione: chiusura output file */
  /******************************************/

  if (SDend (outFile) == FAIL)
	error ("%s %s %s", msg[MSG_SDEND_FAILED], thisPE, funName);
#endif

#ifdef _CRAYMPP
  /* Tutti i PE si incontrano alla fine del lavoro per un caffe' */
  barrier();

  /* Il PE 0 e' delegato alla misura delle prestazioni */
  if (_my_pe() == 0)
#endif
  {
#ifdef _CRAYMPP
	/* Legge il realtime clock */
	stop_tick = rtclock();
#endif
	times (&stop);
	utime = (stop.tms_utime - start.tms_utime) / (double) CLK_TCK;				/* user time */
	stime = (stop.tms_stime - start.tms_stime) / (double) CLK_TCK;				/* system time */
	speed = simRec.numRow * simRec.numCol * simRec.depth * (simRec.numIter / utime);
	fprintf (error_logfile, "User time: %fs\nSystem time: %fs\nVelocita': %.0f nodi/s\n", utime, stime, speed);
#ifdef _CRAYMPP
	fprintf (error_logfile, "Ticks: %ld\n", stop_tick - start_tick);
#endif
  }

  fclose (error_logfile);

#ifdef _CRAYMPP
  /* Alla fine deve restare solo il file di log del PE 0 */
  if (_my_pe() != 0)
    unlink (simRec.logFileName);
#endif

  /******************/
  /* Alla prossima! */
  /******************/
}
