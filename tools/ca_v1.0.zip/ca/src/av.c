/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * av.c		"AVerage"
 *
 * Programma per il calcolo delle quantita' medie per velocita' e densita'.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <math.h>

#include "mfhdf.h"
#include "av.h"


FILE *error_logfile;


/*
 * Legge la linea di comando e salva le opzioni nel record apposito. 
 *
 * Input:
 *		int argc, char *argv[]: i soliti...;
 *		userOption *optPtr: record delle opzioni utente;
 *
 * Comportamento:
 *		se c'e' qualche errore in input scrive un messaggio di errore e poi termina il programma.
 *		Gestisce anche la richiesta di help da parte dell'utente.
 */
void parseCommandLine (int argc, char *argv[], userOption *optPtr)
{
  char *funName = ": parseCommandLine()";

  extern char *optarg;					/* variabili usate da getopt() */
  extern int opterr;
  extern int optind;

  char opt;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  opterr = 0;						/* cosi' getopt() non segnala gli errori all'esterno */

  /* Lettura della linea di comando opzione per opzione */
  while ((opt = getopt (argc, argv, "hva:e:r:s:o:i:c:")) != EOF)

	switch (opt) {
	  int i;

	  /* Help */
	  case 'h':
		printf ("%s\n", msg[MSG_HELP]); exit (1);

	  /* Output "verboso" */
	  case 'v':
		optPtr->setOptions |= OPT_INFO; break;

	  /* Coefficente moltiplicativo */
	  case 'c':
		if (sscanf (optarg, "%lf", &optPtr->coefficent) != 1)		
		  error ("%s%c\n", msg[MSG_BAD_OPTION], opt);

		optPtr->setOptions |= OPT_COEFF; 
		break;

	  /* Selezione del tipo di media da eseguire */
	  case 'a':

		for (i = 0; i < strlen (optarg); i++)
		  switch (optarg[i]) {
			case 'x': optPtr->averageType |= AVERAGE_ON_X; break;
			case 'y': optPtr->averageType |= AVERAGE_ON_Y; break;
			case 'z': optPtr->averageType |= AVERAGE_ON_Z; break;
			default: 
			  error ("%s%c\n", msg[MSG_BAD_OPTION], opt);
		  }

		optPtr->setOptions |= OPT_AVERAGE_TYPE;
		break;

	  /* Quali componenti estrarre dal reticolo dati */
	  case 'e':

		for (i = 0; i < strlen (optarg); i++)
		  switch (optarg[i]) {
			case 'x': optPtr->whatToExtract |= EXTRACT_X; break;
			case 'y': optPtr->whatToExtract |= EXTRACT_Y; break;
			case 'z': optPtr->whatToExtract |= EXTRACT_Z; break;
			case 'm': optPtr->whatToExtract |= EXTRACT_MODULUS; break;
			case 'd': optPtr->whatToExtract |= EXTRACT_DENSITY; break;
			case 'v': optPtr->whatToExtract |= EXTRACT_SPEED; 	break;
			default:
			  error ("%s%c\n", msg[MSG_BAD_OPTION], opt);
		  }

		optPtr->setOptions |= OPT_EXTRACT;
		break;

	  /* Il range dei frame su cui mediare */
	  case 'r':

		/* Se non riesce a leggere due interi allora e' errore */
		if (sscanf (optarg, "%d,%d", &optPtr->firstFrame, &optPtr->lastFrame) != 2) 
		  error ("%s%c\n", msg[MSG_BAD_OPTION], opt);

		optPtr->setOptions |= OPT_FRAME_RANGE;
		break;

	  /* Definizione del sotto reticolo su cui mediare */
	  case 's':
		{
		  int a[6];

		  /* Se non riesce a leggere sei interi allora e' errore */
		  if (sscanf (optarg, "%d,%d,%d,%d,%d,%d", &a[0], &a[1], &a[2], &a[3], &a[4], &a[5]) != 6)
		    error ("%s%c\n", msg[MSG_BAD_OPTION], opt);

		  /* Memorizzazione delle dimensioni del sotto reticolo */
		  optPtr->subLat.firstRow   = a[0];
		  optPtr->subLat.firstDepth = a[1];
		  optPtr->subLat.lastRow	= a[2];
		  optPtr->subLat.lastDepth  = a[3];
		  optPtr->subLat.firstCol   = a[4];
		  optPtr->subLat.lastCol    = a[5];

		}

		optPtr->setOptions |= OPT_SUB_LATTICE;
		break;

	  case 'o':
		strcpy (optPtr->outFileName, optarg);
		optPtr->setOptions |= OPT_OUT_FILE;
		break;

	  case 'i':
		strcpy (optPtr->inFileName, optarg);
		optPtr->setOptions |= OPT_IN_FILE;
		break;

	  case '?':
		error ("%s\n", msg[MSG_USAGE]);

	  default:
		goto end_parsing;
	}

end_parsing:
  /* Se non e' stata letta almeno una opzione allora e' errore */
  if (optPtr->setOptions == 0)
	error ("%s\n", msg[MSG_USAGE]);
}


/*
 * Inizializza il record delle opzioni utente.
 *
 *
 * Input:
 *		userOption *optPtr: puntatore al record delle opzioni;
 *
 */
void init (userOption *optPtr)
{
  char *funName = ": init()";

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Nessuna media, nessuna quantita' da estrarre */
  optPtr->averageType = optPtr->whatToExtract = 0;

  /* Nessuna opzione specificata */
  optPtr->setOptions = 0;

}


/*
 * Scrive nel record delle opzioni utente i valori di default.
 *
 * Input:
 *		userOption *optPtr: puntatore al record delle opzioni;
 *		inputData *inputDataPtr: descrive il reticolo dei dati da elaborare.
 *
 */
void setDefaultValues (userOption *optPtr, inputData *inputDataPtr)
{
  char *funName = ": setDefaultValues()";

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Media su tutti i frame se non specificato il range */
  if (!(optPtr->setOptions & OPT_FRAME_RANGE)) {
	optPtr->firstFrame = 0;
	optPtr->lastFrame  = inputDataPtr->numFrame - 1;
  }

  /* Per default il sotto reticolo coincide con tutto il reticolo */
  if (!(optPtr->setOptions & OPT_SUB_LATTICE)) {
	optPtr->subLat.firstRow  = optPtr->subLat.firstDepth = optPtr->subLat.firstCol  = 0;
	optPtr->subLat.lastRow   = inputDataPtr->numRow - 1;
	optPtr->subLat.lastDepth = inputDataPtr->depth - 1;
	optPtr->subLat.lastCol   = inputDataPtr->numCol - 1;
  }

  /* Calcola la dimensione del sotto reticolo */
  optPtr->subLat.len = (optPtr->subLat.lastRow - optPtr->subLat.firstRow + 1) *
					   (optPtr->subLat.lastCol - optPtr->subLat.firstCol + 1) *
					   (optPtr->subLat.lastDepth - optPtr->subLat.firstDepth + 1);

  /* Il numero di frame da leggere */
  inputDataPtr->effNumFrame = optPtr->lastFrame - optPtr->firstFrame + 1;
}


/*
 * Apre il file di input.
 *
 * Input:
 *		userOption *optPtr;
 */
void openInputFile (userOption *optPtr)
{
#ifdef DEBUG
  char *funName = ": openInputFile()";

  printf ("%s\n", funName);
#endif

  /* Controlla se e' in formato HDF */
  if (Hishdf(optPtr->inFileName)) {
	if ((optPtr->infile = SDstart (optPtr->inFileName, DFACC_READ)) == FAIL)
	  error ("%s '%s'\n", msg[MSG_CANT_OPEN_FILE], optPtr->inFileName);
  }
  else
	error ("%s '%s'\n", msg[MSG_BAD_INFILE], optPtr->inFileName);
}


/*
 * Legge le dimensioni di un frame di dati.
 *
 * Input:
 *		inputData *inputPtr: struttura per descrivere il reticolo dati da elaborare;
 *		userOption *optPtr: le opzioni dell'utente;
 *
 * Comportamento:
 *		I dati letti vengono memorizzati nella struttura parametro.
 *		Se non riesce a leggere da stdin scrive un msg di errore e poi termina il prg.
 */
void readFrameDim (inputData *inPtr, userOption *optPtr)
{
  char *funName = ": readFrameDim()";

  int32 header[4];
  int32 start[1], edge[1];
  int32 sds_id;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  start[0] = 0;
  edge[0] = 4;

  /* Legge l'header: e' il dataset 0 */
  sds_id = SDselect (optPtr->infile, 0);
  if (sds_id == FAIL)
	error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

  if (SDreaddata (sds_id, start, NULL, edge, (VOIDP) header) == FAIL) 
	error ("%s %s\n", msg[MSG_SDREAD_FAILED], funName);

  if (SDendaccess (sds_id) == FAIL)
	error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);

  /* Memorizzazione delle dimensioni nel record apposito */
  inPtr->numCol = header[0];
  inPtr->numRow = header[1];
  inPtr->depth  = header[2];
  inPtr->numFrame = header[3];

  /* Adesso puo' calcolare la lunghezza di un frame */
  inPtr->frameLen = header[0] * header[1] * header[2];
}


/*
 * Controllo preliminare delle opzioni utente: controlla se sono stati specificati
 * i nomi dei file di input/output. 
 *
 * Input:
 *		userOption *optPtr: puntatore al record delle opzioni;
 */
void preliminaryCheck (userOption *optPtr)
{
  char *funName = ": preliminaryCheck()";

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Controlla se i nomi dei file di input e output e il comando -e sono stati dati */
  if (!(optPtr->setOptions & OPT_IN_FILE) || !(optPtr->setOptions & OPT_OUT_FILE) ||
	  !(optPtr->setOptions & OPT_EXTRACT))
	error ("%s\n", msg[MSG_COMPULSORY_OPT]);
}


/*
 * Controlla la validita' delle opzioni date dall'utente.
 *
 * Input:
 *		userOption *optPtr: puntatore al record delle opzioni;
 *		inputData *inputDataPtr: descrive il reticolo dei dati da elaborare.
 *
 * Comportamento:
 *		controlla la validita' di tutte le opzioni fornite, scrivendo un apposito msg 
 *		in caso di errore.	
 *		Termina il programma se c'e' stata almeno una opzione errata.
 */
void checkUserOptions (userOption *optPtr, inputData *inputDataPtr)
{
  char *funName = ": checkUserOptions()";

  int anyError = FALSE;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Qualcosa deve pur estrarre.. */
  if (!(optPtr->whatToExtract & (EXTRACT_DENSITY | EXTRACT_SPEED | EXTRACT_MODULUS))) {
	anyError = TRUE;
	fprintf (stderr, "%s\n", msg[MSG_SPECIFY_DVM]);
  }

  /* Per estrarre il modulo o la velocita' bisogna anche specificare quali componenti estrarre */
  if (optPtr->whatToExtract & (EXTRACT_MODULUS | EXTRACT_SPEED))
	if (!(optPtr->whatToExtract & EXTRACT_XYZ)) {
	  anyError = TRUE;
	  fprintf (stderr, "%s\n", msg[MSG_SPECIFY_COMP]);
	}

  /* Controllo validita' opzione -r */
  if ((optPtr->firstFrame < 0) || (optPtr->firstFrame >= inputDataPtr->numFrame) ||
	 (optPtr->lastFrame >= inputDataPtr->numFrame) || (optPtr->lastFrame < 0)) {
	anyError = TRUE;
	fprintf (stderr, "%s%c\n", msg[MSG_NOT_VALID_OPT], 'r');
  }

  /* Controllo validita' opzione -s */
  if ((optPtr->subLat.firstRow < 0) || (optPtr->subLat.firstRow >= inputDataPtr->numRow) ||
	  (optPtr->subLat.lastRow < 0) || (optPtr->subLat.lastRow >= inputDataPtr->numRow) ||
  	  (optPtr->subLat.firstCol < 0) || (optPtr->subLat.firstCol >= inputDataPtr->numCol) ||
	  (optPtr->subLat.lastCol < 0) || (optPtr->subLat.lastCol >= inputDataPtr->numCol) ||
  	  (optPtr->subLat.firstDepth < 0) || (optPtr->subLat.firstDepth >= inputDataPtr->depth) ||
	  (optPtr->subLat.lastDepth < 0) || (optPtr->subLat.lastDepth >= inputDataPtr->depth) ||
	  (optPtr->subLat.firstRow > optPtr->subLat.lastRow) ||
	  (optPtr->subLat.firstCol > optPtr->subLat.lastCol) ||
	  (optPtr->subLat.firstDepth > optPtr->subLat.lastDepth)) {
	anyError = TRUE;
	fprintf (stderr, "%s%c\n", msg[MSG_NOT_VALID_OPT], 's');
  }

  if (anyError)
	exit (1);
}


/*
 * Dealloca un buffer di frame.
 *
 * Input:
 * 		frameBuf *buf: il buffer; 
 *
 */
void deallocate (frameBuf *buf)
{
  register int i;

  for (i = 0; i < buf->numFrame; i++)
	free (buf->frameA[i].store);

  free (buf->frameA);
}


/*
 * Alloca un buffer di frame.
 *
 * Input:
 *		frameBuf *buf: il buffer da allocare;
 *		int numFrame: quanti frame allocare;
 *		int row, col, depth: dimensioni di un frame;
 *
 * Output:
 *		ERROR, OK;
 *
 * Comportamento:
 *		Alloca i frame veri e propri ed il loro campo store.
 *		Se non riesce ad allocare memoria ritorna ERROR al chiamante, altrimenti OK.
 */
int allocate (frameBuf *buf, int numFrame, int row, int col, int depth)
{
  register int i;
  int frameLen = row * col * depth;

  /* Alloca l'array di frame */
  if (((buf->frameA) = (frame *) malloc (sizeof (frame) * numFrame)) == NULL)
	  return ERROR;

  /* Per ogni frame alloca la memoria per i dati veri e propri */
  for (i = 0; i < numFrame; i++) {
	if ((buf->frameA[i].store = (float64 *) malloc (sizeof (float64) * frameLen)) == NULL)
	  return ERROR;
	buf->frameA[i].numRow = row;
	buf->frameA[i].numCol = col;
	buf->frameA[i].depth = depth;
  }

  buf->numFrame = numFrame;

  return OK;
}


/*
 * Carica in memoria un frame di una quantita', leggendo da file.
 * Assume il frame destinazione gia' allocato (anche il campo store).
 *
 * Input:
 *		int32 sds_id: il dataset da cui leggere;
 *		frame *dst: il frame in cui scrivere i dati letti;
 *		int whatLoad: specifica la quantita' da leggere (densita', etc..);
 *		int frameLen: lunghezza del frame;
 *
 * Comportamento:
 *		se si verifica un errore in lettura emette un msg su stderr e termina il prg.
 */
void loadFrame (int32 sds_id, frame *dst, int whatLoad, int frameLen)
{
  static char *funName = ": loadFrame()";

  int32 start[1], edge[1];

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Posizione della quantita' nel dataset */
  switch (whatLoad) {
	case EXTRACT_DENSITY: 	start[0] = 0; break;
	case EXTRACT_X: 		start[0] = frameLen; break;
	case EXTRACT_Y: 		start[0] = 2 * frameLen; break;
	case EXTRACT_Z: 		start[0] = 3 * frameLen;
  }

  edge[0] = frameLen;

  if (SDreaddata (sds_id, start, NULL, edge, (VOIDP) dst->store) == FAIL)
	error ("%s %s\n", msg[MSG_SDREAD_FAILED], funName);
}


/*
 * Estrae un sottoreticolo da un frame.
 *
 * Input:
 *		frame *src: il frame sorgente;
 *		frame *dst: il frame destinazione;
 *		subLat *sl: specifica il sottoreticolo da estrarre.
 *
 * Note:
 *		presuppone il frame dst gia' allocato (anche il campo store).
 */
void  extractSubLat (frame *src, frame *dst, subLattice *sl)
{
  register float64 *store;						/* per velocizzare l'accesso ai dati */
  register int i, j, k;							/* una manciata di contatori */
  int baseRow,
	  baseCol,
	  planeDim;									/* dimensione di un piano del reticolo */

  /* Inizializzazioni varie */
  store = dst->store;
  planeDim = src->numRow * src->depth;

  /* Scrive le dimensioni del frame di output */
  dst->numRow = sl->lastRow - sl->firstRow + 1;
  dst->numCol = sl->lastCol - sl->firstCol + 1;
  dst->depth = sl->lastDepth - sl->firstDepth + 1;

  for (i = sl->firstCol; i <= sl->lastCol; i++) {

	baseCol = i * planeDim;

  	for (j = sl->firstRow; j <= sl->lastRow; j++) {

	  baseRow = baseCol + j * src->depth;

	  for (k = baseRow + sl->firstDepth; k <= baseRow + sl->lastDepth; k++)
		*store++ = src->store[k];
	}
  }
}


/*
 * Caricamento dei dati di input.
 *
 * Input:
 *		frameBuf *buf: il buffer di frame in cui scaricare i dati;
 *		inputData *dataPtr: record delle strutture dati;
 *		userOption *optPtr: record delle opzioni utente;
 *		int whatLoad: quale quantita' caricare (densita', etc..);
 *
 * Note:
 *		alloca la memoria per il buffer di frame passato per parametro.
 *
 */
void loadData (frameBuf *buf, inputData *inPtr, userOption *optPtr, int whatLoad)
{
  static char *funName = ": loadData()";

  int i, j;
  int row, col, depth;
  int32 sds_id;
  frame dummy;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Buffer di lettura per un frame intero */
  if (optPtr->setOptions & OPT_SUB_LATTICE) {
    dummy.store = (float64 *) malloc (sizeof (float64) * inPtr->frameLen);
    if (dummy.store == NULL)
	  error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);
	dummy.numCol = inPtr->numCol;
	dummy.numRow = inPtr->numRow;
	dummy.depth  = inPtr->depth;
  }

  /* Dimensioni di un sub-frame da leggere */
  row = optPtr->subLat.lastRow - optPtr->subLat.firstRow + 1;
  col = optPtr->subLat.lastCol - optPtr->subLat.firstCol + 1;
  depth = optPtr->subLat.lastDepth - optPtr->subLat.firstDepth + 1;

  /* Alloca il buffer di frame per leggere i dati */
  if (allocate (buf, inPtr->effNumFrame, row, col, depth) == ERROR)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Caricamento dei frame specificati */
  for (i = optPtr->firstFrame + 1, j = 0; j < inPtr->effNumFrame; i++, j++) {

	/* Apre il dataset per il frame richiesto: il primo frame e' nel dataset 1 */
	if ((sds_id = SDselect (optPtr->infile, i)) == FAIL)
	  error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

	if (optPtr->setOptions & OPT_SUB_LATTICE) {
	  /* Carica tutto il frame in una struttura temporanea */
	  loadFrame (sds_id, &dummy, whatLoad, inPtr->frameLen);

	  /* Estrae solo i dati richiesti dall'utente */
	  extractSubLat (&dummy, &(buf->frameA[j]), &optPtr->subLat);
	}
	else
	  /* Il sottoreticolo non e' stato specificato, quindi carica tutto il frame nel buffer */
	  loadFrame (sds_id, &(buf->frameA[j]), whatLoad, inPtr->frameLen);

	if (SDendaccess (sds_id) == FAIL)
	  error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);
  }

  /* Libera la memoria inutile */
  if (optPtr->setOptions & OPT_SUB_LATTICE)
	free (dummy.store);
}


/*
 * Copia il contenuto del frame src nel frame dst.
 *
 * Input:
 *		frame *src, *dst: sorgente e destinazione;
 *
 * Output:
 *		ERROR: se non riesce ad allocare memoria;
 *		OK: tutto bene;
 *
 * Comportamento:
 *		alloca la memoria per il campo store del frame dst.
 */
int framecpy (frame *dst, frame *src)
{
  int frameDim;

  /* Scrive nel frame dst le dimensioni del frame src */
  dst->numCol = src->numCol;
  dst->numRow = src->numRow;
  dst->depth  = src->depth;

  frameDim = src->depth * src->numRow * src->numCol;

  if ((dst->store = (float64 *) malloc (sizeof (float64) * frameDim)) == NULL)
	return ERROR;

  memmove (dst->store, src->store, sizeof (float64) * frameDim);  	/* copia del campo store */
  return OK;
}


/* 
 * Esegue una media temporale su un array di frame.
 * Presuppone il frame di output gia' allocato.
 *
 * Input:
 *		frame *frameA: l'array di frame;
 *		frame *outFrame: il frame di output;
 *
 * Comportamento:
 *		Il risultato dell'intero processo e' memorizzato nel frame outFrame; outFrame deve gia'
 *		essere allocato (anche il campo store).
 */
void doTimeAverage (frameBuf *buf, frame *outFrame)
{
  register float64 *store,						/* per velocizzare l'accesso ai dati */
				   tmp;
  register int i, j;
  int frameLen;

  /* Scrive le dimensioni del frame di output */
  outFrame->numRow = buf->frameA->numRow;
  outFrame->numCol = buf->frameA->numCol;
  outFrame->depth = buf->frameA->depth;

  /* Inizializzazioni varie */
  store = outFrame->store;
  frameLen = outFrame->numRow * outFrame->numCol * outFrame->depth;

  for (j = 0; j < frameLen; j++) {

	/* Legge lo stesso elemento da tutti i frame */
    for (i = 0, tmp = 0; i < buf->numFrame; i++)
	  tmp += buf->frameA[i].store[j];

	/* Memorizza nel frame di output */
	*store++ = tmp / buf->numFrame;
  }
}


/*
 * Media spaziale sull'asse x (profondita').
 *
 * Input:
 *		frame *aFrame;
 *
 * Comportamento:
 *		il frame originale viene *sovrascritto*.
 *		Se non riesce ad allocare memoria per le sue strutture ausiliarie scrive un msg su stderr
 *		e termina il prg.
 */
void doAverageOnX (frame *aFrame)
{
  static char *funName = ": doAverageOnX()";

  register int i;
  register float64 *store,
					tmp;
  int frameDim;									/* dimensione del frame originale */
  frame copy;									/* un frame copia */

  /* Effettua una copia del frame originale */
  if (framecpy (&copy, aFrame) == ERROR)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  frameDim = copy.numCol * copy.numRow * copy.depth;
  store = aFrame->store;

  for (i = 0, tmp = 0; i < frameDim; i++) {
	tmp += copy.store[i];

	/* Alla fine di ogni riga calcola il valor medio e lo memorizza */
	if ((i+1) % copy.depth == 0) {
	  *store++ = tmp / copy.depth;
	  tmp = 0;
	}
  }

  aFrame->depth = 1;							/* dopo la media la profondita' e' uno */

  free (copy.store);
}


/*
 * Media spaziale sull'asse y (righe).
 *
 * Input:
 *		frame *aFrame;
 *
 * Comportamento:
 *		il frame originale viene *sovrascritto*.
 *		Se non riesce ad allocare memoria per le sue strutture ausiliarie scrive un msg su stderr
 *		e termina il prg.
 */
void doAverageOnY (frame *aFrame)
{
  static char *funName = ": doAverageOnY()";

  register int i, j, k;
  register float64 *store, 						/* dove memorizzare il frame risultante */
				  *tmpRow, 						/* una riga di supporto */
				  *row;							/* puntatore ad una riga del frame */
  int rowLen;									/* dimensione di una riga del frame (in byte) */

  /* Alcune inizializzazioni */
  store = aFrame->store;						/* cosi' sovrascrivo il frame originale */
  row   = aFrame->store;
  rowLen = sizeof (float64) * aFrame->depth;

  /* Alloca memoria per una riga di supporto */
  if ((tmpRow = (float64 *) malloc (rowLen)) == NULL)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Elabora una colonna alla volta */
  for (i = 0; i < aFrame->numCol; i++) {

	memset (tmpRow, 0, rowLen);

	/* Somma tutte le righe di una colonna */
	for (j = 0; j < aFrame->numRow; j++, row += aFrame->depth)

	  /* Somma tutti gli elementi di una riga */
	  for (k = 0; k < aFrame->depth; k++)
		tmpRow[k] += row[k];

	/* Media e copia nel frame originale */
	for (j = 0; j < aFrame->depth; j++)
	  *store++ = tmpRow[j] / aFrame->numRow;
  }

  aFrame->numRow = 1;							/* dopo la media il numero di righe e' uno */

  free (tmpRow);
}


/*
 * Media spaziale sull'asse z (colonne).
 *
 * Input:
 *		frame *aFrame;
 *
 * Comportamento:
 *		il frame originale viene *sovrascritto*.
 *		Se non riesce ad allocare memoria per le sue strutture ausiliarie scrive un msg su stderr
 *		e termina il prg.
 */
void doAverageOnZ (frame *aFrame)
{
  static char *funName = ": doAverageOnZ()";

  register int i, j, k;
  register float64 *store, 						/* dove memorizzare il frame risultante */
				  *tmpRow, 						/* una riga di supporto */
				  *row;							/* puntatore ad una riga del frame */
  int planeDim;									/* dimensione di un piano del frame */
  int rowLen;									/* dimensione di una riga del frame (in byte) */

  /* Inizializzazioni varie */
  planeDim = aFrame->numRow * aFrame->depth;
  store = aFrame->store;
  rowLen = sizeof (float64) * aFrame->depth;

  /* Alloca memoria per una riga di supporto */
  if ((tmpRow = (float64 *) malloc (rowLen)) == NULL)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Elabora per righe */
  for (i = 0; i < aFrame->numRow; i++) {

	memset (tmpRow, 0, rowLen);

	row = aFrame->store + i * aFrame->depth;		/* riga del primo piano */

	/* Somma tutte le righe di un piano */
	for (j = 0; j < aFrame->numCol; j++) {

	  for (k = 0; k < aFrame->depth; k++)
		tmpRow[k] += row[k];

	  row += planeDim;								/* la stessa riga ma nel prossimo piano */
	}

	/* Media e scrittura nel frame originale */
	for (j = 0; j < aFrame->depth; j++)
	  *store++ = tmpRow[j] / aFrame->numCol;
  }

  aFrame->numCol = 1;							/* dopo la media c'e' una sola colonna */

  free (tmpRow);
}


/*
 * Media spazio-temporale per un buffer di frame. Il risultato della media e' un frame.
 * Il frame di output deve essere gia' allocato, ad esclusione del campo store.
 *
 * Input:
 *		frameBuf *buf: un buffer di frame;
 *		frame *outFrame: frame di output;
 *		userOption *optPtr: record delle opzioni utente;
 *
 * Output:
 *		se non riesce ad allocare memoria ritorna ERROR altrimenti OK.
 */
void space_time_average (frameBuf *buf, frame *outFrame, userOption *optPtr)
{
  static char *funName = ": space_time_average()";

  frame dummy;

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  /* Media temporale: solo per intervalli di frame maggiori di uno */ 
  if (optPtr->firstFrame < optPtr->lastFrame) {

	if ((dummy.store = (float64 *) malloc (sizeof (float64) * optPtr->subLat.len)) == NULL)
	  error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

	doTimeAverage (buf, &dummy);
  }
  else
	/* Semplice copia dell'unico frame del buffer */
	if (framecpy (&dummy, &(buf->frameA[0])) == ERROR)
	  error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Media spaziale */
  if (optPtr->averageType & AVERAGE_ON_X)
	doAverageOnX (&dummy);

  if (optPtr->averageType & AVERAGE_ON_Y)
	doAverageOnY (&dummy);

  if (optPtr->averageType & AVERAGE_ON_Z)
	doAverageOnZ (&dummy);

  /* Copia nel frame di output */
  if (framecpy (outFrame, &dummy) == ERROR)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  free (dummy.store);
}


/*
 * Moltiplica un frame per un dato coefficente.
 *
 * Input:
 *		frame *frameA: l'array di frame;
 *		float64 coeff: il coefficente moltiplicativo.
 */
void multiplyFrame(frame *aFrame, float64 coeff)
{
  register int j;
  register float64 *store;
  int frameLen;

  frameLen = aFrame->depth * aFrame->numRow * aFrame->numCol;
  store = aFrame->store;
  for (j = 0; j < frameLen; j++, store++)
	*store *= coeff;
}


/*
 * Scrittura di un frame su file.
 * Il file deve essere gia' aperto in scrittura.
 *
 * Input:
 *		frame *aFrame: il frame;
 *		FILE  *fp: il file;
 *		int writeHeader: specifica se si vuole o meno un header informativo all'inizio del file;
 *
 * Output:
 *		ERROR: errore in scrittura;
 *		OK: tutto bene;
 *
 * Note:
 *		la scrittura del frame avviene per righe.
 *
 */
int writeFrame (frame *aFrame, FILE *fp, int writeHeader)
{
  register int i,
			rowLen;						/* lunghezza di una riga del frame */
  register float64 *datum;				/* puntatore ai dati da scrivere */
  int frameDim;							/* dimensione del campo store di un frame */

#ifdef DEBUG
  printf (": writeFrame()\n");
#endif

  frameDim = aFrame->numCol * aFrame->numRow * aFrame->depth;
  rowLen = aFrame->depth;
  datum = aFrame->store;

  /* Piccolo header */
  if (writeHeader)
	fprintf (fp, "# Colonne:%d\n# Righe:%d\n# Profondita':%d\n", aFrame->numCol, aFrame->numRow, aFrame->depth);

  /* Da migliorare ... ad esempio scrivere una riga intera alla volta */
  for (i = 0; i < frameDim; i++) {

	fprintf (fp, "%f\n", *datum++);

	/* Alla fine di ogni riga scrive una linea vuota */
	if ((i+1) % rowLen == 0)
	  fprintf (fp, "\n");
  }

  /* Controllo per eventuali errori di I/O */
  if (ferror (fp))
	return ERROR;
  else
	return OK;
}


/*
 * Scrittura di un frame di risultati su file. 
 *
 * Input:
 *		frame *aFrame: il frame da scrivere;
 *		userOption *optPtr: le opzioni selezionate dall'utente;
 *		int whatDatum: il tipo di frame (densita', q.di moto, etc..);
 *
 * Comportamento:
 *		emette un msg di errore e termina il programma se almeno una delle seguenti condizioni e'
 *		soddisfatta:
 *			- non riesce ad aprire (creare) un file;
 *			- si verifica un errore nella scrittura di un file.
 */
void writeResult (frame *aFrame, userOption *optPtr, int whatDatum)
{
  char fileName[MAX_FILENAME_LEN];				/* nome file di output */
  char suffix = ' ';					/* estensione per il nome file di output */
  int writeInfo;						/* specifica se si vuole un header a inizio file */
  FILE *fp;

#ifdef DEBUG
  printf (": writeResult()\n");
#endif

  /* Seleziona il suffisso per il nome del file di output */
  switch (whatDatum) {
	case EXTRACT_DENSITY: 	suffix = 'd'; break;
	case EXTRACT_X: 		suffix = 'x'; break;
	case EXTRACT_Y: 		suffix = 'y'; break;
	case EXTRACT_Z: 		suffix = 'z'; break;
	case EXTRACT_MODULUS:	suffix = 'm';
  }

  /* Apertura file di output */
  sprintf (fileName, "%s.%c", optPtr->outFileName, suffix);
  if ((fp = fopen (fileName, "w")) == NULL)
	error ("%s '%s' %s\n", msg[MSG_CANT_OPEN_FILE], fileName);

  /* Scrittura header se richiesta */
  if ((writeInfo = (optPtr->setOptions & OPT_INFO))) {
	char header[50] = "# Velocita': componente ";

	/* Costruisce l'header */
	switch (whatDatum) {
	  case EXTRACT_X:		strcat (header, "X"); break;
	  case EXTRACT_Y:		strcat (header, "Y"); break;
	  case EXTRACT_Z:		strcat (header, "Z"); break;
	  case EXTRACT_DENSITY: sprintf (header, "# Densita'"); break;
	  case EXTRACT_MODULUS:
			sprintf (header, "# Modulo: componenti estratte"); 
			if (optPtr->whatToExtract & EXTRACT_X)
			  strcat (header, " X");
			if (optPtr->whatToExtract & EXTRACT_Y)
			  strcat (header, " Y");
			if (optPtr->whatToExtract & EXTRACT_Z)
			  strcat (header, " Z");
	}
	fprintf (fp, "%s\n", header);
	if (ferror (fp))
	  error ("%s '%s'\n", msg[MSG_WRITE_ERROR], fileName);
  }

  /* Scrittura frame su file */
  if (writeFrame (aFrame, fp, writeInfo) == ERROR)
	error ("%s '%s'\n", msg[MSG_WRITE_ERROR], fileName);

  fclose (fp);
}


/*
 * Calcola il modulo di un buffer di frame.
 * Scrive il risultato in un frame (deve essere gia' allocato).
 *
 * Input:
 *		frameBuf *buf: il buffer di frame;
 *		frame *dst: frame destinazione;
 */
void doModulus (frameBuf *buf, frame *dst)
{
  register int i, j;
  register float64 *store, tmp;
  int frameLen;

  store = dst->store;
  frameLen = buf->frameA->numRow * buf->frameA->numCol * buf->frameA->depth;

  if (buf->numFrame == 1)
	/* Con un solo frame e' inutile elevare a potenza ed estarre la radice */
	for (i = 0; i < frameLen; i++)
	  *store++ = fabs (buf->frameA->store[i]);
  else
	for (i = 0; i < frameLen; i++) {
	  for (j = 0, tmp = 0; j < buf->numFrame; j++)
		tmp += (buf->frameA[j].store[i] * buf->frameA[j].store[i]);
	  *store++ = sqrt (tmp);
 	}
}


/*
 * Carica il modulo delle componenti della velocita' scelte.
 *
 * Input:
 *		frameBuf *dst: il buffer dove scaricare i dati;
 *		inputData *inputPtr: i dati di input;
 *		userOption *optPtr: record delle opzioni utente;
 *
 * Note:
 *		alloca la memoria necessaria per il buffer passato per parametro.
 */
void loadModulus (frameBuf *dst, inputData *inPtr, userOption *optPtr)
{
  char *funName = ": loadModulus()";

  register int i,j,k;
  frameBuf buf;										/* buffer di lettura */
  frame dummy;										/* un altro buffer */
  int row, col, depth,								/* dimensioni del sottoreticolo da elaborare */
	  nbuf;
  int32 sds_id;
  int extract[3] = {EXTRACT_X, EXTRACT_Y, EXTRACT_Z};

#ifdef DEBUG
  printf ("%s\n", funName);
#endif

  if (optPtr->setOptions & OPT_SUB_LATTICE) {

	/* Buffer di lettura per un frame intero */
    dummy.store = (float64 *) malloc (sizeof (float64) * inPtr->frameLen);
    if (dummy.store == NULL)
	  error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);
	dummy.numCol = inPtr->numCol;
	dummy.numRow = inPtr->numRow;
	dummy.depth  = inPtr->depth;
  }

  /* Dimensioni di un sub-frame da leggere */
  row = optPtr->subLat.lastRow - optPtr->subLat.firstRow + 1;
  col = optPtr->subLat.lastCol - optPtr->subLat.firstCol + 1;
  depth = optPtr->subLat.lastDepth - optPtr->subLat.firstDepth + 1;

  /* Conta quante componenti estrarre */
  for (i = 0, nbuf = 0; i < 3; i++)
	if (optPtr->whatToExtract & extract[i])
	  nbuf++;

  /* Alloca il buffer di frame per leggere le componenti */
  if (allocate (&buf, nbuf, row, col, depth) == ERROR)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  /* Alloca il buffer di frame per il modulo */
  if (allocate (dst, inPtr->effNumFrame, row, col, depth) == ERROR)
	error ("%s %s\n", msg[MSG_MALLOC_FAILED], funName);

  for (i = 0, j = optPtr->firstFrame+1; i < inPtr->effNumFrame; i++, j++) {

	/* Seleziona il dataset per il frame richiesto */
	if ((sds_id = SDselect (optPtr->infile, j)) == FAIL)
	  error ("%s %s\n", msg[MSG_SDSELECT_FAILED], funName);

	for (k = 0, nbuf = 0; k < 3; k++)

	  /* Carica le componenti richieste */
	  if (optPtr->whatToExtract & extract[k]) {

		if (optPtr->setOptions & OPT_SUB_LATTICE) {

		  /* Estrae solo i dati richiesti dall'utente con il comando -s */
		  loadFrame (sds_id, &dummy, extract[k], inPtr->frameLen);
		  extractSubLat (&dummy, &(buf.frameA[nbuf]), &optPtr->subLat);

		}
		else
		  /* Carica un frame intero di dati */
		  loadFrame (sds_id, &(buf.frameA[nbuf]), extract[k], inPtr->frameLen);

		nbuf++;
	  }

	if (SDendaccess (sds_id) == FAIL)
	  error ("%s %s\n", msg[MSG_SDENDACC_FAILED], funName);

	doModulus (&buf, &(dst->frameA[i]));
  }

  /* Libera la memoria inutile */
  deallocate (&buf);
  if (optPtr->setOptions & OPT_SUB_LATTICE)
	free (dummy.store);
}


/*
 * Effettua 'veramente' tutto il lavoro, ma solo su una determinata quantita'.
 * E' chiamata solamente da doJob().
 *
 * Input:
 *		inputData *inputPtr: i dati di input;
 *		userOption *optPtr: record delle opzioni utente;
 *		int whatDatum: su quale quantita' lavorare (densita', etc...);
 */
void reallyDoJob(inputData *inPtr, userOption *optPtr, int whatDatum)
{
  frameBuf i_buf;									/* buffer di frame di input */
  frame resultFrame;

#ifdef DEBUG
  printf (": reallyDoJob()\n");
#endif

  /* Il calcolo del modulo richiede una funzione personale, per ridurre l'uso di memoria */
  if (whatDatum == EXTRACT_MODULUS)
	loadModulus (&i_buf, inPtr, optPtr);
  else
	loadData (&i_buf, inPtr, optPtr, whatDatum);

  space_time_average (&i_buf, &resultFrame, optPtr);

  if (optPtr->setOptions & OPT_COEFF)
	multiplyFrame (&resultFrame, optPtr->coefficent);

  writeResult (&resultFrame, optPtr, whatDatum);

  /* Dealloca la memoria inutile */
  deallocate (&i_buf);
  free (resultFrame.store);
}


/*
 * Esegue una media spazio-temporale dei dati di input.
 *
 * Input:
 *		inputData *inputPtr: i dati di input;
 *		userOption *optPtr: record delle opzioni utente;
 */
void doJob(inputData *inPtr, userOption *optPtr)
{
#ifdef DEBUG
  printf (": doJob()\n");
#endif

  /* Media per la densita' */
  if (optPtr->whatToExtract & EXTRACT_DENSITY)
	reallyDoJob (inPtr, optPtr, EXTRACT_DENSITY);

  /* Media per la velocita' */
  if (optPtr->whatToExtract & EXTRACT_SPEED) {

	int extract[3] = {EXTRACT_X, EXTRACT_Y, EXTRACT_Z};
	int i;

	for (i = 0; i < 3; i++)
	  if (optPtr->whatToExtract & extract[i])
		reallyDoJob (inPtr, optPtr, extract[i]);
  }

  /* Media per il modulo della velocita' */
  if (optPtr->whatToExtract & EXTRACT_MODULUS)
	reallyDoJob (inPtr, optPtr, EXTRACT_MODULUS);
}


/*
 * Chiude il file di input.
 *
 * Input:
 *		userOption *optPtr: le opzioni selezionate dall'utente;
 */
void closeInputFile (userOption *optPtr)
{
  char *funName = ": closeInputFile()";

  if (SDend (optPtr->infile) == FAIL)
	error ("%s %s\n", msg[MSG_SDEND_FAILED], funName);
}


void main (int argc, char *argv[])
{
  userOption optRec;					/* il record delle opzioni utente */
  inputData	 inputDataRec;				/* specifica il reticolo da elaborare */

  /* Cosi' error() scrive su stderr */
  error_logfile = stderr;

  /* La linea di comando deve avere almeno un argomento */
  if (argc < 2)
	error ("%s\n", msg[MSG_USAGE]);

  /* Inizializzazioni preliminari */
  init (&optRec);

  /* Lettura della linea di comando */
  parseCommandLine (argc, argv, &optRec);

  /* Controllo preliminare dei comandi letti */
  preliminaryCheck (&optRec);

  /* Apre file di input */
  openInputFile (&optRec);

  /* Legge le dimensioni di un frame di dati */
  readFrameDim (&inputDataRec, &optRec);

  /* Imposta i valori di default delle opzioni utente */
  setDefaultValues (&optRec, &inputDataRec);

  /* Controllo consistenza delle opzioni utente */
  checkUserOptions (&optRec, &inputDataRec);

  /* Ok, ora puo' partire tutto il lavoro */
  doJob (&inputDataRec, &optRec);

  /* Fine: chiude file di input */
  closeInputFile (&optRec);
}
