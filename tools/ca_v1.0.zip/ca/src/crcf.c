/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * crcf.c	"Check ResourCe File"
 *
 * Controlla la validita' di un file di risorse.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>

#include "ca_cdef.h"
#include "crcf.h"


FILE *error_logfile;


/*
 * Semplice parsing della linea di comando.
 *
 * Input:
 *		int argc, char *argv[]: i soliti noti...
 *
 * Output:
 *		char *rc_file: il nome del file di risorse;
 *
 * Note:
 *		se si verifica un errore nella lettura delle risorse emette un msg di errore e
 *		termina il programma.
 */
void parseCommandLine (int argc, char *argv[], char *rc_file)
{
  extern int opterr;
  extern char *optarg;
  char opt;

#ifdef DEBUG
  printf (": parseCommandLine()\n");
#endif

  opterr = 0;					/* cosi' getopt() non segnala errori all'utente */

  /* L'unica opzione e' -h per l'help */
  while ((opt = getopt (argc, argv, "h")) != -1)

	switch (opt) {

	  /* Richiesta di aiuto */
	  case 'h':
		printf ("%s\n", msg[HELP]);
		exit (1);

	  default:
		goto end_parsing;
	}

end_parsing:
  if (argc < 2)
	error ("%s\n", msg[USAGE]);

  strcpy (rc_file, argv[optind]);
}


/*
 * Legge le risorse dal <resource_file>.
 *
 * Input:
 *		char *fileName:	nome del <resource_file>;
 *		simulInData *simRecPtr: record da riempire con i valori delle risorse;
 *
 * Output:
 *		passaggio per indirizzo:
 *		int *numObstacle: il numero degli ostacoli letti;
 *		int obstacleList[][]: la lista degli ostacoli letti;
 *		int inputRes[]:	specifica quali risorse sono state specificate e quali no.
 */
void readResourceFile (char *fileName, simulInData *simRecPtr, int inputRes[], int *numObstacle,
						obstacle **obsList)	
{
  FILE *fp;
  int  i = 0,
	   p[6],
	   numLine = 0,										/* numero linee lette */
	   resource,										/* indice di risorsa */
	   alreadySet = FALSE,
	   obsCount = 0,									/* conta gli ostacoli letti */
	   inputError = FALSE;								/* segnala errore di input */
  char *buf,
	   dummy[BUFLEN],
	   inBuf[BUFLEN],									/* buffer di lettura */
	   resName[BUFLEN];									/* nome di una risorsa */
  obstacle *list = NULL;

#ifdef DEBUG
  printf (": readResourceFile()\n");
#endif

  /* Apre il resource_file */
  if ((fp = fopen (fileName, "r")) == NULL)
	error ("%s '%s'\n", msg[CANT_OPEN_FILE], fileName);

  /**************************************************************************/
  /* Conta tutti gli ostacoli presenti nel <resource_file> per poi allocare */
  /* esattamente un array di ostacoli.									  	*/
  /* Si poteva implementare una soluzione a lista concatenata ma preferisco */
  /* gli array!															  	*/
  /**************************************************************************/
  while (fgets (inBuf, BUFLEN, fp) != NULL) {

	/* Salta commenti e linee vuote */
 	if ((*inBuf == '#') || (*inBuf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
    if (sscanf (inBuf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  inputError = TRUE;
	  break;
   	}

	/* Interessa solo la risorsa ostacolo */
	if (searchStr (resourceSet, NUMRES, resName) == RES_OBSTACLE)
	  obsCount++;
  }

  /* Alloca la memoria per l'array di ostacoli */
  if (!inputError && (obsCount > 0))
	list = (obstacle *) malloc (obsCount * sizeof (obstacle));

  rewind (fp);									/* 'riavvolge' il file */

  /************************************/
  /* Lettura 'vera' del resource_file */
  /************************************/
  while (fgets (buf = inBuf, BUFLEN, fp) != NULL) {

	numLine++;

	/* Salta commenti e linee vuote */
 	if ((*buf == '#') || (*buf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
    if (sscanf (buf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  fprintf (stderr, "%s %d %s\n", msg[MSG_HEADER], numLine, msg[BAD_RESOURCE_FILE]);
	  continue;
	}

	while (*buf++ != ':');					/* si sposta sul valore della risorsa */

	/* Cerca la risorsa nell'insieme delle risorse e memorizza il relativo valore nel
 	 * record dei parametri.
  	 */
	switch (resource = searchStr (resourceSet, NUMRES, resName)) {
	  case RES_NUMITER:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numIter) == 0);
					alreadySet = inputRes[RES_NUMITER];
					if (!inputError) inputRes[RES_NUMITER] = TRUE;
				 	break;
	  case RES_NUMROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numRow) == 0);
					alreadySet = inputRes[RES_NUMROW];
					if (!inputError) inputRes[RES_NUMROW] = TRUE;
				   	break;
	  case RES_NUMCOL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numCol) == 0);
					alreadySet = inputRes[RES_NUMCOL];
					if (!inputError) inputRes[RES_NUMCOL] = TRUE;
				   	break;
	  case RES_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->depth) == 0);
					alreadySet = inputRes[RES_DEPTH];
					if (!inputError) inputRes[RES_DEPTH] = TRUE;
			      	break;
	  case RES_MACRO_COL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->macroCellCol) == 0);
					alreadySet = inputRes[RES_MACRO_COL];
					if (!inputError) inputRes[RES_MACRO_COL] = TRUE;
			      	break;
	  case RES_MACRO_ROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->macroCellRow) == 0);
					alreadySet = inputRes[RES_MACRO_ROW];
					if (!inputError) inputRes[RES_MACRO_ROW] = TRUE;
			      	break;
	  case RES_MACRO_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->macroCellDepth) == 0);
					alreadySet = inputRes[RES_MACRO_DEPTH];
					if (!inputError) inputRes[RES_MACRO_DEPTH] = TRUE;
			      	break;
	  case RES_TRANSIENT:
					inputError = (sscanf (buf, " %d ", &simRecPtr->transient) == 0);
					alreadySet = inputRes[RES_TRANSIENT];
					if (!inputError) inputRes[RES_TRANSIENT] = TRUE;
			      	break;
	  case RES_SAMPLE_STEP:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplingStep) == 0);
					alreadySet = inputRes[RES_SAMPLE_STEP];
					if (!inputError) inputRes[RES_SAMPLE_STEP] = TRUE;
			      	break;
	  case RES_SAMPLE_PER_FRAME:
					inputError = (sscanf (buf, " %d ", &simRecPtr->samplePerFrame) == 0);
					alreadySet = inputRes[RES_SAMPLE_PER_FRAME];
					if (!inputError) inputRes[RES_SAMPLE_PER_FRAME] = TRUE;
			      	break;
	  case RES_DENSITY:
					inputError = (sscanf (buf, " %lf ", &simRecPtr->n) == 0);
					alreadySet = inputRes[RES_DENSITY];
					if (!inputError) inputRes[RES_DENSITY] = TRUE;
				 	break;
	  case RES_TABFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->collTabFileName) == 0);
					alreadySet = inputRes[RES_TABFILE];
					if (!inputError) inputRes[RES_TABFILE] = TRUE;
				    break;
	  case RES_LOGFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->logFileName) == 0);
					alreadySet = inputRes[RES_LOGFILE];
					if (!inputError) inputRes[RES_LOGFILE] = TRUE;
				    break;
	  case RES_BOUND_COND:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;
					alreadySet = inputRes[RES_BOUND_COND];
					if (!alreadySet)
					  /* Cerca di assegnare il valore alla risorsa */
					  if ((simRecPtr->boundaryCond = searchStr (boundaryValue, 2, dummy)) == RES_UNKNOWN)
					  	inputError = TRUE;
					if (!inputError) inputRes[RES_BOUND_COND] = TRUE;
				    break;
	  case RES_OBSTACLE:
					/* Un controllo quasi inutile.. */
					if ((inputError = (i >= obsCount)))
					  break;

					inputError = (sscanf (buf, " %d %d %d %d %d %d ", &p[0], &p[1],
									&p[2], &p[3], &p[4], &p[5]) != 6);

					if (!inputError) {
						list[i].firstRow   = p[0];
						list[i].firstDepth = p[1];
						list[i].lastRow    = p[2];
						list[i].lastDepth  = p[3];
						list[i].firstCol   = p[4];
						list[i].lastCol    = p[5];
						i++;				/* incrementa contatore degli ostacoli letti */
					}
					break;
	  case RES_DATA_COMPRESSION:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;
					alreadySet = inputRes[RES_DATA_COMPRESSION];
					if (!alreadySet)
					  /* Cerca di assegnare il valore alla risorsa */
					  if ((simRecPtr->dataCompression = searchStr (dataCompValue, 2, dummy)) == RES_UNKNOWN)
					  	inputError = TRUE;
					if (!inputError) inputRes[RES_DATA_COMPRESSION] = TRUE;
				    break;
	  case RES_INJECTION_IN:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;
					alreadySet = inputRes[RES_INJECTION_IN];
					if (!alreadySet)
					  /* Cerca di assegnare il valore alla risorsa */
					  if ((simRecPtr->injectionIn = searchStr (injectionValue, 3, dummy)) == RES_UNKNOWN)
					  	inputError = TRUE;
					if (!inputError) inputRes[RES_INJECTION_IN] = TRUE;
				    break;
	  case RES_INJECTION_OUT:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;
					alreadySet = inputRes[RES_INJECTION_OUT];
					if (!alreadySet)
					  /* Cerca di assegnare il valore alla risorsa */
					  if ((simRecPtr->injectionOut = searchStr (injectionValue, 3, dummy)) == RES_UNKNOWN)
					  	inputError = TRUE;
					if (!inputError) inputRes[RES_INJECTION_OUT] = TRUE;
				    break;
	  case RES_INJECTION_AREA_IN:
					inputError = (sscanf (buf, " %d %d", &simRecPtr->firstInjectionRowIn,
											&simRecPtr->lastInjectionRowIn) < 2);
					alreadySet = inputRes[RES_INJECTION_AREA_IN];
					if (!inputError) inputRes[RES_INJECTION_AREA_IN] = TRUE;
				 	break;
	  case RES_INJECTION_AREA_OUT:
					inputError = (sscanf (buf, " %d %d", &simRecPtr->firstInjectionRowOut,
											&simRecPtr->lastInjectionRowOut) < 2);
					alreadySet = inputRes[RES_INJECTION_AREA_OUT];
					if (!inputError) inputRes[RES_INJECTION_AREA_OUT] = TRUE;
				 	break;
	  case RES_LATTICE_STATUS:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;
					alreadySet = inputRes[RES_LATTICE_STATUS];
					if (!alreadySet)
					  /* Cerca di assegnare il valore alla risorsa */
					  if ((simRecPtr->latticeStatus = searchStr (latticeStatusValue, 3, dummy)) == RES_UNKNOWN)
						inputError = TRUE;
					if (!inputError) inputRes[RES_LATTICE_STATUS] = TRUE;
				    break;
	  case RES_LATFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->latticeFileName) == 0);
					alreadySet = inputRes[RES_LATFILE];
					if (!inputError) inputRes[RES_LATFILE] = TRUE;
				    break;
	  case RES_STATUS_FILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->statusFileName) == 0);
					alreadySet = inputRes[RES_STATUS_FILE];
					if (!inputError) inputRes[RES_STATUS_FILE] = TRUE;
				    break;
	  case RES_OUTFILE:
					inputError = (sscanf (buf, " %s ", simRecPtr->outFileName) == 0);
					alreadySet = inputRes[RES_OUTFILE];
					if (!inputError) inputRes[RES_OUTFILE] = TRUE;
				    break;
	  case RES_SPEED:
					inputError = (sscanf (buf, " %lf %lf %lf ", &simRecPtr->u[0], &simRecPtr->u[1], &simRecPtr->u[2]) != 3);
					alreadySet = inputRes[RES_SPEED];
					if (!inputError) inputRes[RES_SPEED] = TRUE;
				    break;
	  case RES_UNKNOWN:
					fprintf (stderr, "%s %d %s %s\n", msg[MSG_HEADER], numLine, 
								msg[UNKNOWN_RESOURCE], resName);
					alreadySet = inputError = FALSE;
	}
	if (inputError)
	  fprintf (stderr, "%s %d %s\n", msg[MSG_HEADER], numLine, msg[BAD_RESOURCE_VALUE]);
	if (alreadySet)
	  fprintf (stderr, "%s %d %s\n", msg[MSG_HEADER], numLine, msg[ALREADY_SET_RESOURCE]);
  }

  /* Se uscendo dal ciclo non e' EOF allora si e' verificato un errore di I/O */
  if (!feof (fp)) {
	fclose (fp);
	sprintf (inBuf, "%d ", numLine);
	error ("%s %d %s\n", msg[MSG_HEADER], numLine, msg[IOERROR]);
  }
  fclose (fp);
  *numObstacle = obsCount;
  *obsList = list;
}


/*
 * Controlla la validita' dei valori delle risorse lette. 
 *
 * Input:
 *		simulInData *simRecPtr: record dei parametri; 
 *		int inputRes[]:	specifica quali risorse sono state specificate e quali no.
 *		int numObstacle: il numero degli ostacoli;
 *		int obstacleList: la lista degli ostacoli;
 *
 * Output:
 *		nessuno.
 */
void doCheck (simulInData *simRecPtr, int inputRes[], int numObstacle, obstacle *obsList)
{
  eVect e_real;							/* un vettore dello spazio euclideo */
  int i, 
	resource;							/* indice di risorsa */

#ifdef DEBUG
  printf (": doCheck()\n");
#endif

  /* Controlla se tutte le risorse (a parte l'ultima) sono state specificate */
  for (resource = 0; resource < NUMRES - 1; resource++)
	if (!inputRes[resource])
	  fprintf (stderr, "%s %s\n", msg[UNSPEC_RESOURCE], resourceSet[resource]);

  /* Controlla la validita' della densita' specificata */
  if (inputRes[RES_DENSITY])
	if ((simRecPtr->n <= 0) || (simRecPtr->n >= 12))
	  fprintf (stderr, "%s \n", msg[BAD_DENSITY_VALUE]);

  /* Controlla la validita' della velocita' specificata */
  if (inputRes[RES_SPEED])
	if (MODULUS(simRecPtr->u) >= 1)
	  fprintf (stderr, "%s \n", msg[BAD_SPEED_VALUE]);

  /* Controlla se la profondita' e' multipla della lunghezza di un u_int */
  if (inputRes[RES_DEPTH])
	if (simRecPtr->depth % UINTLEN)
	  fprintf (stderr, "%s\n", msg[BAD_DEPTH_VALUE]);

  /* Controlla l'esistenza del collision table file */
  if (inputRes[RES_TABFILE]) {
	FILE *dummy;

	if ((dummy = fopen (simRecPtr->collTabFileName, "r")) == NULL)
	  fprintf (stderr, "%s '%s'\n", msg[CANT_OPEN_FILE], simRecPtr->collTabFileName);
	else 
	  fclose (dummy);
  }

  /* Controlla la dimensione del lattice_file specificato */
  if (inputRes[RES_LATFILE] && inputRes[RES_NUMCOL] && inputRes[RES_NUMROW] && inputRes[RES_DEPTH]) {
	long fileSize, latticeSize;

	/* La lunghezza in bit del lattice_file deve essere uguale al numero di nodi del reticolo */
	latticeSize = simRecPtr->numRow * simRecPtr->numCol * simRecPtr->depth;
	fileSize = fsize (simRecPtr->latticeFileName);
	if (fileSize == -1) 
	  fprintf (stderr, "%s '%s' o %s\n", msg[CANT_OPEN_FILE], simRecPtr->latticeFileName, msg[IOERROR]);
	else 
	  /* Deve esserci un bit per ogni nodo del reticolo */
	  if (fileSize * 8 != latticeSize)
	    fprintf (stderr, "%s\n", msg[BAD_LATTICE_FILE]);
  }

  /* Controlla le probabilita' calcolate secondo Chapman-Enskog */
  if (inputRes[RES_SPEED] && inputRes[RES_DENSITY])
	for (i = 0; i < NUMVECT; i++) {
	  double prob;

	  /* Trasforma il velocity vector in coordinate reali */
	  e_real[0] = DOT_PRODUCT (inverse[0], e[i]);
	  e_real[1] = DOT_PRODUCT (inverse[1], e[i]);
	  e_real[2] = DOT_PRODUCT (inverse[2], e[i]);

	  /* Calcolo approssimazione */
	  prob = (simRecPtr->n / (double) NUMVECT) * (1 + 3 * DOT_PRODUCT (e_real, simRecPtr->u));

	  /* Controllo validita' */
	  if (prob >= 1.0)
		fprintf (stderr, "%s %d\n", msg[PROBABILITY_TOO_BIG], i);

	  if (prob <= 0.0)
		fprintf (stderr, "%s %d\n", msg[PROBABILITY_TOO_SMALL], i);
  	}

  /* Controlla la validita' delle dimensioni delle macrocella */
  if (inputRes[RES_LATFILE] && inputRes[RES_NUMCOL] && inputRes[RES_NUMROW] && 
	inputRes[RES_DEPTH] && inputRes[RES_MACRO_COL] && inputRes[RES_MACRO_ROW] && inputRes[RES_MACRO_DEPTH]) {
	if (simRecPtr->numRow % simRecPtr->macroCellRow)
	  fprintf (stderr, "%s, %s\n", msg[BAD_MACRO_DIM], resourceSet[RES_MACRO_ROW]);
    if (simRecPtr->numCol % simRecPtr->macroCellCol)
	  fprintf (stderr, "%s, %s\n", msg[BAD_MACRO_DIM], resourceSet[RES_MACRO_COL]);
    if (simRecPtr->depth % simRecPtr->macroCellDepth)
	  fprintf (stderr, "%s, %s\n", msg[BAD_MACRO_DIM], resourceSet[RES_MACRO_DEPTH]);
  }

  /* Controlla validita' durata transitorio */
  if (inputRes[RES_TRANSIENT] && inputRes[RES_NUMITER])
	if (simRecPtr->transient > simRecPtr->numIter)
	  fprintf (stderr, "%s\n", msg[BAD_TRANSIENT]);

  /* Controlla validita' passo di campionamento e numero campioni per frame */
  if (inputRes[RES_TRANSIENT] && inputRes[RES_NUMITER] && inputRes[RES_SAMPLE_STEP]) {
    div_t numSample;

	/* Calcola il numero totale di campionamenti */
	numSample = div (simRecPtr->numIter - simRecPtr->transient, simRecPtr->samplingStep);

	/* Congruenza del passo di campionamento */
	if (numSample.rem != 0)
	  fprintf (stderr, "%s\n", msg[BAD_SAMPLE_STEP]);

	/* Congruenza del numero di campioni per frame */
	if (inputRes[RES_SAMPLE_PER_FRAME])
	  if (numSample.quot % simRecPtr->samplePerFrame != 0)
	    fprintf (stderr, "%s\n", msg[BAD_SAMPLE_PER_FRAME]);
  }

  /* Controllo validita' area di iniezione di ingresso */
  if (inputRes[RES_INJECTION_AREA_IN] && inputRes[RES_NUMCOL] && inputRes[RES_NUMROW] && inputRes[RES_DEPTH])
	if ((simRecPtr->firstInjectionRowIn < 0) || (simRecPtr->firstInjectionRowIn >= simRecPtr->numRow) ||
		(simRecPtr->lastInjectionRowIn < 0) || (simRecPtr->lastInjectionRowIn >= simRecPtr->numRow) ||
		(simRecPtr->firstInjectionRowIn > simRecPtr->lastInjectionRowIn))
	  fprintf (stderr, "%s\n", msg[BAD_INJECTION_AREA_IN]);

  /* Controllo validita' area di iniezione di uscita */
  if (inputRes[RES_INJECTION_AREA_OUT] && inputRes[RES_NUMCOL] && inputRes[RES_NUMROW] && inputRes[RES_DEPTH])
	if ((simRecPtr->firstInjectionRowOut < 0) || (simRecPtr->firstInjectionRowOut >= simRecPtr->numRow) ||
		(simRecPtr->lastInjectionRowOut < 0) || (simRecPtr->lastInjectionRowOut >= simRecPtr->numRow) ||
		(simRecPtr->firstInjectionRowOut > simRecPtr->lastInjectionRowOut))
	  fprintf (stderr, "%s\n", msg[BAD_INJECTION_AREA_OUT]);

  /* Controlla gli ostacoli specificati */
  for (i = 0; i < numObstacle; i++) {

	/* Controllo dei piani inclusi nell'ostacolo */
	if ((obsList[i].firstCol > obsList[i].lastCol) ||
		(obsList[i].lastCol >= simRecPtr->numCol))
	  fprintf (stderr, "%s %d %s\n", msg[BAD_OBSTACLE_HDR], i, msg[BAD_OBSTACLE_COL]);

	/* Controllo righe dell'ostacolo */
	if ((obsList[i].firstRow > obsList[i].lastRow) ||
		(obsList[i].lastRow >= simRecPtr->numRow))
	  fprintf (stderr, "%s %d %s\n", msg[BAD_OBSTACLE_HDR], i, msg[BAD_OBSTACLE_ROW]);

	/* Controllo profondita' dell'ostacolo */
	if ((obsList[i].firstDepth > obsList[i].lastDepth) ||
		(obsList[i].lastDepth >= simRecPtr->depth))
	  fprintf (stderr, "%s %d %s\n", msg[BAD_OBSTACLE_HDR], i, msg[BAD_OBSTACLE_DEPTH]);
  }
}


void main (int argc, char *argv[])
{
  int inputRes[NUMRES] = {FALSE},					/* risorse specificate dall'utente */
	  numObstacle;									/* numero ostacoli */
  obstacle *obstacleList;							/* ostacoli specificati dall'utente */
  char rc_file[MAX_FILENAME_LEN];					/* nome file di risorse */
  simulInData  simRec;								/* record contenente i parametri della simulazione */

  /* Cosi' error() scrive su stderr */
  error_logfile = stderr;

  /* Semplice parsing dell'input */
  parseCommandLine (argc, argv, rc_file);

  /* Legge il <resource_file> */
  readResourceFile (rc_file, &simRec, inputRes, &numObstacle, &obstacleList);

  /* Controllo delle risorse specificate */
  doCheck (&simRec, inputRes, numObstacle, obstacleList);
}
