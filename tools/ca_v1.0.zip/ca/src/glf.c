/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * glf.c	"Generate Lattice File"
 * 
 * Genera automaticamente il lattice_file a partire dalle informazioni del resource_file.
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>

#include "ca_cdef.h"
#include "glf.h"


FILE *error_logfile;

/*
 * Semplice parsing della linea di comando.
 *
 * Input:
 *		int argc:
 *		char *argv[]: i soliti noti...
 *
 * Comportamento:
 *		in pratica gestice solo la richiesta di help.
 */
void parseCommandLine (int argc, char *argv[])
{
  extern int opterr;
  char opt;

#ifdef DEBUG
  printf (": parseCommandLine()\n");
#endif

  opterr = 0;					/* cosi' getopt() non segnala errori all'utente */


  /* L'unica opzione e' -h per l'help */
  while ((opt = getopt (argc, argv, "h")) != EOF)
	switch (opt) {
	  case 'h':
		printf ("%s\n", msg[MSG_HELP]);
		exit (1);

	  case '?':
		error ("%s\n", msg[MSG_USAGE]);
      default:
        goto no_help;
	}

  /* Se arriva qui allora non e' stato richiesto aiuto */
no_help:
  if (argc < 3)
	error ("%s\n", msg[MSG_USAGE]);
}


/*
 * Legge i valori delle risorse dal resource_file.
 *
 * Input:
 *		simulInData *simRecPtr: puntatore al record dove verranno memorizzati i valori letti;
 *		char *fileName: nome del resource_file;
 *
 * Output:
 *		valore di ritorno:
 *		int:	OK risorse lette correttamente;
 *				ERROR errore nella lettura.
 *		passaggio per indirizzo:
 *		int *numObstacle: il numero di ostacoli letti;
 *		obstacle: **obsList: array degli ostacoli specificati dall'utente;
 *
 * Note:
 *		alloca la memoria per l'array degli ostacoli.
 */
int readResourceFile (simulInData *simRecPtr, char *fileName, obstacle **obsList, int *numObstacle)
{
  FILE *fp;
  int  i = 0, 
	   p[6], 											/* variabile di comodo */
	   resource,										/* indice di risorsa */
	   inputError = FALSE,								/* segnala errore di input */
	   obsCount = 0;									/* conta gli ostacoli letti */
  char *buf,
	   dummy[BUFLEN],
	   inBuf[BUFLEN],									/* buffer di lettura */
	   resName[BUFLEN];									/* nome di una risorsa */
  obstacle *list = NULL;								/* lista degli ostacoli letti */

#ifdef DEBUG
  printf (": readResourceFile()\n");
#endif

  /* Apre il resource_file */
  if ((fp = fopen (fileName, "r")) == NULL)
	error ("%s '%s'\n", msg[MSG_CANT_OPEN_FILE], fileName);

  /**************************************************************************/
  /* Conta tutti gli ostacoli presenti nel <resource_file> per poi allocare */
  /* esattamente un array di ostacoli.									  	*/
  /* Si poteva implementare una soluzione a lista concatenata ma preferisco */
  /* gli array.															  	*/
  /**************************************************************************/
  while (fgets (inBuf, BUFLEN, fp) != NULL) {

	/* Salta commenti e linee vuote */
 	if ((*inBuf == '#') || (*inBuf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
    if (sscanf (inBuf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  inputError = TRUE;
	  break;
   	}

	/* Interessa solo la risorsa ostacolo */
	if (searchStr (resourceSet, NUMRES, resName) == RES_OBSTACLE)
	  obsCount++;
  }

  /* Alloca la memoria per l'array di ostacoli */
  if (!inputError && (obsCount > 0))
	list = (obstacle *) malloc (obsCount * sizeof (obstacle));

  rewind (fp);									/* 'riavvolge' il file */

  /************************************/
  /* Lettura 'vera' del resource_file */
  /************************************/
  while ((fgets (buf = inBuf, BUFLEN, fp) != NULL) && (!inputError)) {

	/* Salta commenti e linee vuote */
 	if ((*buf == '#') || (*buf == '\n'))
	  continue;

	/* Cerca di leggere il nome della risorsa */
    if (sscanf (buf, "%[a-zA-Z0-9] %[:]", resName, dummy) < 2) {
	  inputError = TRUE;
	  break;
   	}

	while (*buf++ != ':');					/* si sposta sul valore della risorsa */

	/* Cerca la risorsa nell'insieme delle risorse e memorizza il relativo valore nel
 	 * record dei parametri.
  	 */
	switch (resource = searchStr (resourceSet, NUMRES, resName)) {
	  case RES_NUMROW:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numRow) == 0);
				   	break;
	  case RES_NUMCOL:
					inputError = (sscanf (buf, " %d ", &simRecPtr->numCol) == 0);
				   	break;
	  case RES_DEPTH:
					inputError = (sscanf (buf, " %d ", &simRecPtr->depth) == 0);
			      	break;
	  case RES_BOUND_COND:
					if ((inputError = (sscanf (buf, " %s ", dummy) == 0)))
					  break;

					/* Cerca di assegnare il valore alla risorsa */
					if ((simRecPtr->boundaryCond = searchStr (boundaryValue, 2, dummy)) == RES_UNKNOWN)
					  inputError = TRUE;
					break;
	  case RES_OBSTACLE:
					if ((inputError = (i >= obsCount)))
					  break;

					inputError = (sscanf (buf, " %d %d %d %d %d %d ", &p[0], &p[1],
									&p[2], &p[3], &p[4], &p[5]) != 6);

					if (!inputError) {
						list[i].firstRow   = p[0];
						list[i].firstDepth = p[1];
						list[i].lastRow    = p[2];
						list[i].lastDepth  = p[3];
						list[i].firstCol   = p[4];
						list[i].lastCol    = p[5];
						i++;				/* incrementa contatore degli ostacoli letti */
					}
					break;
	  case RES_UNKNOWN:
					inputError = TRUE; break;
	  default:
					inputError = FALSE;
	}
  }

  /* Se uscendo dal ciclo non e' EOF allora si e' verificato un errore */
  if (!feof (fp) || inputError || (i != obsCount)) {
	fclose (fp);
	return ERROR;
  }
  else {
	/* Ritorna i valori al chiamante */
	*numObstacle = obsCount;
	*obsList = list;

	fclose (fp);
	return OK;
  }
}


/*
 * Inizializza il reticolo e calcolo dei contorni.
 *
 * Input:
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		u_int **lattice: il reticolo da elaborare.
 *
 * Output:
 *		nessuno.
 */
void initAndDoBoundary (simulInData *simRecPtr, u_int **lattice)
{
  int planeDim, 								/* numero di blocchi per piano */
	  numBlock,									/* numero di blocchi in un riga del piano */
	  lastBlock,								/* indice dell'ultimo blocco di un piano */
	  lastCentralBlock;							/* indice dell'ultimo blocco delle righe centrali */
  u_int	*latticePlane;							/* un piano del reticolo */
  register int i;

#ifdef DEBUG
  printf (": initAndBoundary()\n");
#endif

  /* Inizializzazione di alcuni indici */
  numBlock = simRecPtr->depth / UINTLEN;
  planeDim = simRecPtr->numRow * numBlock;
  lastBlock = planeDim - 1;
  lastCentralBlock = lastBlock - numBlock;

  /* Alloca memoria per un piano del reticolo */
  latticePlane = (u_int *) malloc (planeDim * sizeof (u_int)); 

  /* Prepara il piano da scrivere su <lattice_file> 
   * 	0 = nodo ostacolo 
   * 	1 = nodo fluido 
   */
  memset (latticePlane, ~0, sizeof (u_int) * planeDim);			/* tutti nodi fluido */

  /* Se le condizioni al contorno sono wind-tunnel allora 'costruisce' il condotto marcando
   * opportunamente i nodi di un piano del reticolo.
   */
  if (simRecPtr->boundaryCond == TUNNEL) {
	i = 0;
	while (i < numBlock) 							/* la prima riga e' tutta di nodi ostacolo */
	  latticePlane[i++] = 0;

	/* Preparazione righe centrali */
	if (numBlock == 1)

	  /* caso di un blocco per riga */
	  while (i <= lastCentralBlock) {
		/* primo e ultimo nodo ostacoli */
		latticePlane[i] = setBit(latticePlane[i], 0, OBSTACLE);
		latticePlane[i] = setBit(latticePlane[i], (UINTLEN-1), OBSTACLE);
		i++;
	  }
	else 
	  /* piu' blocchi per riga */
	  while (i <= lastCentralBlock) {
		latticePlane[i] = setBit(latticePlane[i], 0, OBSTACLE);		/* il primo nodo e' ostacolo */
		i += numBlock - 1;							/* si posiziona sull' ultimo blocco della riga */
		latticePlane[i] = setBit(latticePlane[i], (UINTLEN-1), OBSTACLE);	/* ultimo nodo e' ostacolo */
		i++;
	  }

	while (i <= lastBlock)						/* ultima riga tutti ostacoli */
	  latticePlane[i++] = 0;
  }

  /* Costruzione del reticolo totale accostando piu' volte il piano appena calcolato */
  for (i = 0; i < simRecPtr->numCol; i++)
	memmove (lattice[i], latticePlane, sizeof (u_int) * planeDim);
}


/*
 * Inserimento nel reticolo degli ostacoli definiti dall'utente.
 *
 * Input:
 *		simulInData *simRecPtr: record dei parametri di simulazione;
 *		u_int **lattice: il reticolo da elaborare;
 *		int obstacleList: lista degli ostacoli da inserire;
 *		int numObstacle: numero degli ostacoli da inserire.
 *
 * Output:
 *		nessuno.
 */
void insertObstacle (simulInData *simRecPtr, u_int **lattice, obstacle *obsList,
					 int numObstacle)
{
  int planeDim, 								/* numero di nodi in piano */
	  numBlock,									/* numero di blocchi in un riga del piano */
	  planeDimInt,								/* numero di blocchi per piano */
	  planeDimByte;								/* lunghezza in byte di un piano */

  int obsDepth,						/* profondita' di un ostacolo */
	  first, last;					/* indici di posizione */

  register int i, j, k, z;
  register u_int *currPlane;		/* piano corrente nell'inserimento degli ostacoli */

#ifdef DEBUG
  printf (": insertObstacle()\n");
#endif

  /* Calcolo di alcuni parametri */
  numBlock = simRecPtr->depth / UINTLEN;
  planeDim = simRecPtr->numRow * simRecPtr->depth;
  planeDimInt = simRecPtr->numRow * numBlock;
  planeDimByte = planeDimInt * sizeof (u_int);

  /* Elaborazione degli ostacoli */
  for (i = 0; i < numObstacle; i++) {

	/* Calcolo profondita' ostacolo corrente */
	obsDepth = obsList[i].lastDepth - obsList[i].firstDepth + 1;

	/* I seguenti indici sono rispetto ad un piano */
	first = obsList[i].firstDepth +
			obsList[i].firstRow * simRecPtr->depth;		/* posizione del primo nodo ostacolo */
	last  = obsList[i].lastDepth +
			obsList[i].lastRow * simRecPtr->depth;		/* posizione dell'ultimo nodo ostacolo */

	/* Elaborazione di tutti i piani compresi nell'ostacolo */
	for (j = obsList[i].firstCol; j <= obsList[i].lastCol; j++) {

	  currPlane = lattice[j];

	  /* Elaborazione di tutte le righe del piano comprese nell'ostacolo */
	  k = first;
	  while (k <= last) {

		/* Inserimento singoli nodi ostacolo nella riga */
		for (z = k; z < k + obsDepth; z++) {
		  register int wordPos,					/* parola alla quale appartiene il nodo ostacolo */
					   bitPos;					/* posizione all'interno della parola */
		  div_t	result;

		  /* Calcola la posizione della particella ostacolo nel reticolo */ 
		  result = div (z, UINTLEN);
		  wordPos = result.quot;
		  bitPos = result.rem;

		  /* Segna l'ostacolo nella parola */
		  currPlane[wordPos] = setBit(currPlane[wordPos], bitPos, OBSTACLE);
		}

		k += simRecPtr->depth;			/* primo nodo ostacolo della riga successiva */
	  }
 	}
  }
}


void main (int argc, char *argv[])
{
  FILE *fp;
  obstacle *obstacleList;				/* la lista degli ostacoli specificati dall'utente */
  int planeDimInt,						/* dimensione di un piano del reticolo (in interi) */
	  numObstacle = 0;					/* conta gli ostacoli letti dal <resource_file> */
  register int i;
  u_int **lattice;						/* il reticolo da calcolare */
  simulInData simRec;

  /* Cosi' error() (funzione esterna) scrive su stderr */
  error_logfile = stderr;

  /* Controllo della linea di comando */
  parseCommandLine(argc, argv);

  /* Lettura del file delle risorse */
  if (readResourceFile (&simRec, argv[1], &obstacleList, &numObstacle) == ERROR)
	error ("%s\n", msg[MSG_BAD_RESOURCE_FILE]);

  /* Controllo congruenza per la profondita' del reticolo */
  if ((simRec.depth % UINTLEN) != 0)
	error ("%s\n", msg[MSG_BAD_DEPTH]);

  /* Apertura del <lattice_file> */
  if ((fp = fopen (argv[2], "w")) == NULL)
	error ("%s '%s'\n", msg[MSG_CANT_OPEN_FILE], argv[2]);

  planeDimInt = (simRec.depth / UINTLEN) * simRec.numRow;

  /* Alloca la memoria per i puntatori ai piani */
  lattice = (u_int **) malloc (sizeof (u_int *) * simRec.numCol);

  /* Alloca i piani del reticolo */
  for (i = 0; i < simRec.numCol; i++)
	lattice[i] = (u_int *) malloc (planeDimInt * sizeof (u_int));

  /* Inizializzazione del reticolo e calcolo dei contorni */
  initAndDoBoundary (&simRec, lattice);

  /* Inserimento di eventuali ostacoli definiti dall'utente nel <resource_file> */
  if (numObstacle > 0)
	insertObstacle (&simRec, lattice, obstacleList, numObstacle);

  /* Scrittura del reticolo su <lattice_file> */
  for (i = 0; i < simRec.numCol; i++)
	if (fwrite (lattice[i], sizeof (u_int), planeDimInt, fp) < planeDimInt)
	  error ("%s\n", msg[MSG_WRITE_ERROR]);

  fclose (fp);
}
