/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * merge.h
 *
 * Header file per merge.c
 */

/* Cerca una stringa in un dato insieme di stringhe */
extern int searchStr (char **strSet, int strSetDim, char *keyStr);

/* Stampa messaggi su file e poi termina il programma */
extern void error (char *fmt, ...);

typedef struct {
	int numFile;						/* quanti file in input */
	int32 *infile;						/* array dei descrittori di file */
#ifndef USE_DFSD_INTERFACE
	int32  outfile;						/* descrittore del file di output */
#endif
	char **fileName;					/* i nomi dei file di input */
	char outFileName[MAX_FILENAME_LEN];	/* nome del file 'fuso' */

	u_int setOptions;					/* opzioni selezionate dall'utente */
} mergeData;


#define OPT_OUTFILE 0x01


/* Un array di messaggi per l'utente */
char *msg[] = {"Fonde piu' file di output in un unico file.\nUso: merge [-h -o <merge_outfile>] <resource_file> <num_file>\nUsa -h per avere un ulteriore aiuto.",
		"Fonde piu' file di output in un unico file.\nUso: merge [-h -o <merge_outfile>] <resource_file> <num_file>\n\
Commenti:\n\
  <resource_file>   : il file di risorse della simulazione;\n\
  <num_file>        : specifica il numero dei file in input;\n\
  -o <merge_outfile>: il nome del file di output;\n\n\
  merge genera un unico file di output concatenando i file di output di ogni processore.\n\
  Come nome usa l'argomento del comando -o se specificato, altrimenti considera il\n\
  valore della risorsa outFile.\n\n\
  merge riconosce (dal <resource_file>) le seguenti risorse *obbligatorie*:\n\
     - numRow, numCol, depth: dimensioni del reticolo elaborato;\n\
     - transient: transitorio della simulazione;\n\
     - samplingStep: passo di campionamento;\n\
     - samplePerFrame: numero di campioni per frame;\n\
     - outFile: nome del file di output;",
			"merge: errore leggendo opzione",
			"merge: <resource_file> errato, usare crcf",
			"merge: non posso aprire",
			"merge: -n e' obbligatorio",
			"merge: malloc() fallita",
			"merge: SDstart() fallita",
			"merge: file non in formato HDF",
			"merge: SDselect() fallita",
			"merge: numero di frame errato su file",
			"merge: dimensione frame errata",
			"merge: SDread() fallita",
			"merge: SDendaccess() fallita",
			"merge: numero di dataset errato su file",
			"merge: SDwritedata() fallita",
			"merge: SDcreate() fallita",
			"merge: SDgetinfo() fallita",
			"merge: SDend() fallita",
			"merge: SDsetcomp() fallita",
			"merge: SDfileinfo() fallita"};
                 
#define MSG_USAGE				0
#define MSG_HELP				1
#define MSG_BAD_OPTION			2
#define MSG_BAD_RESOURCE_FILE	3
#define MSG_CANT_OPEN_FILE		4
#define MSG_COMPULSORY_OPT		5
#define MSG_MALLOC_FAILED		6
#define MSG_SDSTART_FAILED		7
#define MSG_BAD_OUTPUT_FILE		8
#define MSG_SDSELECT_FAILED		9
#define MSG_BAD_FRAME_NUM		10
#define MSG_BAD_FRAME_DIM		11
#define MSG_SDREAD_FAILED		12
#define MSG_SDENDACC_FAILED		13
#define MSG_BAD_DATASET_NUM		14
#define MSG_SDWRITE_FAILED		15
#define MSG_SDCREATE_FAILED		16
#define MSG_SDGETINFO_FAILED	17
#define MSG_SDEND_FAILED		18
#define MSG_SDSETCOMP_FAILED	19
#define MSG_SDFILEINFO_FAILED	20
