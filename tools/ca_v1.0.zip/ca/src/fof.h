/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * fof.h	Filter Output File
 *
 * Header file per fof.c
 */

/* Cerca una stringa in un dato insieme */
extern int searchStr (char **strSet, int strSetDim, char *keyStr);

/* Ritorna la lunghezza di un file */
extern long fsize (char *fileName);

/* Stampa messaggi su stderr e poi termina il programma */
extern void error (char *format, ...);

/* Indici dei buffer di lettura */
#define D_BUF 0
#define X_BUF 1
#define Y_BUF 2
#define Z_BUF 3

/* Informazioni relative alle macrocelle */
typedef struct _macroDataRec {

	int numMacroCol,		/* dimensioni del reticolo.. */
		numMacroRow,		/* ..misurate in.. */
		macroDepth,			/* ..macrocelle */

		macroCellDim,		/* numero di nodi in una macrocella */
		macroPlaneDim,		/* dimensione di un macropiano (in macrocelle) */
		macroPlaneDimNode;  /* dimensione di un macropiano (in nodi) */

	} macroDataRec;


/* Le opzioni dell'utente */
typedef struct _optionRec {

	int doubleFrame;						/* raddoppio dei frame? */
    char rc_file[MAX_FILENAME_LEN];			/* nome del <resource_file> */
	char fofOutFileName[MAX_FILENAME_LEN];	/* nome file di output */

#ifndef USE_DFSD_INTERFACE
	int32 fofOutFile;						/* ID del file di output */
#endif
	
} optionRec;


/* Un array di messaggi per l'utente */
char *msg[] = {"Filtro per l'<output_file> di ca.\nUso: fof [-h -d] <resource_file> <fof_output_file>\nUsa -h per avere un ulteriore aiuto.",
			   "fof: SDstart() fallita",
			   "fof: SDselect() fallita",
			   "fof: <resource_file> non corretto, usare crcf",
			   "fof: <output_file> non in formato HDF",
			   "fof: SDreaddata() fallita",
			   "fof: malloc() fallita",
			   "fof: SDendaccess() fallita",
			   "fof: SDcreate() fallita",
			   "fof: SDwritedata() fallita",
			   "fof: in <output_file> lunghezza frame errata",
			   "fof: in <output_file> numero frame errato",
			   "fof: SDsetcompress() fallita",
			   "fof: non posso aprire",
			   "Filtro per l'<output_file> di ca.\nUso: fof [-h -d] <resource_file> <fof_output_file>\n\
Commenti:\n\
  -d : 'duplicazione' dei frame (media tra due frame contigui);\n\n\
  <resource_file>  : il file di risorse della simulazione;\n\
  <fof_output_file>: specifica il nome del file che fof generera';\n\n\
  fof legge l'<output_file> di ca ed estrae le quantita' mediate sulle macrocelle.\n\n\
  fof riconosce (dal <resource_file>) le seguenti risorse come *obbligatorie*:\n\
     - numRow, numCol, depth: dimensioni del reticolo elaborato da ca;\n\
     - macroCellRow, macroCellCol, macroCellDepth: dimensioni della macrocelle da elaborare;\n\
     - numIter: numero di iterazioni della simulazione;\n\
     - samplingStep: passo di campionamento;\n\
     - samplePerFrame: numero di campioni per frame;\n\
     - transient: durata del transitorio (in iterazioni);\n\
     - dataCompression: specifica se si vuole l'output compresso;\n\
     - outFile: nome del file di output generato da ca;\n"
};

/* Indici per l'array di messaggi */
#define USAGE      			0
#define SDSTART_FAILED  	1
#define SDSELECT_FAILED		2
#define BAD_RESOURCE_FILE	3
#define BAD_OUTPUT_FILE		4
#define SDREAD_FAILED		5
#define MALLOC_FAILED		6
#define SDENDACC_FAILED		7
#define SDCREATE_FAILED		8
#define SDWRITE_FAILED		9
#define BAD_FRAME_DIM		10
#define BAD_FRAME_NUM		11
#define SDSETCOMP_FAILED	12
#define CANT_OPEN_FILE		13
#define HELP      			14
