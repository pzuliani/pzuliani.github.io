/***********************************************************************************************
Copyright (C) 1996, 1997, 2012 Paolo Zuliani.  All rights reserved.
By using this software the USER indicates that he or she has read, understood 
and will comply with the following:

1. The USER is hereby granted non-exclusive permission to use, copy and/or
modify this software for internal, non-commercial, research purposes only. Any
distribution, including commercial sale or license, of this software, copies of
the software, its associated documentation and/or modifications of either is
strictly prohibited without the prior consent of the authors. Title to copyright
to this software and its associated documentation shall at all times remain with
the authors. Appropriated copyright notice shall be placed on all software
copies, and a complete copy of this notice shall be included in all copies of
the associated documentation. No right is granted to use in advertising,
publicity or otherwise any trademark, service mark, or the name of the authors.

2. This software and any associated documentation is provided "as is".

THE AUTHORS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESSED OR IMPLIED,
INCLUDING THOSE OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT
USE OF THE SOFTWARE, MODIFICATIONS, OR ASSOCIATED DOCUMENTATION WILL NOT
INFRINGE ANY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER INTELLECTUAL PROPERTY
RIGHTS OF A THIRD PARTY.

The authors shall not be liable under any circumstances for any direct,
indirect, special, incidental, or consequential damages with respect to any
claim by USER or any third party on account of or arising from the use, or
inability to use, this software or its associated documentation, even if the
authors have been advised of the possibility of those damages.
***********************************************************************************************/


/*
 * gc.c		"Generate Collisions"
 *
 * Generazione dell'insieme delle collisioni per l'automa cellulare rombododecaedrico.
 *
 */

#include <stdio.h>

#define  MAX    200
#define  MAX_LEN    256
#define  NUMVECT 12						/* 12 velocity vectors */
#define  NUMCLASS_MASS  9				/* ci sono collisioni solo da 2 a 10 particelle:
										 * quindi 9 classi di collisioni che rispettano solo
										 * la conservazione della massa
 										 */

typedef  int  eVect[3];					/* coordinate euclidee */

typedef  struct _collRec {				/* una collisione */
		char *coll;							/* stato iniziale e finale */
		struct _collRec *next;				/* prossima collisione della classe */
		} collRec;

typedef  struct _collClass {			/* una classe di collisioni */
		eVect   qmoto;						/* quantita' di moto */
	  	int 	dim;						/* dimensione della classe */
		collRec *collList;					/* lista delle collisioni */
		} collClass;

typedef struct _optRec {
		int setOptions;
		char collSetFileName[MAX_LEN];
		char classFileName[MAX_LEN];
} userOption;


int opt_part[NUMCLASS_MASS] = {1, 2, 4, 8, 16, 32, 64, 128, 256};


/* il velocity set */
eVect 	e[NUMVECT] ={ {0,2,0}, {-2,0,0}, {0,-2,0}, {2,0,0}, {-1,1,1},
		 {1,1,-1}, {-1,1,-1}, {1,1,1}, {1,-1,-1}, {-1,-1,1}, {1,-1,1},
		 {-1,-1,-1} },
	qmoto_i, qmoto_f;				/* quantita' di moto iniziale e finale di due 
									 * configurazioni candidate a collisione 
									 */

FILE   *fp1, *fp2;

int   minDim = 0;			/* dimensione minima di una classe per essere scritta su file */ 

char *msg_help = "\n\
Uso:   gc [-h -{2|3|4|5|6|7|8|9|10} -e n]  <collision_file> <class_file>\n\n\
    -h          mostra questa schermata;\n\n\
    -{2|...|10} specifica le particelle da considerare nel calcolo delle collisioni.\n\n\
                Questo comando puo' essere ripetuto. Per default gc calcola tutte le\n\n\
                collisioni possibili (da 2 a 10 particelle);\n\n\
    -e n        esclude le collisioni appartenenti a classi con cardinalita' \n\n\
                minore o uguale a n;\n\n\
    <collision_file>  file su cui scrivere l'insieme delle collisioni calcolato;\n\n\
    <class_file>      file su cui scrivere la classi di collisioni calcolate;\n";

char *msg_usage = "\n\
Uso:   gc [-h -{2|3|4|5|6|7|8|9|10} -e n]  <collision_file> <class_file>\n\n\
Usa -h per ottenere un aiuto.\n";


/*
 * Legge la linea di comando e salva le opzioni nel record apposito. 
 *
 * Input:
 *		int argc, char *argv[]: i soliti...;
 *		userOption *optPtr: record delle opzioni utente;
 *
 * Comportamento:
 *		se c'e' qualche errore in input scrive un messaggio di errore e poi termina il programma.
 *		Gestisce anche la richiesta di help da parte dell'utente.
 */
void parseCommandLine (int argc, char *argv[], userOption *optPtr)
{


  extern int opterr;  				/* variabili usate da getopt() */
  extern char *optarg;
  extern int optind;

  char opt;
  int i;


  opterr = 0;						/* cosi' getopt() non segnala gli errori all'esterno */

  /* Lettura della linea di comando opzione per opzione */
  while ((opt = getopt (argc, argv, "h234567891:e:")) != EOF)

	switch (opt) {
	  /* Help */
	  case 'h':
		printf ("%s\n", msg_help); 
		exit (1);

	  case 'e':
		if (sscanf (optarg, "%d", &minDim) != 1) {
			printf ("%s\n", msg_usage); 
			exit (1);
		}
		else break;

	  case '2':
		optPtr->setOptions |= opt_part[0]; break;

	  case '3':

		optPtr->setOptions |= opt_part[1]; break;

	  case '4':

		optPtr->setOptions |= opt_part[2]; break;

	  case '5':

		optPtr->setOptions |= opt_part[3]; break;

	  case '6':

		optPtr->setOptions |= opt_part[4]; break;

	  case '7':

		optPtr->setOptions |= opt_part[5]; break;

	  case '8':

		optPtr->setOptions |= opt_part[6]; break;

	  case '9':

		optPtr->setOptions |= opt_part[7]; break;

	  case '1':

		if (*optarg != '0') {
			printf ("%s\n", msg_usage);
			exit (1);
		}
		optPtr->setOptions |= opt_part[8]; break;

	  case '?':
		printf ("%s\n", msg_usage);
		exit (1);

	  default:
		goto end_parsing;
	}

end_parsing:
  /* Se non e' stata letta almeno una opzione allora per default calcola tutte le collisioni */
  if (optPtr->setOptions == 0)
	for (i = 0; i < NUMCLASS_MASS; i++)
		optPtr->setOptions |= opt_part[i];

  /* legge i nomi dei files, se ci sono*/

  if ((argc - optind) != 2) {
	printf ("%s\n", msg_usage);
	exit (1);
  }

  strncpy (optPtr->collSetFileName, argv[optind++], MAX_LEN);
  strncpy (optPtr->classFileName, argv[optind], MAX_LEN);
}


/* 
 * Inizializza l'array contenente le classi di equivalenza
 */
void  Initialize (collClass collSet[][MAX])
{
  int i, j;

  for (j = 0; j < NUMCLASS_MASS; j++)
	for (i = 0; i < MAX; i++) {
	  collSet[j][i].dim = 0;
	  collSet[j][i].qmoto[0] = collSet[j][i].qmoto[1] = collSet[j][i].qmoto[2] = MAX;  
	  collSet[j][i].collList = NULL;
	}
}


/*
 * Scrive collision_file e class_file. 
 * 
 * Input: l'array di classi di collisioni, numero di collisioni totali per numero 
 *		  di particelle
 */
void  writeCollClass (collClass collSet[][MAX], int numColl[])
{
  register int i, j, k, dim;
  int classCount;
  collRec *p;

  /* piccola intestazione */
  fprintf (fp1, "# Generato da gc.\n#\n# collision_file per automa cellulare rombododecaedrico\n#\n");

  fprintf (fp2, "# Generato da gc.\n#\n# class_file per automa cellulare rombododecaedrico\n#\n");

  if (minDim > 0) {
	fprintf (fp1, "# Sono elencate le classi con cardinalita' superiore a %d\n#\n", minDim);
	fprintf (fp2, "# Sono elencate le classi con cardinalita' superiore a %d\n#\n", minDim);
  }
  fprintf (fp1, "# Numero di collisioni da 2 a 10 particelle\n");

  /* scrive il numero di collisioni per numero di particelle su collision_file */
  for (i = 0; i < NUMCLASS_MASS; i++) 
	fprintf (fp1, "%d\n", numColl[i]);

  /* scrive una classe per massa alla volta iniziando da quella a 2 particelle */ 
  for (i = 0; i < NUMCLASS_MASS; i++) {		
	j = 0;
    fprintf (fp1, "#\n# Collisioni a %d particelle\n", i+2);
    fprintf (fp2, "Collisioni a %d particelle\n", i+2);
    classCount = 0;

	/* scrittura delle collisioni: la dimensione nulla segna la fine delle classi */
	while ((dim = collSet[i][j].dim) > 0) {		
	  p = collSet[i][j].collList;

	  /* si considerano solo le classi che superano la soglia minima */
	  if (dim > minDim) {
		fprintf (fp1, "$ Classe %d\n", classCount);
		fprintf (fp2, "Classe %d dimensione: %d\n", classCount++, dim);

		/* effettiva scrittura delle collisioni */
		for (k = 0; k < dim; k++) {
		  fprintf (fp1, "%s\n", p->coll);
		  p = p->next;
		}
	  }
	  j++;
	}
	fprintf (fp2, "Totale classi: %d\n\n", classCount); 
  }
}


/*
 * Generazione delle collisioni a 2 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  TwoPartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 12, 					/* 12 byte per memorizzare una collisione */
		scan, found,
		numClass = 0, 
		i, j, k, y;
  collRec *p;
 

  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++) {

	qmoto_i[0] = e[i][0]+e[j][0];
	qmoto_i[1] = e[i][1]+e[j][1];
	qmoto_i[2] = e[i][2]+e[j][2];

	for (k = 0; k < NUMVECT; k++)
	for (y = k+1; y < NUMVECT; y++) {

		qmoto_f[0] = e[k][0]+e[y][0];
		qmoto_f[1] = e[k][1]+e[y][1];
		qmoto_f[2] = e[k][2]+e[y][2];

		if ((qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
			  (qmoto_i[2] == qmoto_f[2]) ) 
			if ( !((k == i) && (j == y)) ) {
				scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2]));
					else scan++;
				while (!found && scan < numClass); 

				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}

				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d - %d %d", i, j, k, y);
			}
	}
  }

  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 
}


/*
 * Generazione delle collisioni a 3 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  ThreePartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 18, 					/* 12 byte per memorizzare una collisione */
        scan, 
		numClass = 0,
		found,
	i, j, k, y, z, w;
  collRec *p;

  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++) {

	qmoto_i[0] = e[i][0]+e[j][0]+e[z][0];
  	qmoto_i[1] = e[i][1]+e[j][1]+e[z][1];
  	qmoto_i[2] = e[i][2]+e[j][2]+e[z][2];

  	for (k = 0; k < NUMVECT; k++)
  	for (y = k+1; y < NUMVECT; y++)
  	for (w = y+1; w < NUMVECT; w++) {

		qmoto_f[0] = e[k][0]+e[y][0]+e[w][0];
 		qmoto_f[1] = e[k][1]+e[y][1]+e[w][1];
 		qmoto_f[2] = e[k][2]+e[y][2]+e[w][2];

		if ( (qmoto_i[0] == qmoto_f[0]) &&
			(qmoto_i[1] == qmoto_f[1]) && (qmoto_i[2] == qmoto_f[2]) ) 
 			if  ( !((k == i) && (j == y) && (z == w)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2]));
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d - %d %d %d", i, j, z, k, y, w);
 			}
  	}
  }
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 
}


/*
 * Generazione delle collisioni a 4 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  FourPartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 24, 					/* 12 byte per memorizzare una collisione */
		scan,
		numClass = 0,
		found,
	i, j, k, y, z, w, t, x;
  collRec *p;

  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++) {

	qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0];
	qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1];
	qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2];

	for (k = 0; k < NUMVECT; k++)
	for (y = k+1; y < NUMVECT; y++)
	for (w = y+1; w < NUMVECT; w++)
	for (t = w+1; t < NUMVECT; t++) {

		qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0];
		qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1];
		qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2];

		if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		  (qmoto_i[2] == qmoto_f[2]) ) 
			if ( !((k == i) && (j == y) && (z == w) && (t == x)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2])); 
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d - %d %d %d %d", i, j, z, x, k, y, w, t);
			}
		}
  }
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 

}


/*
 * Generazione delle collisioni a 5 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  FivePartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 30, 					/* 12 byte per memorizzare una collisione */
		scan,
		numClass = 0,
		found,
	i, j, k, y, z, w, t, x, s, r;
  collRec *p;



  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++)
  for (s = x+1; s < NUMVECT; s++) {

	  qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0]+e[s][0];
	  qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1]+e[s][1];
	  qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2]+e[s][2];

	  for (k = 0; k < NUMVECT; k++)
	  for (y = k+1; y < NUMVECT; y++)
	  for (w = y+1; w < NUMVECT; w++)
	  for (t = w+1; t < NUMVECT; t++)
	  for (r = t+1; r < NUMVECT; r++) {

		  qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0]+e[r][0];
		  qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1]+e[r][1];
		  qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2]+e[r][2];

		  if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		    (qmoto_i[2] == qmoto_f[2]) ) 
		  	if  ( !((k == i) && (j == y) && (z == w) && (t == x) && (s == r)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2])); 
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d %d - %d %d %d %d %d", i, j, z, x, s, k, y, w, t, r);
		  	}
	  }
  };
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 

}


/*
 * Generazione delle collisioni a 6 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  SixPartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 36, 					/* 12 byte per memorizzare una collisione */
		scan,
		numClass = 0,
		found,
        i, j, k, y, z, w, t, x, s, r, u, v;
  collRec *p;


  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++)
  for (s = x+1; s < NUMVECT; s++)
  for (u = s+1; u < NUMVECT; u++) {

	  qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0]+e[s][0]+e[u][0];
	  qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1]+e[s][1]+e[u][1];
	  qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2]+e[s][2]+e[u][2];

	  for (k = 0; k < NUMVECT; k++)
	  for (y = k+1; y < NUMVECT; y++)
	  for (w = y+1; w < NUMVECT; w++)
	  for (t = w+1; t < NUMVECT; t++)
	  for (r = t+1; r < NUMVECT; r++)
	  for (v = r+1; v < NUMVECT; v++) {

		  qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0]+e[r][0]+e[v][0];
		  qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1]+e[r][1]+e[v][1];
		  qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2]+e[r][2]+e[v][2];

		  if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		    (qmoto_i[2] == qmoto_f[2]) ) 
		  	if  ( !((k == i) && (j == y) && (z == w) && (t == x) && (s == r) &&
			    (u == v)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2]));
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d %d %d - %d %d %d %d %d %d",
			i, j, z, x, s, u, k, y, w, t, r, v);
		  }
	  }
  };
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 

}


/*
 * Generazione delle collisioni a 7 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  SevenPartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 42, 					/* 12 byte per memorizzare una collisione */
		scan,
		numClass = 0,
		found,
	  i, j, k, y, z, w, t, x, s, r, u, v, n, m;
  collRec *p;


  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++)
  for (s = x+1; s < NUMVECT; s++)
  for (u = s+1; u < NUMVECT; u++)
  for (n = u+1; n < NUMVECT; n++) {

	  qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0]+e[s][0]+e[u][0]+e[n][0];
	  qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1]+e[s][1]+e[u][1]+e[n][1];
	  qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2]+e[s][2]+e[u][2]+e[n][2];

	  for (k = 0; k < NUMVECT; k++)
	  for (y = k+1; y < NUMVECT; y++)
	  for (w = y+1; w < NUMVECT; w++)
	  for (t = w+1; t < NUMVECT; t++)
	  for (r = t+1; r < NUMVECT; r++)
	  for (v = r+1; v < NUMVECT; v++)
	  for (m = v+1; m < NUMVECT; m++) {

		  qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0]+e[r][0]+e[v][0]+e[m][0];
		  qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1]+e[r][1]+e[v][1]+e[m][1];
		  qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2]+e[r][2]+e[v][2]+e[m][2];

		  if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		      (qmoto_i[2] == qmoto_f[2]) ) 
		  	if  ( !((k == i) && (j == y) && (z == w) && (t == x) && (s == r) &&
			    (u == v) && (n == m)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2])); 
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d %d %d %d - %d %d %d %d %d %d %d",
				  i, j, z, x, s, u, n, k, y, w, t, r, v, m);
		  	}
	  }
  }
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 

}


/*
 * Generazione delle collisioni a 8 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  EightPartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 48, 					/* 12 byte per memorizzare una collisione */
		scan,
		numClass = 0,
		found,
	i, j, k, y, z, w, t, x, s, r, u, v, n, m, a, b;
  collRec *p;


  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++)
  for (s = x+1; s < NUMVECT; s++)
  for (u = s+1; u < NUMVECT; u++)
  for (n = u+1; n < NUMVECT; n++)
  for (a = n+1; a < NUMVECT; a++) {

	  qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0]+e[s][0]+e[u][0]+e[n][0]+e[a][0];
	  qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1]+e[s][1]+e[u][1]+e[n][1]+e[a][1];
	  qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2]+e[s][2]+e[u][2]+e[n][2]+e[a][2];

	  for (k = 0; k < NUMVECT; k++)
	  for (y = k+1; y < NUMVECT; y++)
	  for (w = y+1; w < NUMVECT; w++)
	  for (t = w+1; t < NUMVECT; t++)
	  for (r = t+1; r < NUMVECT; r++)
	  for (v = r+1; v < NUMVECT; v++)
	  for (m = v+1; m < NUMVECT; m++)
	  for (b = m+1; b < NUMVECT; b++) {

		  qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0]+e[r][0]+e[v][0]+
					   e[m][0]+e[b][0];
		  qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1]+e[r][1]+e[v][1]+
					   e[m][1]+e[b][1];
		  qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2]+e[r][2]+e[v][2]+
					   e[m][2]+e[b][2];

		  if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		    (qmoto_i[2] == qmoto_f[2]) ) 
		  	if  ( !((k == i) && (j == y) && (z == w) && (t == x) && (s == r) &&
			    (u == v) && (n == m) && (b == a)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2])); 
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d %d %d %d %d - %d %d %d %d %d %d %d %d", i, j, z, x, s, u, n, a, k, y, w, t, r, v, m, b);
		  	}
	  }
  }
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 
}


/*
 * Generazione delle collisioni a 9 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  NinePartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 54, 					/* 12 byte per memorizzare una collisione */
		scan, 
		numClass = 0,
		found,
        i, j, k, y, z, w, t, x, s, r, u, v, n, m, a, b, c, d;
  collRec *p;

  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++)
  for (s = x+1; s < NUMVECT; s++)
  for (u = s+1; u < NUMVECT; u++)
  for (n = u+1; n < NUMVECT; n++)
  for (a = n+1; a < NUMVECT; a++)
  for (c = a+1; c < NUMVECT; c++) {

	  qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0]+e[s][0]+e[u][0]+e[n][0]+ e[a][0]+e[c][0];
	  qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1]+e[s][1]+e[u][1]+e[n][1]+ e[a][1]+e[c][1];
	  qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2]+e[s][2]+e[u][2]+e[n][2]+ e[a][2]+e[c][2];

	  for (k = 0; k < NUMVECT; k++)
	  for (y = k+1; y < NUMVECT; y++)
	  for (w = y+1; w < NUMVECT; w++)
	  for (t = w+1; t < NUMVECT; t++)
	  for (r = t+1; r < NUMVECT; r++)
	  for (v = r+1; v < NUMVECT; v++)
	  for (m = v+1; m < NUMVECT; m++)
	  for (b = m+1; b < NUMVECT; b++)
	  for (d = b+1; d < NUMVECT; d++) {

		  qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0]+e[r][0]+e[v][0]+ e[m][0]+e[b][0]+e[d][0];
		  qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1]+e[r][1]+e[v][1]+ e[m][1]+e[b][1]+e[d][1];
		  qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2]+e[r][2]+e[v][2]+ e[m][2]+e[b][2]+e[d][2];

		  if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		    (qmoto_i[2] == qmoto_f[2]) ) 
		  	if ( !((k == i) && (j == y) && (z == w) && (t == x) && (s == r) &&
			    (u == v) && (n == m) && (b == a) && (c == d)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2])); 
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d %d %d %d %d %d - %d %d %d %d %d %d %d %d %d", i, j, z, x, s, u, n, a, c, k, y, w, t, r, v, m, b, d);
		  	}
	  }
  };
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 

}


/*
 * Generazione delle collisioni a 10 particelle.
 *
 * Input: collSet e' l'array dove memorizzare le collisioni generate.
 * Output: numColl e' il numero totale di collisioni generato.
 * 
 */
void  TenPartColl (collClass collSet[], int *numColl)
{
  int 	dim,
		count,
		bufLen = 60, 					/* 12 byte per memorizzare una collisione */
		scan, 
		numClass = 0,
		found,
	  i, j, k, y, z, w, t, x, s, r, u, v, n, m, a, b, c, d, f, g;
  collRec *p;

  for (i = 0; i < NUMVECT; i++)
  for (j = i+1; j < NUMVECT; j++)
  for (z = j+1; z < NUMVECT; z++)
  for (x = z+1; x < NUMVECT; x++)
  for (s = x+1; s < NUMVECT; s++)
  for (u = s+1; u < NUMVECT; u++)
  for (n = u+1; n < NUMVECT; n++)
  for (a = n+1; a < NUMVECT; a++)
  for (c = a+1; c < NUMVECT; c++)
  for (g = c+1; g < NUMVECT; g++) {

	  qmoto_i[0] = e[i][0]+e[j][0]+e[z][0]+e[x][0]+e[s][0]+e[u][0]+e[n][0]+
				   e[a][0]+e[c][0]+e[g][0];
	  qmoto_i[1] = e[i][1]+e[j][1]+e[z][1]+e[x][1]+e[s][1]+e[u][1]+e[n][1]+
				   e[a][1]+e[c][1]+e[g][1];
	  qmoto_i[2] = e[i][2]+e[j][2]+e[z][2]+e[x][2]+e[s][2]+e[u][2]+e[n][2]+
				   e[a][2]+e[c][2]+e[g][2];

	  for (k = 0; k < NUMVECT; k++)
	  for (y = k+1; y < NUMVECT; y++)
	  for (w = y+1; w < NUMVECT; w++)
	  for (t = w+1; t < NUMVECT; t++)
	  for (r = t+1; r < NUMVECT; r++)
	  for (v = r+1; v < NUMVECT; v++)
	  for (m = v+1; m < NUMVECT; m++)
	  for (b = m+1; b < NUMVECT; b++)
	  for (d = b+1; d < NUMVECT; d++)
	  for (f = d+1; f < NUMVECT; f++) {

		  qmoto_f[0] = e[k][0]+e[y][0]+e[w][0]+e[t][0]+e[r][0]+e[v][0]+
					   e[m][0]+e[b][0]+e[d][0]+e[f][0];
		  qmoto_f[1] = e[k][1]+e[y][1]+e[w][1]+e[t][1]+e[r][1]+e[v][1]+
					   e[m][1]+e[b][1]+e[d][1]+e[f][1];
		  qmoto_f[2] = e[k][2]+e[y][2]+e[w][2]+e[t][2]+e[r][2]+e[v][2]+
					   e[m][2]+e[b][2]+e[d][2]+e[f][2];

		  if ( (qmoto_i[0] == qmoto_f[0]) && (qmoto_i[1] == qmoto_f[1]) &&
		    (qmoto_i[2] == qmoto_f[2]) ) 
		  	if  ( !((k == i) && (j == y) && (z == w) && (t == x) && (s == r) &&
			    (u == v) && (n == m) && (b == a) && (c == d) && (f == g)) ) {
				found = scan = 0;
				collSet[MAX - 1].qmoto[0] = qmoto_f[0]; 
				collSet[MAX - 1].qmoto[1] = qmoto_f[1];
				collSet[MAX - 1].qmoto[2] = qmoto_f[2];
				do 
					if (found = (collSet[scan].qmoto[0] == qmoto_f[0] &&
					    collSet[scan].qmoto[1] == qmoto_f[1] &&
					    collSet[scan].qmoto[2] == qmoto_f[2])); 
					else scan++;
				while (!found && scan < numClass); 
				/* se trovato in ultima posizione allora e' la sentinella */
				if (found && (scan == MAX - 1)) {
					fprintf (stderr, "Overflow!\n");
					exit (1);
				}
				/* se non trovato aggiungo una nuova classe */
				if (!found) {
					collSet[numClass].qmoto[0] = qmoto_f[0];
					collSet[numClass].qmoto[1] = qmoto_f[1];
					collSet[numClass].qmoto[2] = qmoto_f[2];
					collSet[numClass].dim++;
					p = collSet[numClass].collList = (collRec *) malloc (sizeof (collRec));
					numClass++;
				}
				else {
					/* trovato: devo spostarmi alla fine della lista delle collisioni */
					p = collSet[scan].collList;
					for (count = 0; count < collSet[scan].dim - 1; count++)
					  	p = p->next;
					p = p->next = (collRec *) malloc (sizeof (collRec));

					/* aggiorno dimensione della classe */
					collSet[scan].dim++;		
					}

				/* aggiungo la collisione in fondo alla lista */
				p->next = NULL;
				p->coll = (char *) malloc (bufLen);
				sprintf (p->coll, "%d %d %d %d %d %d %d %d %d %d - %d %d %d %d %d %d %d %d %d %d", i, j, z, x, s, u, n, a, c, g, k, y, w, t, r, v, m, b, d, f);
		  	}
	  }
  };
  /* conta le collisioni solo delle classi che superano la soglia */
  for (scan = 0; (dim = collSet[scan].dim) > 0; scan++)
  	if (dim > minDim)  
		*numColl += dim; 

}


void  main (int argc, char *argv[])
{
  collClass  allCollSet[NUMCLASS_MASS][MAX];		/* insieme delle classi di equivalenza */
  int		numColl[NUMCLASS_MASS] = {0};			/* numero di collisioni per numero 
													 * di particelle
													 */
  void (*generateCollision[NUMCLASS_MASS])() = {TwoPartColl, ThreePartColl, FourPartColl, 
												FivePartColl, SixPartColl, SevenPartColl, 
												EightPartColl, NinePartColl, TenPartColl};

  userOption optionsRec;
  int i;

  optionsRec.setOptions = 0;

  printf ("\nCalcolo insieme delle collisioni per modello rombododecaedrico.\n");

  parseCommandLine (argc, argv, &optionsRec);
 
  /* apertura dei files */
  fp1 = fopen (optionsRec.collSetFileName, "w");
  fp2 = fopen (optionsRec.classFileName, "w");

  /* inizializzazione della struttura dati che conterra' le classi di equivalenza */ 
  Initialize (allCollSet);

  /* generazione delle collisioni per numero di particelle coinvolte */
  for (i = 0; i < NUMCLASS_MASS; i++)
	if (optionsRec.setOptions & opt_part[i]) {
		printf ("collisioni a %d particelle\n",i+2);
		(generateCollision[i])(allCollSet[i], &numColl[i]);
	}

  writeCollClass(allCollSet, numColl);

  fclose (fp1);
  fclose (fp2);
}
