Tool suite for the rhombic dodecahedron cellular automaton.
Please bear in mind that this software was written in 1996-97, 
so it will most likely require some changes to compile on a
modern system. (However, a couple of tools compiled OK without
any modification!)

Folder contents:
sim/		several 'resource' files for running simulations;
src/		source code

Comments in the source code are in Italian, but both variable and 
function names are in English. See my thesis for more information
on the tool suite structure.

Paolo Zuliani
paolo.zuliani@ncl.ac.uk
December 2012
